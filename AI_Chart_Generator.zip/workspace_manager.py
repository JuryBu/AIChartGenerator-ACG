# workspace_manager.py

import os
from typing import Optional, TYPE_CHECKING
from constants import INPUT_DIR
from workspace_model import Workspace
import copy
# 为了避免循环导入，我们只在类型检查时导入 MainAppApi
if TYPE_CHECKING:
    from main_app_api import MainAppApi


class WorkspaceManager:
    """负责管理所有工作区对象的生命周期和状态切换。"""

    def __init__(self, api: 'MainAppApi'):
        """
        初始化工作区管理器。
        :param api: MainAppApi 的实例，用于与前端通信。
        """
        self.api = api
        self.workspaces: dict[str, Workspace] = {}
        self.active_workspace_id: Optional[str] = None

    def create_workspace(self, name: str, model_config: dict, font_config: dict) -> Workspace:
        """
        创建一个新的工作区，并触发UI更新。
        返回创建的工作区对象。
        """
        # 从全局设置中获取默认值
        initial_max_retries = self.api.config_manager.settings.get('max_retries', 3)
        initial_max_agent_retries = self.api.config_manager.settings.get('max_agent_retries', 3)

        # --- 核心修复：创建配置的深拷贝 ---
        workspace_model_config = copy.deepcopy(model_config)
        workspace_font_config = copy.deepcopy(font_config)

        # 将这些值设置到新工作区的配置中
        workspace_model_config['max_retries'] = initial_max_retries
        workspace_model_config['max_agent_retries'] = initial_max_agent_retries

        # 使用独立的配置副本创建新工作区
        new_workspace = Workspace(name, workspace_model_config, workspace_font_config)
        self.workspaces[new_workspace.id] = new_workspace

        # 通知前端UI列表已更新，由前端负责渲染
        self.api.refresh_ui_lists()

        return new_workspace

    def delete_workspace(self, workspace_id: str):
        """
        删除指定的工作区，包括清理文件，并通知前端更新UI。
        """
        if workspace_id not in self.workspaces:
            return

        ws_to_delete = self.workspaces[workspace_id]

        # 1. 如果删除的是当前活动的工作区，需要先确定新的活动工作区
        if self.active_workspace_id == workspace_id:
            # 寻找一个可以切换到的新工作区
            other_ws_ids = [ws_id for ws_id in self.workspaces if ws_id != workspace_id]
            self.active_workspace_id = other_ws_ids[0] if other_ws_ids else None

        # 2. 清理文件系统中的文件
        # 2a. 清理 input/ 目录下的托管文件
        for target in ['data', 'prompt']:
            for file_info in ws_to_delete.managed_files.get(target, []):
                managed_name = file_info['managed_name']
                input_file_path = os.path.join(INPUT_DIR, managed_name)

                # 删除原始文件
                if os.path.exists(input_file_path):
                    try:
                        os.remove(input_file_path)
                        print(f"成功删除输入文件: {input_file_path}")
                    except OSError as e:
                        self.api.show_alert(f"删除输入文件失败 {input_file_path}: {e}", "error")

                # 检查并删除关联的预览文件（如果信息存在）
                if file_info.get('preview_path') and os.path.exists(file_info['preview_path']):
                    try:
                        os.remove(file_info['preview_path'])
                        print(f"成功删除预览文件: {file_info['preview_path']}")
                    except OSError as e:
                        self.api.show_alert(f"删除预览文件失败 {file_info['preview_path']}: {e}", "error")

        # 2b. 清理 output/ 目录下的所有生成文件 (关键修改)
        print(f"正在为工作区 {workspace_id} 清理输出文件...")
        outputs_to_delete = ws_to_delete.generated_outputs
        for output_dict in outputs_to_delete:
            file_path = output_dict.get('final_path')
            if file_path and os.path.exists(file_path):
                try:
                    os.remove(file_path)
                    print(f"成功删除输出文件: {file_path}")
                except OSError as e:
                    self.api.show_alert(f"删除输出文件失败 {file_path}: {e}", "error")

        # 2c. 清理其他未被 generated_outputs 跟踪的文件
        other_paths_to_clean = [
            ws_to_delete.get_temp_data_path(),
            ws_to_delete.get_code_path()
        ]
        for f_path in other_paths_to_clean:
            if os.path.exists(f_path):
                try:
                    os.remove(f_path)
                except OSError as e:
                    self.api.show_alert(f"删除文件失败 {f_path}: {e}", "error")

        # 3. 从数据结构中移除
        self.workspaces.pop(workspace_id)

        # 4. 通知前端UI列表已更新，由前端负责重新渲染
        self.api.refresh_ui_lists()

    def get_active_workspace(self) -> Optional[Workspace]:
        """获取当前活动的工作区对象。"""
        if self.active_workspace_id and self.active_workspace_id in self.workspaces:
            return self.workspaces[self.active_workspace_id]
        return None

    def switch_to_workspace(self, workspace_id: str):
        """
        切换到指定的工作区。
        """
        if workspace_id == self.active_workspace_id or workspace_id not in self.workspaces:
            return

        # 更新活动ID
        self.active_workspace_id = workspace_id
        active_ws = self.get_active_workspace()

        print(f"切换到工作区: {active_ws.name} (ID: {workspace_id})")

        # 如果这个工作区有新结果，现在用户看到了，重置标志
        if active_ws.has_new_result:
            active_ws.has_new_result = False

        # 通知前端UI列表已更新（包括活动项），由前端负责高亮和加载内容
        self.api.refresh_ui_lists()