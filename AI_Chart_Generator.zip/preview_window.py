import sys
import json
import webview
import os
import pathlib

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path
from webview_apis import PreviewApi

if __name__ == '__main__':
    print("\n--- [DEBUG preview_window] 进程已启动 ---")
    print(f"[DEBUG preview_window] 接收到的所有命令行参数 (sys.argv): {sys.argv}")

    if len(sys.argv) < 2:
        print("错误：需要一个临时JSON文件的路径作为命令行参数。")
        sys.exit(1)

    temp_file_path = sys.argv[1]
    print(f"[DEBUG preview_window] 接收到的临时文件路径: {temp_file_path}")

    preview_data = None
    window_title = "内容预览"

    try:
        with open(temp_file_path, 'r', encoding='utf-8') as f:
            preview_data = json.load(f)
        print("[DEBUG preview_window] 从文件解析JSON成功！")
        window_title = preview_data.get("任务名称", "内容预览")
    except (json.JSONDecodeError, FileNotFoundError) as e:
        error_message = f"无法从文件解析预览数据: {e}"
        preview_data = {"错误": error_message, "文件路径": temp_file_path}
        window_title = "预览错误"
        print(f"[ERROR preview_window] {error_message}")
    finally:
        if os.path.exists(temp_file_path):
            try:
                os.remove(temp_file_path)
                print(f"[DEBUG preview_window] 临时文件 {temp_file_path} 已成功删除。")
            except OSError as e:
                print(f"[ERROR preview_window] 删除临时文件失败: {e}")

    api = PreviewApi(preview_data)

    # --- 核心修正：恢复使用 file:// URL 的方式加载 ---
    try:
        html_file_path = resource_path("web/preview.html")
        # 2. 使用 pathlib 将普通路径转换为浏览器能理解的 file:// URI
        html_url = pathlib.Path(html_file_path).as_uri()
        print(f"[DEBUG preview_window] 转换后的HTML URI: {html_url}")
    except Exception as e:
        # 如果连生成URL都失败，显示一个错误
        error_html = f"<h1>Error</h1><p>Could not generate URL for preview.html.</p><p>{e}</p>"
        webview.create_window("加载错误", html=error_html)
        webview.start(debug=True)
        sys.exit(1)
    # --- 修正结束 ---


    webview.create_window(
        window_title,
        url=html_url,  # <--- 3. 使用 url 参数，而不是 html 参数
        width=800,
        height=700,
        resizable=True,
        min_size=(600, 500),
        js_api=api
    )
    webview.start()