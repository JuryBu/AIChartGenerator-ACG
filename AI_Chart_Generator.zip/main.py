# main.py

import webview
import pathlib
from utils import resource_path
from main_app_api import MainAppApi

if __name__ == "__main__":
    api = MainAppApi()

    # 准备HTML文件的file:// URI
    html_path = resource_path("web/main.html")
    html_url = pathlib.Path(html_path).as_uri()

    window = webview.create_window(
        'ACG - AI Chart Generator',
        url=html_url,
        js_api=api,
        width=1200,
        height=900,
        min_size=(1000, 700)
    )

    api.set_window(window)
    window.events.closing += api.on_closing
    api.start_context_server()
    # 这个函数会启动一个后台线程，等待前端就绪后进行检查。
    api._perform_startup_checks()

    webview.start()