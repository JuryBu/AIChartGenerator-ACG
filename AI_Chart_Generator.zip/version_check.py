import os
import sys
import win32com.client
import webview
import queue
import time
import webbrowser
import json
import pathlib
import requests
import threading
import subprocess
import zipfile

# 确保项目根目录在 sys.path 中，以便导入 utils
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path

# --- 全局常量 ---
GITEE_API_URL = "https://gitee.com/api/v5/repos/JuryBu/aichart-generator-acg/releases"
GITEE_RELEASES_PAGE = "https://gitee.com/JuryBu/aichart-generator-acg/releases"


class Api:
    """
    暴露给前端 JavaScript 的 Python API。
    """
    def __init__(self):
        # 将 window 引用设为私有 (_window)，以防止 pywebview 在启动时
        # 从主线程内省它，从而避免跨线程 UI 访问错误。
        self._window = None
        # 创建一个线程安全的队列，用于从工作线程向 UI 线程发送 JS 代码。
        self.js_queue = queue.Queue()

    def get_versions(self):
        """
        从 Gitee API 获取版本列表。
        """
        try:
            response = requests.get(GITEE_API_URL, timeout=10)
            response.raise_for_status()
            releases = response.json()

            versions_info = []
            for release in releases:
                version_tag = release.get("tag_name", "N/A")
                assets = release.get("assets", [])
                zip_url, exe_url, py_url, main_exe_name = None, None, None, None

                for asset in assets:
                    download_url = asset.get("browser_download_url")
                    if download_url:
                        if download_url.endswith('.zip'):
                            zip_url = download_url
                        elif download_url.endswith('.exe'):
                            exe_url = download_url
                            main_exe_name = asset.get("name")
                        elif download_url.endswith('.py'):
                            py_url = download_url

                if zip_url and exe_url and py_url and main_exe_name:
                    versions_info.append({
                        "tag": version_tag,
                        "name": release.get("name", "未命名版本"),
                        "published_at": release.get("created_at", ""),
                        "body": release.get("body", "无版本描述。"),
                        "assets": {
                            "zip": zip_url,
                            "exe": exe_url,
                            "py": py_url,
                            "main_exe_name": main_exe_name,
                            "shortcut_name": f"{os.path.splitext(main_exe_name)[0]}.lnk"
                        }
                    })
            return {"status": "success", "versions": versions_info}
        except requests.RequestException as e:
            return {"status": "error", "message": f"获取版本列表失败: {e}"}
        except Exception as e:
            return {"status": "error", "message": f"处理数据时发生未知错误: {e}"}

    def select_directory(self):
        """
        打开一个文件夹选择对话框。
        """
        # 使用私有引用 _window
        result = self._window.create_file_dialog(webview.FOLDER_DIALOG)
        return result[0] if result else None

    def open_repo(self):
        """
        在默认浏览器中打开 Gitee 发布页面。
        """
        webbrowser.open(GITEE_RELEASES_PAGE)
        return {"status": "success"}

    def start_installation(self, version_data, install_path):
        """
        在一个新的后台线程中开始安装过程，以避免阻塞 UI。
        """
        thread = threading.Thread(target=self._install_logic, args=(version_data, install_path), daemon=True)
        thread.start()

    def _update_js(self, func_name, *args):
        """
        一个线程安全的辅助函数，用于将 JS 调用排入队列。
        """
        js_args = ', '.join(map(json.dumps, args))
        script = f'{func_name}({js_args})'
        self.js_queue.put(script)

    def _install_logic(self, version_data, install_path):
        """
        核心安装逻辑，在后台线程中执行。
        """
        try:
            os.makedirs(install_path, exist_ok=True)
            assets = version_data['assets']
            main_exe_name = assets['main_exe_name']
            shortcut_name = assets['shortcut_name']

            download_targets = {
                "zip": os.path.join(install_path, "program.zip"),
                "exe": os.path.join(install_path, main_exe_name),
                "py": os.path.join(install_path, "get-pip.py")
            }

            self.download_file_with_progress(assets["zip"], download_targets["zip"], "正在下载主程序包...", 0, 40)
            self.download_file_with_progress(assets["exe"], download_targets["exe"], "正在下载执行文件...", 40, 30)
            self.download_file_with_progress(assets["py"], download_targets["py"], "正在下载配置脚本...", 70, 5)

            self._update_js("update_progress", 78, "正在解压文件...")
            with zipfile.ZipFile(download_targets["zip"], 'r') as zip_ref:
                zip_ref.extractall(install_path)
            self._update_js("update_progress", 85, "解压完成")

            self._update_js("update_progress", 88, "正在配置Python环境...")
            python_exe_path = os.path.join(install_path, "python", "python.exe")
            setup_script_path = download_targets["py"]
            if os.path.exists(python_exe_path):
                # 步骤1: 准备一个干净的环境变量副本
                proc_env = os.environ.copy()
                # 步骤2: 强制子进程使用UTF-8
                proc_env['PYTHONUTF8'] = '1'

                process = subprocess.run(
                    [python_exe_path, setup_script_path],
                    capture_output=True, text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                    env=proc_env  # <--- 步骤3: 将修复后的环境传递给子进程
                )
                if process.returncode != 0:
                    raise Exception(f"环境配置脚本执行失败: {process.stderr}")
                self._update_js("update_progress", 92, "环境配置成功")
            else:
                self._update_js("update_status", "警告：未找到嵌入式Python，跳过环境配置", "warning")
                time.sleep(2)

            self._update_js("update_progress", 95, "正在创建桌面快捷方式...")
            target_exe_path = download_targets["exe"]
            shell = win32com.client.Dispatch("WScript.Shell")
            desktop = shell.SpecialFolders("Desktop")
            shortcut_path = os.path.join(desktop, shortcut_name)
            shortcut = shell.CreateShortcut(shortcut_path)
            shortcut.TargetPath = target_exe_path
            shortcut.WorkingDirectory = install_path
            shortcut.Description = f"AI Chart Generator {version_data['tag']}"
            shortcut.save()

            self._update_js("update_progress", 98, "正在清理临时文件...")
            os.remove(download_targets["zip"])
            os.remove(download_targets["py"])

            self._update_js("installation_complete", "安装成功！此窗口将在3秒后自动关闭。")
            time.sleep(3)
            self.js_queue.put("CLOSE_WINDOW")
        except Exception as e:
            error_message = f"安装失败: {e}"
            print(error_message)
            self._update_js("update_status", error_message, "error")

    def download_file_with_progress(self, url, save_path, message_prefix, progress_start, progress_span):
        try:
            response = requests.get(url, stream=True, timeout=30)
            response.raise_for_status()
            total_size = int(response.headers.get('content-length', 0))
            bytes_downloaded = 0
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    bytes_downloaded += len(chunk)
                    if total_size > 0:
                        percent_of_file = (bytes_downloaded / total_size) * 100
                        total_percent = progress_start + (percent_of_file / 100 * progress_span)
                        mb_downloaded = bytes_downloaded / 1024 / 1024
                        mb_total = total_size / 1024 / 1024
                        message = f"{message_prefix} ({mb_downloaded:.2f}MB / {mb_total:.2f}MB)"
                        self._update_js("update_progress", int(total_percent), message)
        except requests.RequestException as e:
            raise Exception(f"下载文件失败: {url}") from e


# --- 线程通信与窗口管理 ---

# 创建一个事件来优雅地通知 poll_js_queue 循环退出
shutdown_event = threading.Event()

def on_closing():
    """当用户点击窗口关闭按钮时，此函数被调用。"""
    print("窗口正在关闭，设置 shutdown event。")
    shutdown_event.set()

def poll_js_queue(window, api_instance):
    """
    这个函数作为自定义的事件循环运行在主线程上。
    它负责从队列中取出 JS 代码并执行它。
    """
    while not shutdown_event.is_set():
        try:
            # 使用带超时的阻塞式 get，这比空转+sleep更高效
            script = api_instance.js_queue.get(block=True, timeout=0.1)

            if script == "CLOSE_WINDOW":
                print("接收到 CLOSE_WINDOW 命令，销毁窗口...")
                window.destroy()  # 这会触发 on_closing 事件，从而设置 shutdown_event
                break  # 退出循环

            if window.webview_is_running:
                window.evaluate_js(script)

        except queue.Empty:
            # 队列为空，超时，循环继续，再次检查 shutdown_event
            continue
        except Exception as e:
            # 捕获在执行脚本时可能发生的错误
            print(f"从队列执行脚本时出错: {e}")
            if not window.webview_is_running:
                print("窗口已不再运行，退出 poll_js_queue。")
                break

    print("poll_js_queue 循环已干净地退出。")


# --- 程序主入口 ---

if __name__ == '__main__':
    api = Api()
    html_path = resource_path("web/version_check.html")
    html_url = pathlib.Path(html_path).as_uri()

    window = webview.create_window(
        '版本检查与更新',
        html_url,
        js_api=api,
        width=800,
        height=600,
        resizable=True
    )
    # 将窗口实例安全地赋给 API 的私有属性
    api._window = window

    # 将 on_closing 函数绑定到窗口的 closing 事件
    window.events.closing += on_closing

    # 启动 pywebview，使用我们的 poll_js_queue 函数作为事件循环
    webview.start(poll_js_queue, (window, api))

    print("Pywebview 已关闭，程序退出。")
