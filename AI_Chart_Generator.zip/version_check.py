import os
import sys
import threading
import requests
import zipfile
import subprocess
import win32com.client
import webview
import time
import webbrowser
import json
import pathlib

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path

# Gitee API URL for your repository releases
GITEE_API_URL = "https://gitee.com/api/v5/repos/JuryBu/aichart-generator-acg/releases"
# Gitee releases page URL
GITEE_RELEASES_PAGE = "https://gitee.com/JuryBu/aichart-generator-acg/releases"


class Api:
    def __init__(self):
        self.window = None

    def get_versions(self):
        """
        Fetches version list from Gitee API.
        """
        try:
            response = requests.get(GITEE_API_URL)
            response.raise_for_status()
            releases = response.json()

            versions_info = []
            for release in releases:
                version_tag = release.get("tag_name", "N/A")
                assets = release.get("assets", [])

                # Find the required asset files
                zip_url, exe_url, py_url = None, None, None
                main_exe_name = None

                for asset in assets:
                    download_url = asset.get("browser_download_url")
                    if download_url:
                        if download_url.endswith('.zip'):
                            zip_url = download_url
                        elif download_url.endswith('.exe'):
                            exe_url = download_url
                            main_exe_name = asset.get("name")
                        elif download_url.endswith('.py'):
                            py_url = download_url

                # Only add the version if all essential files are found
                if zip_url and exe_url and py_url and main_exe_name:
                    versions_info.append({
                        "tag": version_tag,
                        "name": release.get("name", "未命名版本"),
                        "published_at": release.get("created_at", ""),
                        "body": release.get("body", "无版本描述。"),
                        "assets": {
                            "zip": zip_url,
                            "exe": exe_url,
                            "py": py_url,
                            "main_exe_name": main_exe_name,
                            "shortcut_name": f"{os.path.splitext(main_exe_name)[0]}.lnk"
                        }
                    })

            return {"status": "success", "versions": versions_info}

        except requests.RequestException as e:
            return {"status": "error", "message": f"获取版本列表失败: {e}"}
        except Exception as e:
            return {"status": "error", "message": f"处理数据时发生未知错误: {e}"}

    def select_directory(self):
        """
        Opens a folder selection dialog.
        """
        result = self.window.create_file_dialog(webview.FOLDER_DIALOG)
        return result[0] if result else None

    def open_repo(self):
        """
        Opens the Gitee releases page in the default browser.
        """
        webbrowser.open(GITEE_RELEASES_PAGE)
        return {"status": "success"}

    def start_installation(self, version_data, install_path):
        """
        Starts the installation process in a new thread.
        """
        thread = threading.Thread(target=self._install_logic, args=(version_data, install_path))
        thread.start()

    def _update_js(self, func_name, *args):
        """
        Helper function to safely call JS functions using json.dumps for robust serialization.
        """
        if self.window:
            # 使用 json.dumps 可以安全地将 Python 对象转换为 JS 字面量，自动处理引号、反斜杠等
            # 这解决了 Python 3.9 中 f-string 表达式不能包含反斜杠的问题
            js_args = ', '.join(map(json.dumps, args))
            self.window.evaluate_js(f'{func_name}({js_args})')

    def _install_logic(self, version_data, install_path):
        """
        The core installation logic, adapted from installer.py.
        """
        try:
            os.makedirs(install_path, exist_ok=True)

            assets = version_data['assets']
            main_exe_name = assets['main_exe_name']
            shortcut_name = assets['shortcut_name']

            # 1. Download files
            download_targets = {
                "zip": os.path.join(install_path, "program.zip"),
                "exe": os.path.join(install_path, main_exe_name),
                "py": os.path.join(install_path, "get-pip.py")
            }

            self.download_file_with_progress(assets["zip"], download_targets["zip"], "正在下载主程序包...", 0, 40)
            self.download_file_with_progress(assets["exe"], download_targets["exe"], "正在下载执行文件...", 40, 30)
            self.download_file_with_progress(assets["py"], download_targets["py"], "正在下载配置脚本...", 70, 5)

            # 2. Unzip
            self._update_js("update_progress", 78, "正在解压文件...")
            with zipfile.ZipFile(download_targets["zip"], 'r') as zip_ref:
                zip_ref.extractall(install_path)
            self._update_js("update_progress", 85, "解压完成")

            # 3. Configure environment
            self._update_js("update_progress", 88, "正在配置Python环境...")
            python_exe_path = os.path.join(install_path, "python", "python.exe")
            setup_script_path = download_targets["py"]

            if os.path.exists(python_exe_path):
                process = subprocess.run(
                    [python_exe_path, setup_script_path],
                    capture_output=True, text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                if process.returncode != 0:
                    raise Exception(f"环境配置脚本执行失败: {process.stderr}")
                self._update_js("update_progress", 92, "环境配置成功")
            else:
                self._update_js("update_status", "警告：未找到嵌入式Python，跳过环境配置", "warning")
                time.sleep(2)

            # 4. Create shortcut
            self._update_js("update_progress", 95, "正在创建桌面快捷方式...")
            target_exe_path = download_targets["exe"]

            # --- 使用 pywin32 创建快捷方式 ---
            # 1. 创建 WScript.Shell 对象
            shell = win32com.client.Dispatch("WScript.Shell")

            # 2. 获取桌面路径
            desktop = shell.SpecialFolders("Desktop")
            shortcut_path = os.path.join(desktop, shortcut_name)

            # 3. 创建快捷方式对象
            shortcut = shell.CreateShortcut(shortcut_path)

            # 4. 设置属性
            shortcut.TargetPath = target_exe_path
            shortcut.WorkingDirectory = install_path
            shortcut.Description = f"AI Chart Generator {version_data['tag']}"
            # 可选: 设置图标
            # shortcut.IconLocation = target_exe_path

            # 5. 保存
            shortcut.save()
            # --- 修改结束 ---

            # 5. Cleanup
            self._update_js("update_progress", 98, "正在清理临时文件...")
            os.remove(download_targets["zip"])
            os.remove(download_targets["py"])

            # 6. Complete
            self._update_js("installation_complete", "安装成功！此窗口将在3秒后关闭。")
            time.sleep(3)
            self.window.destroy()

        except Exception as e:
            error_message = f"安装失败: {e}"
            print(error_message)
            self._update_js("update_status", error_message, "error")

    def download_file_with_progress(self, url, save_path, message_prefix, progress_start, progress_span):
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()
            total_size = int(response.headers.get('content-length', 0))
            bytes_downloaded = 0

            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    bytes_downloaded += len(chunk)
                    if total_size > 0:
                        percent_of_file = (bytes_downloaded / total_size) * 100
                        total_percent = progress_start + (percent_of_file / 100 * progress_span)
                        mb_downloaded = bytes_downloaded / 1024 / 1024
                        mb_total = total_size / 1024 / 1024
                        message = f"{message_prefix} ({mb_downloaded:.2f}MB / {mb_total:.2f}MB)"
                        self._update_js("update_progress", int(total_percent), message)
        except requests.RequestException as e:
            raise Exception(f"下载文件失败: {url}") from e


if __name__ == '__main__':
    api = Api()
    # 1. 使用 resource_path 获取 HTML 文件的绝对路径
    html_path = resource_path("web/version_check.html")
    # 2. 使用 pathlib 将路径转换为浏览器可识别的 file:// 格式
    html_url = pathlib.Path(html_path).as_uri()

    window = webview.create_window(
        '版本检查与更新',
        html_url,  # <--- 使用生成的 URL
        js_api=api,
        width=800,
        height=600,
        resizable=True
    )
    api.window = window

    # 移除 http_server，因为我们现在使用 file:// 协议
    webview.start()