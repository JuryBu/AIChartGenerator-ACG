# workspace_model.py

import os
import uuid
from typing import Optional, List, Dict  # 步骤 1: 导入 Dict
import shutil
from constants import OUTPUT_DIR
from PIL import Image
import base64
import mimetypes
import json  # 为 load_output_files_from 方法导入
from utils import format_file_size


class Workspace:
    """封装单个工作区的所有状态和数据。"""

    def __init__(self, name: str, model_config: dict, font_config: dict):
        self.id: str = str(uuid.uuid4())
        self.name: str = name
        self.model_config: dict = model_config
        self.api_type: str = model_config.get("api_type", "external")
        self.font_config: dict = font_config
        self.agent_mode_enabled: bool = True  # 默认为开启

        # --- 状态变量 ---
        self.data_input_text: str = ""
        self.prompt_input_text: str = ""
        self.last_generated_code: str = "# 尚未生成任何代码."
        self.console_output: str = ""
        self.analysis_text: str = "# 此处将显示对图表的文字分析..."
        self.analysis_text_raw_md: str = ""

        self.managed_files: dict[str, list] = {'data': [], 'prompt': []}
        self.preview_widgets: dict[str, dict] = {'data': {}, 'prompt': {}}

        # 步骤 2: 移除旧的单文件属性
        # self.generated_image_pil: Optional[PILImage] = None  (已移除)
        # self.generated_image_path: Optional[str] = None      (已移除)

        # 步骤 3: 新增多文件输出列表属性
        self.generated_outputs: List[Dict] = []

        # --- 新增：清除选项配置 ---
        self.clear_options: dict = {
            "plot": True,
            "code": True,
            "console": True,
            "analysis": True
        }

        # --- 运行标志 ---
        self.is_running: bool = False
        self.has_new_result: bool = False

        # --- 新增: 状态日志和进度条 ---
        self.status_log: list = []
        self.progress: dict = {"value": 0, "text": "空闲", "visible": False}

    def clear_all_outputs(self):
        """
        无条件地清除所有输出区域的内容。
        此方法用于生成新结果之前，不理会用户的UI选择。
        """
        all_output_targets = ["plot", "code", "console", "analysis"]
        self.clear_selective_outputs(all_output_targets)

    def clear_selective_outputs(self, targets: List[str]):
        """根据传入的目标列表，选择性地清除输出内容。"""
        print(f"工作区 {self.id} 正在清除: {targets}")

        # 当 "plot" 在目标中时，它代表整个输出区域（图片+文件列表）
        if "plot" in targets:
            # 1. 遍历当前所有输出，收集需要删除的文件路径
            files_to_delete = []
            for item in self.generated_outputs:
                file_path = item.get('final_path')
                if file_path and os.path.exists(file_path):
                    files_to_delete.append(file_path)

            # 2. 从文件系统删除这些文件
            for f_path in files_to_delete:
                try:
                    os.remove(f_path)
                except OSError as e:
                    print(f"清除输出文件失败 {f_path}: {e}")

            # 3. 完全清空输出列表
            self.generated_outputs = []

        if "code" in targets:
            self.last_generated_code = "# 尚未生成任何代码."

        if "console" in targets:
            self.console_output = ""

        if "analysis" in targets:
            self.analysis_text = "# 此处将显示对图表的文字分析..."
            self.analysis_text_raw_md = "" # 同时清空原始Markdown

    def get_temp_data_path(self) -> str:
        """返回此工作区专用的临时数据文件路径。"""
        return os.path.join(OUTPUT_DIR, f"data_{self.id}.xlsx")

    def get_code_path(self) -> str:
        """返回此工作区专用的代码文件路径。"""
        return os.path.join(OUTPUT_DIR, f"code_{self.id}.py")

    def get_status_flags(self) -> dict:
        """返回一个包含当前内容状态标志的字典，用于UI更新。"""
        # ... (前面的代码 has_code, has_console_output 不变) ...
        has_code = bool(self.last_generated_code and self.last_generated_code.strip() != "# 尚未生成任何代码.")
        has_console_output = bool(self.console_output and self.console_output.strip())

        # --- 使用原始Markdown进行逻辑判断  ---
        # 1. 安全地获取原始Markdown内容
        raw_md_content = getattr(self, 'analysis_text_raw_md', '').strip()

        # 2. 定义所有可能的占位符
        placeholder_with_hash = "# 此处将显示对图表的文字分析..."
        placeholder_without_hash = "此处将显示对图表的文字分析..." # 兼容可能被污染的旧数据

        # 3. 使用与保存历史时完全相同的、最健壮的逻辑来判断状态
        has_analysis = bool(
            raw_md_content and \
            raw_md_content != placeholder_with_hash and \
            raw_md_content != placeholder_without_hash
        )

        # 基于新的 self.generated_outputs 列表来判断状态 (这部分不变)
        has_plot = any(item.get('type') == 'image' for item in self.generated_outputs)
        has_data_file = any(item.get('type') == 'data' for item in self.generated_outputs)

        return {
            "has_code": has_code,
            "has_plot": has_plot,
            "has_data_file": has_data_file,
            "has_console_output": has_console_output,
            "has_analysis": has_analysis,
        }

    def clear_content(self):
        """清空工作区的所有内容和状态，但不包括配置。"""
        self.data_input_text = ""
        self.prompt_input_text = ""
        self.last_generated_code = "# 尚未生成任何代码."
        self.console_output = ""
        self.analysis_text = "# 此处将显示对图表的文字分析..."

        # 步骤 5: 修改 clear_content 方法
        # 移除旧属性的清除逻辑
        # self.generated_image_pil = None  (已移除)
        # self.generated_image_path = None (已移除)

        # 清空输入文件（逻辑上）
        for target in ['data', 'prompt']:
            self.managed_files[target].clear()

        # --- 修改：遍历 self.generated_outputs 列表来清理物理文件 ---
        for item in self.generated_outputs:
            f_path = item.get('final_path')
            if f_path and os.path.exists(f_path):
                try:
                    os.remove(f_path)
                except OSError as e:
                    print(f"清空工作区时删除文件失败 {f_path}: {e}")

        # 清空列表本身
        self.generated_outputs = []

        # 清理其他独立于 generated_outputs 的文件（例如代码文件）
        other_paths_to_clean = [
            self.get_code_path(),
            self.get_temp_data_path()  # 可选：如果临时数据文件不被 tracked
        ]
        for f_path in other_paths_to_clean:
            if os.path.exists(f_path):
                try:
                    os.remove(f_path)
                except OSError as e:
                    print(f"清空工作区时删除文件失败 {f_path}: {e}")

    def load_output_files_from(self, history_path: str):
        """从一个历史记录文件夹加载输出文件到当前工作区。"""
        # 步骤 6: 修改 load_output_files_from 方法
        self.generated_outputs = []
        # 假设元数据存储在 history_path 下的 metadata.json 文件中
        metadata_path = os.path.join(history_path, 'metadata.json')

        if not os.path.exists(metadata_path):
            print(f"历史记录中未找到元数据文件: {metadata_path}")
            # 兼容旧版历史记录：尝试加载单个文件
            legacy_plot_path = os.path.join(history_path, "output_plot.png")
            if os.path.exists(legacy_plot_path):
                dest_path = os.path.join(OUTPUT_DIR, f"image_{self.id}_0.png")
                shutil.copy2(legacy_plot_path, dest_path)
                self.generated_outputs.append({
                    "type": "image",
                    "filename": "output_plot.png",
                    "final_path": dest_path
                })
            return

        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)
            # 从元数据中获取输出文件列表
            outputs_metadata = metadata.get('generated_outputs', [])
        except (json.JSONDecodeError, IOError) as e:
            print(f"读取或解析元数据失败 {metadata_path}: {e}")
            return

        # 遍历元数据，复制文件并重建 self.generated_outputs 列表
        for index, item_meta in enumerate(outputs_metadata):
            original_filename = item_meta.get('filename')
            # [新增] 兼容旧版历史记录，或使用更可靠的 history_relative_path
            relative_path_in_history = item_meta.get('history_relative_path',
                                                     os.path.join('outputs', original_filename))

            if not original_filename:
                continue

            src_path = os.path.join(history_path, relative_path_in_history)  # <--- 修正点
            if os.path.exists(src_path):
                _, ext = os.path.splitext(original_filename)
                # 为文件在主 output 目录中创建一个新的、与工作区绑定的唯一名称
                # 注意：这里我们使用 original_filename 而不是 relative_path_in_history 来构造新文件名
                new_filename = f"{item_meta.get('type', 'file')}_{self.id}_{index}{ext}"
                dest_path = os.path.join(OUTPUT_DIR, new_filename)

                try:
                    shutil.copy2(src_path, dest_path)

                    # 创建一个新的字典，包含更新后的路径和其他元数据
                    new_output_item = item_meta.copy()
                    new_output_item['final_path'] = dest_path

                    self.generated_outputs.append(new_output_item)
                except Exception as e:
                    print(f"从历史记录复制文件失败: {src_path} -> {dest_path}. 错误: {e}")

    def to_dict(self) -> dict:
        """
        将工作区对象序列化为可转换为JSON的字典。
        """
        status_flags = self.get_status_flags()
        # 步骤 8: 修改 to_dict 方法，为所有图片生成 Base64
        outputs_with_base64 = []
        for item in self.generated_outputs:
            item_copy = item.copy()

            # --- 【核心新增】计算并添加文件大小 ---
            final_path = item_copy.get('final_path')
            if final_path and os.path.exists(final_path):
                try:
                    size_bytes = os.path.getsize(final_path)
                    item_copy['file_size_str'] = format_file_size(size_bytes)
                except OSError:
                    item_copy['file_size_str'] = 'N/A'
            else:
                item_copy['file_size_str'] = 'N/A'
            # --- 新增结束 ---

            if item_copy.get('type') == 'image':
                image_path = item_copy.get('final_path')
                if image_path and os.path.exists(image_path):
                    try:
                        mime_type, _ = mimetypes.guess_type(image_path)
                        if not mime_type: mime_type = "image/png"

                        with open(image_path, "rb") as image_file:
                            encoded_string = base64.b64encode(image_file.read()).decode('utf-8')

                        # 在副本中添加 base64 字段
                        item_copy['base64'] = f"data:{mime_type};base64,{encoded_string}"
                    except Exception as e:
                        print(f"工作区 {self.id} to_dict(): 图片转Base64失败: {e}")
                        item_copy['base64'] = None
            outputs_with_base64.append(item_copy)

        # 找到第一个图片作为主预览图
        first_image_item_processed = next((item for item in outputs_with_base64 if item.get('type') == 'image'), None)
        image_base64 = first_image_item_processed.get('base64') if first_image_item_processed else None
        preview_image_path = first_image_item_processed.get('final_path') if first_image_item_processed else None

        return {
            "id": self.id,
            "name": self.name,
            "api_type": self.api_type,
            "agent_mode_enabled": self.agent_mode_enabled,
            "data_input_text": self.data_input_text,
            "prompt_input_text": self.prompt_input_text,
            "last_generated_code": self.last_generated_code,
            "console_output": self.console_output,
            "analysis_text": self.analysis_text,
            "managed_files": self.managed_files,
            "generated_outputs": outputs_with_base64,  # <-- 使用处理过的新列表
            "generated_image_base64": image_base64,  # 主预览图的 base64
            "preview_image_path": preview_image_path,  # 主预览图的路径
            "has_new_result": self.has_new_result,
            "clear_options": self.clear_options,
            "model_config": self.model_config,
            "font_config": self.font_config,
            "status_flags": status_flags,
            "status_log": self.status_log,
            "progress": self.progress
        }