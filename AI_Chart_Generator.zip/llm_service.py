# llm_service.py

import requests
import json
import base64
import os
import sys
import mimetypes
import subprocess

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import get_python_executable, resource_path


class LLMService:
    def __init__(self, config, log_callback=print):
        self.config = config
        self.api_type = config.get("api_type", "external")
        self.log_callback = log_callback

        if self.api_type == 'external':
            api_config = config.get('external_api', {})
            self.base_url = api_config.get('base_url')
            self.api_key = api_config.get('api_key')
            self.model = api_config.get('model')
        else:  # local
            api_config = config.get('local_api', {})
            self.base_url = api_config.get('base_url')
            self.api_key = api_config.get('api_key', 'not-needed')
            self.model = api_config.get('model')

        if not self.base_url:
            raise ValueError("API base_url is not configured.")

        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }

    def _encode_image_to_base64(self, image_path):
        try:
            with open(image_path, "rb") as image_file:
                return base64.b64encode(image_file.read()).decode('utf-8')
        except Exception as e:
            self.log_callback(f"Error encoding image {image_path}: {e}\n")
            return None

    def _get_file_content(self, filepath):
        """
        通过调用外部脚本来安全地读取文件内容，以避免在主进程中使用pandas。
        """
        filename = os.path.basename(filepath)
        try:
            python_exe = get_python_executable()
            script_path = resource_path("read_file_content.py")

            command = [python_exe, script_path, filepath]

            # 为子进程准备一个干净且强制UTF-8的环境
            proc_env = os.environ.copy()
            proc_env['PYTHONUTF8'] = '1'

            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                encoding='utf-8',
                check=False,  # 我们手动检查返回码
                env=proc_env,
                startupinfo=startupinfo
            )

            if result.returncode == 0:
                return result.stdout
            else:
                error_message = f"读取文件 {filename} 时出错: {result.stderr.strip()}"
                self.log_callback(error_message + "\n")
                return f"# Error reading file: {filename}"

        except Exception as e:
            error_message = f"启动文件读取器时发生错误: {e}"
            self.log_callback(error_message + "\n")
            return f"# Error reading file: {filename}"

    def _build_messages(self, user_prompt, data_files, prompt_files, workspace_id: str):
        system_prompt = """
**核心规则：文件和数据处理**
1.  **输入文件路径**: 用户提供的所有数据文件都位于 `input/` 子目录中。你在代码中引用这些文件时，**必须**使用我在本次提示中提供的**确切文件名**，并加上 `input/` 前缀。
2.  **【极其重要】输出目录**: 所有由你的代码生成的产物（图表、数据文件、文本报告等）**必须**保存到一个特殊的输出目录中。在你的代码里，你**必须**使用 `output_path = '__SANDBOX_PATH__'` 来引用这个目录。
    *   **正确示例**: `plt.savefig(f'{output_path}/sales_trends.png')` 或 `df.to_csv(f'{output_path}/final_data.csv')`。
    *   你可以在这个目录中创建任意数量、任意名称的文件。
3.  **鼓励多样化输出**: 如果用户的请求包含多个分析点，你可以生成多个图表文件。如果需要中间数据和最终报告，你可以同时输出一个 `.csv` 和一个 `.txt` 文件。
4.  **鼓励描述性命名**: 请为你的输出文件使用有意义的、符合其内容的英文名称，例如 `monthly_revenue.png` 或 `cleaned_customer_data.xlsx`。

**核心规则：任务类型判断与输出**
你必须首先判断用户的核心需求属于以下哪一类，并严格按照对应规则输出：

**1. 如果是单纯【可视化任务】(例如：画图、绘制图表、生成图片):**
   a. 你 **必须** 生成完整的Python绘图代码。
   b. **【字体关键指令】** 为了确保中文字符能正确显示，你 **必须** 在所有绘图代码之前，完整地包含以下字体设置代码块，不允许有改动：

    # ---中文字体设置 ---
    import matplotlib.pyplot as plt
    import matplotlib.font_manager as fm
    import os
    import sys

    def setup_chinese_font():
        font_path = '__FONT_PATH_PLACEHOLDER__'
        if os.path.exists(font_path):
            my_font_prop = fm.FontProperties(fname=font_path)
            plt.rcParams['font.sans-serif'] = [my_font_prop.get_name()]
            plt.rcParams['font.family'] = 'sans-serif'
            plt.rcParams['axes.unicode_minus'] = False
            return my_font_prop
        else:
            plt.rcParams['axes.unicode_minus'] = False
            plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial Unicode MS']
            return None
    my_font_prop = setup_chinese_font()
    # ---【结束】中文字体设置 ---

   c. **【极其重要：字体应用规则】** 对于图表中 **所有** 可能包含中文的文本元素，你 **必须** 使用 `fontproperties=my_font_prop` 参数来显式指定字体。
   d. 代码的最后必须是保存图表的指令，例如 `plt.savefig(f'{output_path}/my_chart.png', bbox_inches='tight')`。

**2. 如果是单纯【数据处理/转换任务】:**
   a. 你 **必须** 生成处理数据的Python代码。
   b. 在代码的末尾，你 **必须** 将最终处理完成的DataFrame保存为一个或多个文件。例如：`final_df.to_excel(f'{output_path}/processed_data.xlsx', index=False)`。
   c. 在此模式下，**不要** 导入 `matplotlib` 或调用 `plt.savefig()`。

**3. 如果是【可视化和数据输出兼有】:**
       a. 遵循1，2类型的要求融合，做到既生成可视化图像又完成了数据保存于文件的同时完成效果。
       
**4. 如果是【简单问答/分析任务】(以及无法归为以上三类):**
       a. 你应该优先尝试将答案或分析结果以创造性的可视化方式呈现，遵循【可视化任务】的规则。例如，用一个美观的文本框图表来展示文本答案。
       b. 仅当问题本质上是纯粹的知识性问答（如“什么是Python？”），且你判断任何形式的可视化都会显得多余或无意义时，你才可以放弃生成代码，并直接以纯文本形式在print方式回答。

---------------------------
    从这里开始是任务执行指令的内容

    【代码结构与规范】
        **顶级脚本原则**: 生成的代码必须是可直接从头到尾执行的顶级脚本。**绝对不要** 将核心逻辑封装在任何函数（如 `def main():`）中。
        **避免参数冗余**: 在函数调用时，如果使用了字典解包（`**style_dict`），就**绝对不能**再显式地写入任何已在字典中的参数。

【绘图稳定性提示】 
在绘制复杂的流程图时，请优先使用 connectionstyle="arc3,rad=..." 来创建带角度的箭头，避免使用 connectionstyle="angle,..." 以提高代码的稳定性。

输出要求：
永远只输出纯粹、完整的Python代码。
不要包含任何Markdown标记，如 ```python ... ```。
不要添加任何解释性文字。
"""

        messages = [{"role": "system", "content": system_prompt}]
        content_parts = []

        content_parts.append({"type": "text", "text": f"我的核心要求是：\n---\n{user_prompt}\n---"})

        def process_file_list(file_list, header_text):
            if not file_list:
                return
            content_parts.append({"type": "text", "text": f"\n{header_text}\n"})
            for file_info in file_list:
                # --- 核心修改开始 ---
                original_name = file_info['managed_name']
                is_preview = file_info.get('is_preview', False)

                # `path_for_llm` 是 app_logic 传递过来的，指向真实要读取的文件（原始或预览）
                path_to_read = file_info.get('path_for_llm', os.path.join("input", original_name))

                # 为了进行类型判断，我们仍然使用原始文件名
                filepath_for_mimetype = os.path.join("input", original_name)
                mime_type, _ = mimetypes.guess_type(filepath_for_mimetype)
                ext = os.path.splitext(filepath_for_mimetype)[1].lower()
                # --- 核心修改结束 ---

                if ext == '.pdf':
                    try:
                        import fitz
                        content_parts.append(
                            {"type": "text", "text": f"文件「{original_name}」(PDF)的逐页内容如下 (图片+文字):"})
                        doc = fitz.open(filepath_for_mimetype)  # 使用原始路径打开
                        for i, page in enumerate(doc):
                            page_text = page.get_text("text").strip()
                            pix = page.get_pixmap(dpi=150)
                            img_bytes = pix.tobytes("png")
                            base64_image = base64.b64encode(img_bytes).decode('utf-8')

                            content_parts.append(
                                {"type": "text", "text": f"\n--- {original_name} - 第 {i + 1} 页 ---\n"})
                            content_parts.append({
                                "type": "image_url",
                               "image_url": {"url": f"data:image/png;base64,{base64_image}"}
                            })
                            if page_text:
                                content_parts.append(
                                    {"type": "text", "text": f"第 {i + 1} 页的文本内容：\n```\n{page_text}\n```"})
                        doc.close()
                    except Exception as e:
                        content_parts.append({"type": "text", "text": f"处理PDF文件「{original_name}」时出错: {e}"})

                elif mime_type and mime_type.startswith('image/'):
                    base64_image = self._encode_image_to_base64(filepath_for_mimetype)  # 使用原始路径
                    if base64_image:
                        content_parts.append({"type": "text", "text": f"图片文件「{original_name}」的内容："})
                        content_parts.append({
                           "type": "image_url",
                            "image_url": {"url": f"data:{mime_type};base64,{base64_image}"}
                        })
                else:  # 其他文本类文件
                    # --- 核心修改开始 ---
                    file_text_content = self._get_file_content(path_to_read)  # 使用正确的路径读取内容

                    if is_preview:
                        # 如果是预览文件，构建特殊的提示
                        prompt_text = (
                            f"文件「{original_name}」的前20行预览内容如下：\n"
                            f"重要提示：这是一个大型数据文件的预览，仅用于展示数据结构。"
                            f"在生成的代码中，必须使用原始文件名 '{original_name}' 来读取完整数据。\n"
                            f"```\n{file_text_content}\n```\n"
                        )
                    else:
                        # 如果不是预览文件，使用常规提示
                        prompt_text = f"文件「{original_name}」的内容如下：\n```\n{file_text_content}\n```\n"

                    content_parts.append({"type": "text", "text": prompt_text})
                    # --- 核心修改结束 ---

        process_file_list(data_files, "以下是【待分析的数据文件】及其内容：")
        process_file_list(prompt_files, "以下是【参考文件或样式示例】及其内容：")

        messages.append({"role": "user", "content": content_parts})
        return messages

    def generate_code(self, user_prompt, data_files, prompt_files, workspace_id: str):
        # 使用新的、简化的参数调用新的 _build_messages
        messages = self._build_messages(user_prompt, data_files, prompt_files, workspace_id)
        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": 65536,
        }
        if self.api_type == 'local':
            combined_prompt = ""
            for msg in messages:
                if msg['role'] == 'user':
                    if isinstance(msg['content'], list):
                        for part in msg['content']:
                            if part['type'] == 'text':
                                combined_prompt += part['text'] + "\n"
                    else:
                        combined_prompt += msg['content'] + "\n"

            data['messages'] = [
                {"role": "system", "content": messages[0]['content']},
                {"role": "user", "content": combined_prompt}
            ]

        try:
            self.log_callback("正在向AI模型发送优化后的请求...\n")
            response = requests.post(
                self.base_url,
                headers=self.headers,
                data=json.dumps(data),
                timeout=180,
                proxies=None
            )
            response.raise_for_status()
            response_data = response.json()

            if (not response_data.get('choices') or
                    not response_data['choices'][0].get('message') or
                    not response_data['choices'][0]['message'].get('content')):

                finish_reason = "N/A"
                if response_data.get('choices') and response_data['choices']:
                    finish_reason = response_data['choices'][0].get('finish_reason', 'N/A')

                error_info = (f"API返回成功，但内容为空。\n"
                              f"结束原因: {finish_reason}\n"
                              f"完整响应:\n{json.dumps(response_data, indent=2)}")
                return f"# Error: {error_info}"

            generated_code = response_data['choices'][0]['message']['content'].strip()

            if generated_code.startswith("```python"):
                generated_code = generated_code[9:]
            if generated_code.startswith("```"):
                generated_code = generated_code[3:]
            if generated_code.endswith("```"):
                generated_code = generated_code[:-3]

            self.log_callback("成功接收并清理API响应。\n")
            return generated_code.strip()

        except requests.exceptions.Timeout:
            return "# 错误: API请求超时。服务器响应时间过长。"
        except requests.exceptions.RequestException as e:
            return f"# 错误: API请求失败: {e}"
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            return f"# 错误: 解析API响应失败: {e}\n响应文本:  {response.text}"

    def analyze_outputs(self, generated_outputs, input_data_files):
        """
        向LLM发送所有生成的输出文件（图片、数据等）和原始输入数据，请求文字分析。
        此函数是一个生成器，用于流式返回分析文本。
        """
        analysis_system_prompt = """
你是顶级的图表与数据分析专家。你的任务是根据用户提供的所有生成结果（可能包含多张图表、数据文件、文本报告等）和原始数据，生成一段全面、专业、精炼的文字分析报告。

请严格遵守以下核心规则：
1.  「格式要求」：在你的回答中，如果需要强调某些词语或句子，请使用「」符号，绝对不要使用 `**` 或者 `“”`。
2.  「公式要求」：如果分析内容中需要使用任何数学或统计公式，必须以LaTeX格式呈现（例如：相关系数 $r_{xy}$ 的计算公式为 $r_{xy} = \frac{\sum_{i=1}^{n}(x_i - \bar{x})(y_i - \bar{y})}{\sqrt{\sum_{i=1}^{n}(x_i - \bar{x})^2}\sqrt{\sum_{i=1}^{n}(y_i - \bar{y})^2}}$）。
3.  「内容要求」：你的分析必须是对所有结果的多维度综合解读。做到「不重不漏」，全面覆盖所有图表和数据反映的关键信息点，例如趋势、异常值、分布特征、项目间的比较关系、数据间的关联等。
4.  「纯粹性要求」：绝对不要输出任何多余的文字，比如“好的，这是您的分析：”或“希望这个分析对您有帮助。”等。直接开始你的分析内容。
"""
        messages = [{"role": "system", "content": analysis_system_prompt}]
        content_parts = []
        content_parts.append(
            {"type": "text", "text": "请根据以下所有生成的结果文件，并参考原始输入数据，生成一份专业的综合分析报告。"})

        if not generated_outputs:
            yield "# 错误: 没有任何可供分析的生成结果。"
            return

        content_parts.append({"type": "text", "text": "\n--- 生成的结果文件如下 ---\n"})
        for item in generated_outputs:
            # --- 【核心修改】使用 app_logic 准备好的新路径和标记 ---
            path_to_read = item.get('path_for_analysis', item.get('final_path'))
            is_preview = item.get('is_preview', False)
            # --- 【修改结束】 ---

            filename = item.get('filename')
            file_type = item.get('type')

            if not (path_to_read and os.path.exists(path_to_read)):
                continue

            if file_type == 'image':
                mime_type, _ = mimetypes.guess_type(path_to_read)
                base64_image = self._encode_image_to_base64(path_to_read)
                if base64_image:
                    content_parts.append({"type": "text", "text": f"图片文件「{filename}」:"})
                    content_parts.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime_type or 'image/png'};base64,{base64_image}"}
                    })
            else:  # data, text, other
                file_content = self._get_file_content(path_to_read)
                # --- 【核心修改】在提示中明确告知LLM这是一个预览文件 ---
                content_parts.append({
                    "type": "text",
                    "text": f"文件「{filename}」的内容{'（预览）' if is_preview else ''}：\n```\n{file_content}\n```\n"
                })
                # --- 【修改结束】 ---

        # --- 添加原始输入数据作为上下文 (这部分逻辑已经很完美，保持不变) ---
        if input_data_files:
            content_parts.append({"type": "text",
                                  "text": "\n--- 作为参考，这是生成以上结果所使用的原始数据文件（请注意，对过大的文件做了预处理截取处理，只保留了前20行左右的数据，表头没有修改） ---\n"})
            for file_info in input_data_files:
                filename = file_info['managed_name']
                path_to_read = file_info.get('path_for_llm', os.path.join("input", filename))
                mime_type, _ = mimetypes.guess_type(os.path.join("input", filename))
                if mime_type and mime_type.startswith('image/'):
                    continue
                file_text_content = self._get_file_content(path_to_read)
                content_parts.append({
                    "type": "text",
                    "text": f"文件「{filename}」的内容{'（预览）' if file_info.get('is_preview') else ''}：\n```\n{file_text_content}\n```"
                })

        messages.append({"role": "user", "content": content_parts})

        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": 65536,
            "stream": True
        }

        # --- 流式请求和处理逻辑保持不变 ---
        try:
            self.log_callback("正在向AI模型发送分析请求...\n")
            response = requests.post(
                self.base_url,
                headers=self.headers,
                data=json.dumps(data),
                timeout=120,
                stream=True,  # 让requests库也处理流
                proxies=None
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    decoded_line = line.decode('utf-8')
                    if decoded_line.startswith('data: '):
                        json_str = decoded_line[6:]
                        if json_str.strip() == '[DONE]':
                            self.log_callback("\n分析流接收完毕。\n")
                            break
                        try:
                            chunk = json.loads(json_str)
                            if 'choices' in chunk and chunk['choices']:
                                delta = chunk['choices'][0].get('delta', {})
                                content = delta.get('content')
                                if content:
                                    yield content # 产出文本块
                        except json.JSONDecodeError:
                            continue

        except requests.exceptions.RequestException as e:
            error_msg = f"# 错误: API请求失败: {e}"
            self.log_callback(error_msg + "\n")
            yield error_msg
        except Exception as e:
            error_msg = f"# 错误: 处理分析流时发生未知错误: {e}"
            self.log_callback(error_msg + "\n")
            yield error_msg

    def evaluate_and_refine(self, user_prompt, generated_code, output_dir_path):
        """
        评估生成的结果是否满足用户要求，如果不满足则生成修正后的代码。
        """
        evaluation_system_prompt = """
你是顶级代码审查与需求分析专家。你的任务是严格评估一个AI生成的产物（图表或数据文件）是否【完全满足】用户的原始需求。

**核心评估流程:**
1.  **审查输入**: 我会提供三样东西：
    a. 【用户原始需求】
    b. 【生成结果的Python代码】
    c. 【实际生成的结果】 (可能是一张图片，或是一个数据文件的内容)
2.  **严格比对**: 你必须逐字逐句地比对【用户原始需求】和【实际生成的结果】。检查所有细节，例如：图表类型、标题、坐标轴标签、颜色、数据准确性、数据格式等等。尤其要注意比对字体有无tofu方框情况，出现这种情况说明代码生成后替换是绝对失败需要修改的。
3.  **做出判断并严格按规则回应**:
    *   **如果结果【完美无瑕】，完全符合所有需求**: 你的回应 **必须** 只包含一个单词 `[COMPLETE]`，前后不能有任何其他文字、符号或代码。
    *   **如果结果【存在任何不符之处】**: 你 **必须** 重新生成一段【完整的、修正后的Python代码】来解决所有问题。**【代码质量红线】** 你生成的修正代码必须是可直接执行的、无语法错误的顶级脚本。你的回应中 **绝对不能** 包含 `[COMPLETE]` 这个词，也不要包含任何解释性文字，直接输出修正后的代码块。

**输出要求总结:**
- 完美 -> `[COMPLETE]`
- 不完美 -> (完整的Python代码)
"""
        messages = [{"role": "system", "content": evaluation_system_prompt}]
        content_parts = []

        content_parts.append(
            {"type": "text", "text": f"请根据以下信息评估结果的质量：\n\n【用户原始需求】:\n---\n{user_prompt}\n---\n"})
        content_parts.append(
            {"type": "text", "text": f"【用于生成结果的Python代码】:\n---\n```python\n{generated_code}\n```\n---\n"})

        # 处理生成的结果目录
        if not os.path.exists(output_dir_path) or not os.path.isdir(output_dir_path):
            content_parts.append({
                "type": "text",
                "text": "【实际生成的结果】:\n---\n错误：代码执行后未找到预期的输出目录。\n---"
            })
        else:
            try:
                output_files = os.listdir(output_dir_path)
                if not output_files:
                    content_parts.append({
                        "type": "text",
                        "text": "【实际生成的结果】:\n---\n错误：代码执行后未在输出目录中找到任何文件。\n---"
                    })
                else:
                    content_parts.append({
                        "type": "text",
                        "text": "【实际生成的结果】(在沙箱目录中找到以下文件):\n---"
                    })
                    for filename in output_files:
                        file_path = os.path.join(output_dir_path, filename)
                        mime_type, _ = mimetypes.guess_type(file_path)

                        if mime_type and mime_type.startswith('image/'):
                            base64_image = self._encode_image_to_base64(file_path)
                            if base64_image:
                                content_parts.append({
                                    "type": "text",
                                    "text": f"\n文件「{filename}」 (图片):\n"
                                })
                                content_parts.append({
                                    "type": "image_url",
                                    "image_url": {"url": f"data:{mime_type};base64,{base64_image}"}
                                })
                        else:  # 假设是Excel或其他文本类文件
                            file_text_content = self._get_file_content(file_path)
                            content_parts.append({
                                "type": "text",
                                "text": f"\n文件「{filename}」 (内容):\n---\n```\n{file_text_content}\n```\n---"
                            })
            except Exception as e:
                 content_parts.append({
                    "type": "text",
                    "text": f"【实际生成的结果】:\n---\n错误：在读取输出目录时发生错误: {e}\n---"
                 })

        messages.append({"role": "user", "content": content_parts})

        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": 32768,
        }

        # API调用逻辑与 generate_code 类似
        try:
            self.log_callback("Agent正在评估结果...\n")
            response = requests.post(
                self.base_url, headers=self.headers, data=json.dumps(data), timeout=180
            )
            response.raise_for_status()
            response_data = response.json()

            if not response_data.get('choices') or not response_data['choices'][0].get('message'):
                return ('error', "# 错误: 评估请求的API响应为空。")

            response_text = response_data['choices'][0]['message']['content'].strip()

            if "[COMPLETE]" in response_text:
                self.log_callback("Agent评估完成：结果符合要求。\n")
                return ('complete', None)
            else:
                # 清理代码
                if response_text.startswith("```python"):
                    response_text = response_text[9:]
                if response_text.startswith("```"):
                    response_text = response_text[3:]
                if response_text.endswith("```"):
                    response_text = response_text[:-3]

                self.log_callback("Agent评估完成：结果不符，已生成修正代码。\n")
                return ('refine', response_text.strip())

        except Exception as e:
            return ('error', f"# 错误: Agent评估请求失败: {e}")

    def generate_chat_completion(self, messages, max_tokens=32768):
        """
        通用的聊天补全方法，支持流式输出。
        这个函数现在是一个生成器 (generator)。
        :param messages: 符合OpenAI格式的消息列表。
        :param max_tokens: 最大生成 token 数。
        :yield: AI生成的回复文本块 (delta)。
        """
        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "stream": True  # <-- 核心修改：开启流式传输
        }

        try:
            self.log_callback("正在向AI模型发送流式聊天请求...\n")
            response = requests.post(
                self.base_url,
                headers=self.headers,
                data=json.dumps(data),
                timeout=180,
                stream=True,  # <-- 核心修改：让requests库也处理流
                proxies=None
            )
            response.raise_for_status()

            # 逐行处理服务器发送的事件 (Server-Sent Events)
            for line in response.iter_lines():
                if line:
                    decoded_line = line.decode('utf-8')
                    if decoded_line.startswith('data: '):
                        json_str = decoded_line[6:]
                        if json_str.strip() == '[DONE]':
                            self.log_callback("\n流式响应接收完毕。\n")
                            break
                        try:
                            chunk = json.loads(json_str)
                            if 'choices' in chunk and chunk['choices']:
                                delta = chunk['choices'][0].get('delta', {})
                                content = delta.get('content')
                                if content:
                                    # 使用 yield 产出每一块文本
                                    yield content
                        except json.JSONDecodeError:
                            self.log_callback(f"无法解析流数据块: {json_str}\n")
                            continue

        except requests.exceptions.RequestException as e:
            error_msg = f"# 错误: API请求失败: {e}"
            self.log_callback(error_msg + "\n")
            yield error_msg
        except Exception as e:
            error_msg = f"# 错误: 处理流式响应时发生未知错误: {e}"
            self.log_callback(error_msg + "\n")
            yield error_msg

    def generate_chat_completion_raw(self, messages, max_tokens=32768):
        """
        【新增】非流式的聊天补全方法。
        它在内部调用流式方法并聚合所有结果，最后返回一个完整的字符串。
        这个方法是专门为 Agent 工作流设计的，因为 Agent 需要一次性获得完整回复来进行解析。
        """
        full_response = []
        is_error = False

        # 调用我们现有的流式生成器
        for chunk in self.generate_chat_completion(messages, max_tokens):
            # 检查流的第一个数据块是否为我们定义的错误信息
            if not full_response and chunk.strip().startswith("# 错误:"):
                is_error = True

            full_response.append(chunk)

        # 拼接所有文本块
        final_text = "".join(full_response)

        # 如果是错误，直接返回包含错误信息的完整文本
        # 如果不是错误，也返回完整文本
        return final_text.strip()
