import webview
import pathlib
import os
import sys

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path
from webview_apis import FontManagerApi
from config_manager import ConfigManager  # 导入ConfigManager


# 这个独立的API类将创建自己的ConfigManager实例来操作同一个配置文件
# 从而实现与主程序的解耦
class StandaloneFontManagerApi(FontManagerApi):
    def __init__(self, window: webview.Window = None):
        # 1. 创建独立的ConfigManager实例
        # 注意：这里我们不再需要 self.config_manager = ConfigManager()
        # 因为父类的构造函数会处理它。
        # 我们直接创建一个实例并传递给父类。
        config_manager_instance = ConfigManager()

        # 2. 将这个独立的实例传递给父类
        # 父类的 __init__ 会自动调用 resource_path("字体") 来设置 self.font_dir
        # 和 self.config_manager
        super().__init__(window=window, config_manager=config_manager_instance)


if __name__ == '__main__':
    # +++ 核心修改：将相对路径转换为绝对的 file:// URL +++
    # 1. 使用我们可靠的 resource_path 获取绝对文件路径
    html_path = resource_path("web/font_manager.html")
    # 2. 使用 pathlib 将此路径转换为浏览器可识别的 file:// 格式
    html_url = pathlib.Path(html_path).as_uri()

    print(f"--- [DEBUG] 使用加载URL: {html_url} ---") # 增加调试信息

    # 1. 先创建一个 API 实例。注意此时还没有 window 对象，
    #    所以我们需要在 create_window 之后再把 window 关联上。
    api = StandaloneFontManagerApi(None) # <--- 暂时传入 None

    window = webview.create_window(
        "字体管理",
        html_url,
        width=700,
        height=500,
        resizable=True,
        min_size=(500, 400),
        js_api=api  # <--- 使用标准的 js_api 参数来暴露
    )

    # 2. 窗口创建后，把 window 对象回传给 api 实例
    api.window = window

    webview.start()
