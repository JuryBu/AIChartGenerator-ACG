# webview_apis.py

import os
import json
import webbrowser
import threading
import requests
import zipfile
from utils import resource_path
import base64
import mimetypes
from urllib.parse import urlparse, unquote
from bs4 import BeautifulSoup


class HelpApi:
    """“使用说明”窗口的后端API。"""

    def __init__(self, main_api=None):
        self.main_api = main_api
        self.sections_data = {}  # 存储所有章节数据
        self.section_keys = []  # 存储有序的章节名
        self._load_help_data()

    def _load_help_data(self):
        help_file_path = resource_path("help_content.json")
        try:
            with open(help_file_path, "r", encoding="utf-8") as f:
                self.sections_data = json.load(f)
            if not self.sections_data: raise FileNotFoundError
            self.section_keys = list(self.sections_data.keys())
        except (FileNotFoundError, json.JSONDecodeError):
            default_content = {
                "使用说明": [{"title": "错误", "text": "暂无使用说明...", "image": ""}]
            }
            with open(help_file_path, "w", encoding="utf-8") as f:
                json.dump(default_content, f, indent=2, ensure_ascii=False)
            self.sections_data = default_content
            self.section_keys = list(self.sections_data.keys())

    def _get_page_with_data_url(self, page_data):
        """将单个页面数据中的相对图片路径转换为Base64 URL。"""
        page_data_copy = page_data.copy()
        relative_image_path = page_data_copy.get("image")
        page_data_copy["image_relative_path"] = relative_image_path

        if relative_image_path:
            full_path = resource_path(relative_image_path)
            if os.path.exists(full_path):
                try:
                    mime_type, _ = mimetypes.guess_type(full_path)
                    if not mime_type: mime_type = "application/octet-stream"
                    with open(full_path, "rb") as image_file:
                        encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
                    page_data_copy["image"] = f"data:{mime_type};base64,{encoded_string}"
                except Exception as e:
                    page_data_copy["image"] = ""  # 转换失败
            else:
                page_data_copy["image"] = ""  # 路径不存在
        else:
            page_data_copy["image"] = ""  # 没有图片

        return page_data_copy

    def get_sections(self):
        """返回所有章节的标题列表。"""
        return self.section_keys

    def get_section_content(self, section_key, page_index=0):
        """根据章节名和页面索引获取页面数据。"""
        if section_key not in self.sections_data:
            return None

        pages_in_section = self.sections_data[section_key]
        total_pages = len(pages_in_section)

        if not (0 <= page_index < total_pages):
            return None

        # 获取指定页面的原始数据
        page_data = pages_in_section[page_index]
        # 转换图片为 Base64 并返回
        processed_page_data = self._get_page_with_data_url(page_data)

        return {
            "page_data": processed_page_data,
            "current_page": page_index,
            "total_pages": total_pages,
            "section_key": section_key
        }

    def show_full_size_image(self, relative_path):
        """在系统默认查看器中打开图片。"""
        if not relative_path: return
        try:
            full_path = resource_path(relative_path)
            if os.path.exists(full_path):
                import pathlib
                webbrowser.open(pathlib.Path(full_path).as_uri())
        except Exception as e:
            # --- 修改点 一 ---
            if self.main_api:
                self.main_api.show_alert(f"打开图片失败: {e}", "error")
            else:
                # 备用方案：当没有主API时，直接使用tkinter弹窗
                import tkinter.messagebox
                tkinter.messagebox.showerror("错误", f"打开图片失败: {e}")


class FontManagerApi:
    """“字体管理”窗口的后端API。"""

    # --- 用这个新的 __init__ 方法替换旧的 ---
    def __init__(self, window=None, config_manager=None, main_api=None):
        """
        初始化API，支持多种初始化方式。
        :param window: webview 窗口实例。
        :param config_manager: ConfigManager 实例。
        :param main_api: (可选) 主应用的API实例，用于向下兼容或获取上下文。
        """
        self.main_api = main_api

        # 核心逻辑：优先使用直接传入的参数，否则尝试从 main_api 获取
        self.window = window or (main_api.window if main_api else None)
        self.config_manager = config_manager or (main_api.config_manager if main_api else None)

        # 关键的防御性编程：确保 config_manager 最终被成功设置
        if not self.config_manager:
            raise ValueError("FontManagerApi 必须通过 config_manager 或 main_api 参数来提供一个配置管理器实例。")

        self.font_dir = resource_path("字体")

    def scan_fonts_and_update_config(self):
        """
        扫描字体目录，并与config.json双向同步。
        - 如果文件夹中有新字体，则自动注册到config.json。
        - 如果config.json中的字体文件已不存在，则从中移除。
        """
        config = self.config_manager.config  # 直接使用内存中的配置
        font_dir = self.font_dir

        if not os.path.exists(font_dir):
            os.makedirs(font_dir)
            config['font_mapping'] = {}
            self.config_manager.save()
            return

        disk_fonts = {f for f in os.listdir(font_dir) if f.lower().endswith(('.ttf', '.otf'))}

        font_mapping = config.get('font_mapping', {})
        # 注意：在您的 config_manager 中，值是文件名，不是字典。所以我们这样获取
        registered_font_files = set(font_mapping.values())

        fonts_to_add = disk_fonts - registered_font_files
        fonts_to_remove_from_config = registered_font_files - disk_fonts

        config_changed = False

        if fonts_to_add:
            config_changed = True
            for font_file in fonts_to_add:
                font_name = os.path.splitext(font_file)[0]
                base_name, counter = font_name, 1
                while font_name in font_mapping:
                    font_name = f"{base_name}_{counter}"
                    counter += 1
                font_mapping[font_name] = font_file

        if fonts_to_remove_from_config:
            config_changed = True
            keys_to_delete = [k for k, v in font_mapping.items() if v in fonts_to_remove_from_config]
            for key in keys_to_delete:
                del font_mapping[key]

        if config_changed:
            self.config_manager.save()
            print("字体配置已自动同步并保存。")

    # --- 替换结束 ---

    def get_font_list(self):
        """获取字体列表和推荐下载信息。"""
        if not self.config_manager:
            return {"status": "error", "message": "配置管理器未初始化。"}

        try:
            # 1. 【核心】在获取列表前，先执行同步
            self.scan_fonts_and_update_config()

            # 2. 现在从已同步的配置中读取数据
            font_mapping = self.config_manager.config.get("font_mapping", {})

            # 3. 获取磁盘上的文件列表（现在应该和配置是同步的）
            if not os.path.exists(self.font_dir):
                os.makedirs(self.font_dir)
            font_files = [f for f in os.listdir(self.font_dir) if f.lower().endswith(('.ttf', '.otf'))]

            recommended_fonts = [
                {
                    "name": "思源黑体 (Source Han Sans)",
                    "url": "https://github.com/adobe-fonts/source-han-sans/releases/download/2.004R/SourceHanSansSC.zip",
                    "description": "Adobe出品的开源中文字体，覆盖全面，效果出色。"
                }
            ]

            return {
                "status": "success",
                "installed_fonts": font_files,
                "font_mapping": font_mapping,
                "recommended_fonts": recommended_fonts
            }
        except Exception as e:
            import traceback
            traceback.print_exc()
            return {"status": "error", "message": str(e)}

    def delete_font(self, font_filename):
        """删除字体文件并更新配置。"""
        # --- 修改点 二 (安全检查) ---
        if not self.config_manager:
            return {"status": "error", "message": "配置管理器未初始化。"}

        try:
            os.remove(os.path.join(self.font_dir, font_filename))
            success = self.config_manager.remove_font(font_filename)
            if not success:
                print(f"警告: 字体文件 '{font_filename}' 已删除，但在配置文件中未找到。")

            return {"status": "success", "message": f"'{font_filename}' 已删除。"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def open_browser(self, url):
        """在浏览器中打开URL。"""
        if url:
            webbrowser.open_new_tab(url)

    def _resolve_download_link(self, page_url: str):
        """
        解析给定的URL，尝试找到真实的.zip下载链接。
        :param page_url: 用户输入的URL，可能是页面也可能是直接链接。
        :return: (is_success, result_message_or_url)
        """
        # 规则1：如果链接本身就是zip文件，直接返回
        if page_url.lower().endswith('.zip'):
            return True, page_url

        # 规则2：处理 Google Fonts 的链接
        parsed_url = urlparse(page_url)
        if "fonts.google.com" in parsed_url.netloc:
            # 示例: /specimen/Noto+Sans+SC -> Noto Sans SC
            path_parts = [p for p in parsed_url.path.split('/') if p]
            if path_parts and path_parts[0] == 'specimen':
                font_name_encoded = path_parts[-1]
                font_name = unquote(font_name_encoded).replace('+', ' ')
                # 构造Google Fonts的直接下载链接
                download_url = f"https://fonts.google.com/download?family={font_name}"
                return True, download_url

        # 规则3：通用网页抓取 (作为备用方案)
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
            response = requests.get(page_url, headers=headers, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'lxml')
            # 寻找所有href以.zip结尾的<a>标签
            zip_links = soup.find_all('a', href=lambda href: href and href.lower().endswith('.zip'))
            if zip_links:
                # 返回找到的第一个链接
                return True, zip_links[0]['href']
        except Exception as e:
            print(f"网页抓取失败: {e}")
            # 抓取失败不影响，继续返回错误信息

        return False, "无法从此页面链接中自动找到 .zip 下载地址。请尝试粘贴 .zip 文件的直接链接。"

    def start_download(self, url_from_user):
        """在一个新线程中开始下载和安装字体，并能智能解析URL。"""

        def send_status(message, is_error=False):
            # --- 修改点 二 (安全检查) ---
            if self.window:
                self.window.evaluate_js(f'updateDownloadStatus({json.dumps(message)}, {str(is_error).lower()})')

        try:
            send_status("正在解析链接...", is_error=False)

            # 调用新的解析函数
            is_success, result = self._resolve_download_link(url_from_user)

            if not is_success:
                # 如果解析失败，直接向前端报告错误
                send_status(result, is_error=True)
                return

            # 解析成功，result就是可以直接下载的.zip链接
            direct_zip_url = result
            send_status(f"链接解析成功，准备下载...", is_error=False)

            # 使用解析后的链接启动下载线程
            thread = threading.Thread(target=self._download_and_install, args=(direct_zip_url,), daemon=True)
            thread.start()

        except Exception as e:
            send_status(f"发生未知错误: {e}", is_error=True)

    def _download_and_install(self, url):
        """实际执行下载和安装的函数（在工作线程中运行）。"""

        def send_status(message, is_error=False):
            # --- 修改点 二 (安全检查) ---
            if self.window:
                # 使用window.evaluate_js将状态安全地发送回前端
                # json.dumps确保消息中的特殊字符被正确转义
                self.window.evaluate_js(f'updateDownloadStatus({json.dumps(message)}, {str(is_error).lower()})')

        try:
            send_status("开始下载...")
            zip_path = os.path.join(self.font_dir, "temp_font_download.zip")
            with requests.get(url, stream=True, timeout=60) as r:
                r.raise_for_status()
                with open(zip_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

            send_status("下载完成，正在解压...")
            new_fonts_added = []
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                for member in zip_ref.infolist():
                    if member.is_dir() or not member.filename.lower().endswith(('.ttf', '.otf')):
                        continue
                    # 省略处理重名的复杂逻辑以简化，直接解压
                    zip_ref.extract(member, path=self.font_dir)
                    new_fonts_added.append(os.path.basename(member.filename))

            os.remove(zip_path)

            send_status("更新配置...")
            # --- 修改点 二 (安全检查) ---
            if new_fonts_added and self.config_manager:
                config = self.config_manager.config
                font_mapping = config.get("font_mapping", {})
                for font_file in new_fonts_added:
                    display_name = os.path.splitext(font_file)[0]
                    font_mapping[display_name] = font_file
                self.config_manager.save()

            send_status(f"成功安装 {len(new_fonts_added)} 个新字体！", is_error=False)

            # --- 修改点 二 (安全检查) ---
            if self.window:
                self.window.evaluate_js('refreshFontList()')

        except Exception as e:
            send_status(f"安装失败: {e}", is_error=True)


class PreviewApi:
    """“内容预览”窗口的后端API。"""

    def __init__(self, preview_data: dict, main_api=None):
        """
        初始化API，并存储从启动器传入的预览数据。
        :param preview_data: 包含所有待显示内容的字典。
        :param main_api: 主应用的API实例。
        """
        self.data = preview_data
        self.main_api = main_api
        # --- 新增调试信息 ---
        print("\n--- [DEBUG PreviewApi] ---")
        print("[DEBUG PreviewApi] API已初始化。")
        print(f"[DEBUG PreviewApi] 加载的数据键: {list(self.data.keys())}")
        # --- 结束新增 ---

    def get_preview_data(self):
        """返回存储的预览数据给前端JS。"""
        # --- 新增调试信息 ---
        print("\n--- [DEBUG PreviewApi] get_preview_data 被JS调用 ---")
        print(f"[DEBUG PreviewApi] 准备返回的数据键: {list(self.data.keys())}")
        print("--- [DEBUG PreviewApi] get_preview_data 调用结束 ---")
        # --- 结束新增 ---
        return self.data

    def open_file(self, path: str):
        """在系统默认应用中打开文件。"""
        print(f"[DEBUG PreviewApi] open_file 被JS调用, 路径: {path}")

        # 【核心修改】将传入的路径转换为绝对路径，以增加鲁棒性
        try:
            absolute_path = os.path.abspath(path)
        except Exception:
            # 如果路径本身有问题，无法转换，则直接使用原始路径
            absolute_path = path

        if not absolute_path or not os.path.exists(absolute_path):
            print(f"[DEBUG PreviewApi] 文件路径不存在或为空: {absolute_path}")
            return

        try:
            # 使用绝对路径来打开文件
            webbrowser.open(absolute_path)
        except Exception as e:
            # --- 修改点 三 ---
            if self.main_api:
                self.main_api.show_alert(f"打开文件失败: {e}", "error")
            else:
                # 备用方案：当没有主API时，直接使用tkinter弹窗
                import tkinter.messagebox
                tkinter.messagebox.showerror("错误", f"打开文件失败: {e}")