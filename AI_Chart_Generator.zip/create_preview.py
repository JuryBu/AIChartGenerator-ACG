import sys
import os
import pandas as pd


def create_preview(original_file_path):
    """
    读取一个数据文件，如果行数超过20，则创建一个只包含前20行的预览CSV文件。
    成功时，将预览文件的路径打印到标准输出。
    失败时，将错误信息打印到标准错误。
    """
    try:
        # 确定文件扩展名以选择正确的读取器
        _, extension = os.path.splitext(original_file_path)

        if extension.lower() in ['.xlsx', '.xls']:
            df = pd.read_excel(original_file_path)
        else:  # .csv, .txt 等
            df = pd.read_csv(original_file_path, sep=None, engine='python', on_bad_lines='skip')

        # 只有当行数大于20时才创建预览
        if len(df) > 20:
            preview_df = df.head(20)

            # 构造预览文件名和路径
            original_filename = os.path.basename(original_file_path)
            # 注意：预览文件和原始文件放在同一目录下（即 input/ 目录）
            dir_name = os.path.dirname(original_file_path)
            preview_filename = f"preview_for_{original_filename}.csv"  # 预览文件统一为csv
            preview_filepath = os.path.join(dir_name, preview_filename)

            # 保存预览文件
            preview_df.to_csv(preview_filepath, index=False)

            # 【关键】将成功创建的预览文件路径打印到stdout
            print(preview_filepath)
        else:
            # 如果文件行数不足，不需要预览，打印一个特殊标记
            print("NO_PREVIEW_NEEDED")

    except Exception as e:
        # 【关键】将错误信息打印到stderr
        print(f"Error creating preview for {original_file_path}: {e}", file=sys.stderr)
        sys.exit(1)  # 以非零状态码退出，表示失败


if __name__ == "__main__":
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        create_preview(input_file)
    else:
        print("Usage: python create_preview.py <path_to_data_file>", file=sys.stderr)
        sys.exit(1)