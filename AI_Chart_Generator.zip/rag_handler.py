# rag_handler.py (NEW FILE)

import os
import sys

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import get_app_base_path

models_cache = get_app_base_path('models_cache')
os.environ['HF_HOME'] = models_cache
os.environ['HUGGINGFACE_HUB_CACHE'] = models_cache

# 同样，在这里设置镜像地址，确保运行时如果需要下载，也能走国内镜像
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

import threading
import time
import re
from pathlib import Path


class RAGHandler:
    def __init__(self, model_name='clip-ViT-B-32'):
        """
        【优化】初始化RAG处理器，但**不立即加载模型**。
        """
        print("[RAG] 初始化多模态 RAG Handler (模型将惰性加载)...")
        self.model_name = model_name
        self.model = None
        self.model_lock = threading.Lock()

        # --- 核心修改：为打包和文件系统健壮性做准备 ---
        # 1. 获取应用根目录，确保持久化文件存储在 .exe 旁边
        app_base_path = get_app_base_path()
        self.persistent_files_dir = os.path.join(app_base_path, 'persistent_files')
        os.makedirs(self.persistent_files_dir, exist_ok=True)
        print(f"[RAG] 持久化文件存储已初始化于: {self.persistent_files_dir}")

        # --- 索引 1: 对话文本块索引 (现有) ---
        self.faiss_index = None
        self.vector_dimension = None
        self.chunk_metadata = []
        self.source_documents = []
        self.bm25_index = None
        self.chunk_texts = []

        # --- 索引 2: 持久化文件注意力索引 (新增) ---
        self.file_faiss_index = None
        self.file_vector_dimension = None
        self.file_metadata = [] # 存储每个持久化文件的元数据

        # --- 线程安全 ---
        self._lock = threading.RLock()
        self._is_building_index = False

    def _initialize_model_if_needed(self):
        """
        【内部方法 - 新增】
        检查模型是否已加载，如果未加载，则在线程安全的模式下加载它。
        【优化】: 将 import 语句移入函数内部，以支持 PyInstaller 的 excludes 策略。
        """
        if self.model is None:
            with self.model_lock:
                if self.model is None:
                    print(f"[RAG] 首次需要，正在加载多模态模型: {self.model_name}...")
                    try:
                        # --- LAZY LOADING ---
                        from sentence_transformers import SentenceTransformer
                        self.model = SentenceTransformer(self.model_name)
                        print(f"[RAG] 成功加载多模态模型。")
                    except Exception as e:
                        print(
                            f"[RAG] 错误：无法加载模型 '{self.model_name}'. 错误信息: {e}")

    def preload_model_async(self):
        """
        【公开接口 - 新增】
        在一个单独的后台线程中预加载 SentenceTransformer 模型，
        避免阻塞其他操作，并让首次检索更快。
        """
        if self.model is not None:
            print("[RAG PRELOAD] 模型已经加载，无需预加载。")
            return None # <-- 修改点：明确返回 None

        print("[RAG PRELOAD] 准备在后台线程中预加载模型...")
        preload_thread = threading.Thread(target=self._initialize_model_if_needed, daemon=True)
        preload_thread.start()
        return preload_thread # <-- 核心修改：返回创建的线程对象

    def _extract_text_from_file(self, file_path):
        """
        【内部方法】
        根据文件类型从文件中提取纯文本内容。
        【优化】: 将 import 语句移入函数内部，以支持 PyInstaller 的 excludes 策略。
        """
        try:
            # --- LAZY LOADING ---
            import fitz
            import docx
        except ImportError:
            print("[RAG] 文件处理库 (PyMuPDF/python-docx) 未安装，跳过文件解析。")
            return None, "unsupported"

        path = Path(file_path)
        text_content = ""
        file_type = path.suffix.lower()

        try:
            import docx
            print(f"[RAG] 正在从文件 '{path.name}' 提取内容...")
            if file_type == '.pdf':
                with fitz.open(path) as doc:
                    text_content = "".join(page.get_text() for page in doc)
            elif file_type == '.docx':
                doc = docx.Document(path)
                text_content = "\n".join([para.text for para in doc.paragraphs])
            elif file_type in ['.txt', '.md', '.py', '.js', '.html', '.css', '.json']:
                text_content = path.read_text(encoding='utf-8', errors='ignore')
            else:
                print(f"[RAG] 警告: 不支持的文件类型 '{file_type}'")
                return None, "unsupported"

            print(f"[RAG] 成功提取 {len(text_content)} 字符。")
            return text_content, "file"
        except Exception as e:
            print(f"[RAG] 错误: 解析文件 '{path.name}' 失败: {e}")
            return None, "error"

    def _get_turn_text(self, user_msg, assistant_msg):
        """
        将一个对话回合（用户提问+AI回答）的用户和AI消息整合成一个可供向量化的文档。
        """
        user_content = user_msg.get('content', {})
        user_text = user_content.get('text', '') if isinstance(user_content, dict) else str(user_content)

        assistant_content = assistant_msg.get('content', '')
        assistant_text = str(assistant_content)

        return f"用户提问: {user_text}\nNavi的回答: {assistant_text}"

    def _chunk_text(self, text, chunk_size=200, chunk_overlap=20):
        """
        一个简单的文本分块函数。
        - text: 要分块的文本
        - chunk_size: 每个块的目标大小（字符数）
        - chunk_overlap: 块之间的重叠大小，以保留上下文
        """
        if not text:
            return []

        # 首先尝试按段落分割
        chunks = text.split('\n\n')

        final_chunks = []
        for chunk in chunks:
            if len(chunk) <= chunk_size:
                if chunk.strip():
                    final_chunks.append(chunk.strip())
            else:
                # 如果段落太长，则按句子（或其他标点）分割
                # 这是一个简化的句子分割，可以根据需要用更复杂的库（如nltk）替代
                sentences = re.split(r'(?<=[。？！；.!?;\n])', chunk)
                current_chunk = ""
                for sentence in sentences:
                    if len(current_chunk) + len(sentence) <= chunk_size:
                        current_chunk += sentence
                    else:
                        if current_chunk.strip():
                            final_chunks.append(current_chunk.strip())
                        current_chunk = sentence
                if current_chunk.strip():
                    final_chunks.append(current_chunk.strip())

        return final_chunks

    def process_history_async(self, chat_history):
        """
        【公开接口】
        异步处理整个聊天历史记录，构建初始的向量索引。
        此方法会立即返回，索引构建在后台线程中进行，避免阻塞主线程。
        """
        # 注意：这里的逻辑稍微调整，我们总是启动线程，让线程内部去处理模型是否加载的问题
        if self._is_building_index:
            print("[RAG] 索引正在构建中，请勿重复调用。")
            return None # <-- 修改点：明确返回 None

        print("[RAG] 准备在后台线程中处理历史记录...")
        # 使用 deepcopy 防止在遍历时 chat_history 被其他线程修改
        from copy import deepcopy
        history_copy = deepcopy(chat_history)

        thread = threading.Thread(target=self._build_index_background, args=(history_copy,), daemon=True)
        thread.start()
        return thread # <-- 核心修改：返回创建的线程对象

    def _build_index_background(self, chat_history):
        """
        【内部方法 - 重大修改】
        在后台线程中运行，为历史内容构建**双索引系统**：
        1. 对话文本块索引 (用于上下文检索)
        2. 持久化文件索引 (用于文件注意力)
        【优化】: 将所有 import 移入内部，并处理文件持久化。
        """
        self._initialize_model_if_needed()
        if not self.model:
            print("[RAG] 模型加载失败，无法构建索引。")
            return

        with self._lock:
            self._is_building_index = True

        print("[RAG] 后台任务开始：构建双索引系统...")
        start_time = time.time()

        # --- LAZY LOADING ---
        from PIL import Image
        import shutil
        import uuid
        import mimetypes

        # --- 清理和准备工作 ---
        # 1. 清空持久化文件目录，确保与当前历史记录同步
        if os.path.exists(self.persistent_files_dir):
            shutil.rmtree(self.persistent_files_dir)
        os.makedirs(self.persistent_files_dir, exist_ok=True)

        # 2. 准备临时数据容器
        # 用于对话索引
        chunks_to_embed = []
        chunks_for_bm25 = []
        temp_chunk_metadata = []
        temp_source_documents = []
        # 用于文件索引
        files_to_embed = []
        temp_file_metadata = []

        # 3. 遍历历史记录，填充容器
        for msg_idx, msg in enumerate(chat_history):
            content = msg.get('content', {})
            if not isinstance(content, dict) or msg.get('role') != 'user':
                continue

            user_text_content = content.get('text', '')

            # a. 处理文件 (非图片)
            for file_path in content.get('files', []):
                if not os.path.exists(file_path): continue

                # --- 文件持久化 ---
                unique_filename = f"{uuid.uuid4().hex}_{os.path.basename(file_path)}"
                persistent_path = os.path.join(self.persistent_files_dir, unique_filename)
                shutil.copy(file_path, persistent_path)

                # --- [核心修改] ---
                mime_type, _ = mimetypes.guess_type(file_path)
                if not mime_type: mime_type = 'application/octet-stream'  # 提供一个默认值
                # --- [修改结束] ---

                file_text, status = self._extract_text_from_file(persistent_path)
                if file_text:
                    # 为文件索引添加数据
                    files_to_embed.append(file_text)  # 整个文件内容作为向量
                    temp_file_metadata.append({
                        "persistent_path": persistent_path,
                        "original_name": os.path.basename(file_path),
                        "type": "file",
                        "mime_type": mime_type,  # <-- [新增] 存储MIME类型
                        "associated_msg_idx": msg_idx,
                        "associated_text": user_text_content
                    })

                    # 为对话索引添加数据 (分块)
                    source_doc_index = len(temp_source_documents)
                    temp_source_documents.append({"type": "file", "path": file_path, "original_msg_idx": msg_idx})
                    chunks = self._chunk_text(file_text)
                    for chunk_text in chunks:
                        chunks_to_embed.append(chunk_text)
                        chunks_for_bm25.append(chunk_text)
                        temp_chunk_metadata.append({"source_doc_index": source_doc_index})

            # b. 处理图片
            for image_path in content.get('images', []):
                if not os.path.exists(image_path): continue

                try:
                    # --- 图片持久化 ---
                    unique_filename = f"{uuid.uuid4().hex}_{os.path.basename(image_path)}"
                    persistent_path = os.path.join(self.persistent_files_dir, unique_filename)
                    shutil.copy(image_path, persistent_path)

                    # --- [核心修改] ---
                    mime_type, _ = mimetypes.guess_type(image_path)
                    if not mime_type: mime_type = 'image/png'  # 提供一个默认值
                    # --- [修改结束] ---

                    img = Image.open(persistent_path)

                    # 为文件索引添加数据
                    files_to_embed.append(img)
                    temp_file_metadata.append({
                        "persistent_path": persistent_path,
                        "original_name": os.path.basename(image_path),
                        "type": "image",
                        "mime_type": mime_type,  # <-- [新增] 存储MIME类型
                        "associated_msg_idx": msg_idx,
                        "associated_text": user_text_content
                    })

                    # 为对话索引添加数据 (图片本身，不分块)
                    source_doc_index = len(temp_source_documents)
                    temp_source_documents.append({"type": "image", "path": image_path, "original_msg_idx": msg_idx})
                    chunks_to_embed.append(img)
                    chunks_for_bm25.append("") # BM25无内容
                    temp_chunk_metadata.append({"source_doc_index": source_doc_index})
                except Exception as e:
                    print(f"[RAG] 错误: 无法加载或持久化图片 '{image_path}': {e}")

            # c. 处理对话回合
            if user_text_content and (msg_idx + 1) < len(chat_history):
                next_msg = chat_history[msg_idx + 1]
                if next_msg.get('role') == 'assistant':
                    turn_text = self._get_turn_text(msg, next_msg)
                    source_doc_index = len(temp_source_documents)
                    temp_source_documents.append({
                        "type": "turn", "text": turn_text, "original_msg_idx": msg_idx,
                        "assistant_msg_idx": msg_idx + 1
                    })
                    chunks = self._chunk_text(turn_text)
                    for chunk_text in chunks:
                        chunks_to_embed.append(chunk_text)
                        chunks_for_bm25.append(chunk_text)
                        temp_chunk_metadata.append({"source_doc_index": source_doc_index})

        # 4. 向量化和索引构建
        try:
            # --- LAZY LOADING ---
            from rank_bm25 import BM25Okapi
            import jieba
            import numpy as np
            import faiss

            # a. 构建对话索引
            chunk_embeddings = None
            bm25 = None
            if chunks_to_embed:
                print(f"[RAG] 正在为 {len(chunks_to_embed)} 个对话块生成向量...")
                chunk_embeddings = self.model.encode(chunks_to_embed, convert_to_tensor=False, show_progress_bar=True)
                print("[RAG] 正在构建 BM25 关键词索引...")
                tokenized_corpus = [list(jieba.lcut(chunk)) for chunk in chunks_for_bm25]
                bm25 = BM25Okapi(tokenized_corpus)

            # b. 构建文件索引
            file_embeddings = None
            if files_to_embed:
                print(f"[RAG] 正在为 {len(files_to_embed)} 个持久化文件生成向量...")
                file_embeddings = self.model.encode(files_to_embed, convert_to_tensor=False, show_progress_bar=True)

        except Exception as e:
            print(f"[RAG] 错误: 在构建索引时发生异常: {e}")
            with self._lock: self._is_building_index = False
            return

        # 5. 获取锁并安全地更新所有数据结构
        with self._lock:
            # 更新对话索引
            if chunk_embeddings is not None:
                chunk_embeddings = np.array(chunk_embeddings).astype('float32')
                faiss.normalize_L2(chunk_embeddings)
                d = chunk_embeddings.shape[1]
                self.vector_dimension = d
                index = faiss.IndexFlatIP(d)
                index.add(chunk_embeddings)
                self.faiss_index = index
            self.chunk_metadata = temp_chunk_metadata
            self.source_documents = temp_source_documents
            self.chunk_texts = chunks_for_bm25
            self.bm25_index = bm25

            # 更新文件索引
            if file_embeddings is not None:
                file_embeddings = np.array(file_embeddings).astype('float32')
                faiss.normalize_L2(file_embeddings)
                d = file_embeddings.shape[1]
                self.file_vector_dimension = d
                index = faiss.IndexFlatIP(d)
                index.add(file_embeddings)
                self.file_faiss_index = index
            self.file_metadata = temp_file_metadata

            self._is_building_index = False

        end_time = time.time()
        print(f"[RAG] 双索引构建完成！对话块: {len(self.chunk_metadata)}, 持久化文件: {len(self.file_metadata)}, 耗时 {end_time - start_time:.2f} 秒。")

    def find_relevant_context(self, query_text, top_k=5, threshold=0.7, rrf_k=60):
        """
        【公开接口】
        使用混合搜索（向量+BM25）和RRF融合策略，查找最相关的历史对话回合。
        """
        # 【新增】在使用模型前，确保它已被加载
        self._initialize_model_if_needed()
        if not self.model or self.faiss_index is None or not self.chunk_metadata:
            return []

        if self._is_building_index:
            print("[RAG] 警告: 索引正在后台构建中，本次检索结果可能不完整。")

        with self._lock:
            if self.faiss_index is None or not self.chunk_metadata:
                return []

            # --- 1. 向量搜索 (使用 FAISS) ---

            import faiss
            query_vector = self.model.encode(query_text, convert_to_tensor=False)

            # a. 准备FAISS输入
            query_vector = query_vector.reshape(1, -1).astype('float32')
            faiss.normalize_L2(query_vector)

            # b. 执行高效的ANN搜索
            search_k = min(self.faiss_index.ntotal, top_k * 2)  # 避免k大于索引中的向量总数
            vector_scores, vector_top_indices = self.faiss_index.search(query_vector, search_k)

            # c. 处理FAISS输出
            vector_scores = vector_scores.flatten()
            vector_top_indices = vector_top_indices.flatten()

            # --- 2. BM25 关键词搜索 ---
            bm25_scores = None
            import jieba
            if self.bm25_index and jieba:
                import numpy as np
                tokenized_query = list(jieba.lcut(query_text))
                bm25_scores = self.bm25_index.get_scores(tokenized_query)
                bm25_top_indices = np.argsort(bm25_scores)[-top_k * 2:][::-1]  # 取更多结果用于融合

            # --- 3. RRF 倒数排序融合 ---
            # RRF公式: score(d) = sum(1 / (k + rank(d)))
            rrf_scores = {}

            for rank, idx in enumerate(vector_top_indices):
                # 【关键修复】: 应该用 rank 来访问 scores 数组, 因为 scores 和 top_indices 是并列的
                if vector_scores[rank] > 0.5:  # 基础相关性过滤  <-- 已修复
                    if idx not in rrf_scores:
                        rrf_scores[idx] = 0
                    rrf_scores[idx] += 1 / (rrf_k + rank)

            # 处理BM25搜索结果
            if bm25_scores is not None:
                for rank, idx in enumerate(bm25_top_indices):
                    if bm25_scores[idx] > 0:  # 基础相关性过滤
                        if idx not in rrf_scores:
                            rrf_scores[idx] = 0
                        rrf_scores[idx] += 1 / (rrf_k + rank)

            if not rrf_scores:
                return []

            # 根据RRF分数对【块】进行最终排序
            sorted_chunk_indices = sorted(rrf_scores.keys(), key=lambda idx: rrf_scores[idx], reverse=True)

            # --- 4. 结果去重与格式化 (多模态适配) ---
            relevant_docs = {}
            final_top_k = top_k  # 最终返回的源文档数

            for idx in sorted_chunk_indices:
                if len(relevant_docs) >= final_top_k:
                    break

                chunk_meta = self.chunk_metadata[idx]
                # 'turn_index' 变为 'source_doc_index'
                source_doc_index = chunk_meta['source_doc_index']

                # 使用 RRF 分数作为该源文档的代表分数
                score = rrf_scores[idx]

                # 按 source_doc_index 进行去重
                if source_doc_index not in relevant_docs:
                    # 从 self.source_documents 获取源信息
                    doc_info = self.source_documents[source_doc_index].copy()
                    doc_info['score'] = score
                    relevant_docs[source_doc_index] = doc_info

            # 按分数对去重后的源文档进行排序
            sorted_docs = sorted(relevant_docs.values(), key=lambda x: x['score'], reverse=True)
            return sorted_docs

    def find_relevant_files(self, query_text, top_k=5, threshold=0.75):
        """
        【公开接口 - 新增】
        使用文件注意力索引，查找与用户问题最相关的历史文件。
        """
        self._initialize_model_if_needed()
        if not self.model or self.file_faiss_index is None or not self.file_metadata:
            return []

        if self._is_building_index:
            print("[RAG] 警告: 文件索引正在构建中，本次文件检索可能不完整。")

        with self._lock:
            if self.file_faiss_index is None or not self.file_metadata:
                return []

            try:
                # --- LAZY LOADING ---
                import faiss
                import numpy as np

                # 1. 向量化查询
                query_vector = self.model.encode(query_text, convert_to_tensor=False)
                query_vector = np.array(query_vector).reshape(1, -1).astype('float32')
                faiss.normalize_L2(query_vector)

                # 2. 搜索文件索引
                search_k = min(self.file_faiss_index.ntotal, top_k)
                if search_k == 0: return []

                scores, indices = self.file_faiss_index.search(query_vector, search_k)

                # 3. 过滤和格式化结果
                relevant_files = []
                for i in range(len(indices[0])):
                    idx = indices[0][i]
                    score = scores[0][i]

                    if score >= threshold:
                        metadata = self.file_metadata[idx].copy()
                        metadata['score'] = score
                        relevant_files.append(metadata)

                return relevant_files
            except Exception as e:
                print(f"[RAG] 文件相关性搜索失败: {e}")
                return []

    def add_message_async(self, message, message_idx):
        """
        【公开接口 - 新】
        异步地向索引中添加一条新的消息（可以是用户或AI的）。
        这个方法将取代旧的 add_turn_async。
        """
        if not self.model:
            return

        from copy import deepcopy
        message_copy = deepcopy(message)

        thread = threading.Thread(
            target=self._add_message_background,
            args=(message_copy, message_idx),
            daemon=True
        )
        thread.start()

    def _add_message_background(self, msg, msg_idx):
        """
        【内部方法 - 新】
        在后台安全地处理并添加单条消息到多模态索引中。
        """
        # 【新增】在使用模型前，确保它已被加载
        self._initialize_model_if_needed()
        if not self.model:
            print("[RAG] 模型未加载，无法增量添加消息。")
            return

        content_to_embed = []
        chunks_for_bm25 = []
        new_chunk_metadata = []
        new_source_documents = []

        content = msg.get('content', {})
        if not isinstance(content, dict) or msg.get('role') != 'user':
            # 当前逻辑只索引用户上传的丰富内容，可按需扩展
            # 我们也可以把AI的回答作为一种'turn'来索引，但目前简化处理
            return

        # 1. 解析消息内容，与 _build_index_background 中的逻辑类似
        # a. 处理文件
        for file_path in content.get('files', []):
            file_text, status = self._extract_text_from_file(file_path)
            if file_text:
                new_source_documents.append({
                    "type": "file", "path": file_path, "original_msg_idx": msg_idx
                })
                chunks = self._chunk_text(file_text)
                for chunk_text in chunks:
                    content_to_embed.append(chunk_text)
                    chunks_for_bm25.append(chunk_text)

        # b. 处理图片
        for image_path in content.get('images', []):
            try:
                from PIL import Image
                img = Image.open(image_path)
                new_source_documents.append({
                    "type": "image", "path": image_path, "original_msg_idx": msg_idx
                })
                content_to_embed.append(img)
                chunks_for_bm25.append("")
            except Exception as e:
                print(f"[RAG] 错误: 增量添加时无法加载图片 '{image_path}': {e}")

        # c. 处理文本 (注意: 这里简化为只处理用户消息文本，而非对话回合)
        if content.get('text'):
            # 如果需要，可以修改这里以包含AI回答，形成对话回合
            text = content.get('text', '')
            new_source_documents.append({
                "type": "text", "text": text, "original_msg_idx": msg_idx
            })
            chunks = self._chunk_text(text)
            for chunk_text in chunks:
                content_to_embed.append(chunk_text)
                chunks_for_bm25.append(chunk_text)

        if not content_to_embed:
            return

        # 2. 向量化
        new_vectors = self.model.encode(content_to_embed, convert_to_tensor=False)

        with self._lock:
            while self._is_building_index:
                time.sleep(0.1)

            # 3. 更新所有数据结构
            source_doc_start_index = len(self.source_documents)
            self.source_documents.extend(new_source_documents)

            for i in range(len(content_to_embed)):
                # 动态计算每个块的 source_doc_index
                # 注意：这个简化的实现假设 new_source_documents 的顺序与 content_to_embed 对应
                # 这是一个需要小心处理的地方，但对于当前逻辑是成立的。
                # 一个更鲁棒的实现会为每个块创建更详细的元数据。
                doc_idx = source_doc_start_index + i  # 简化处理，实际可能需要更复杂的映射
                new_chunk_metadata.append({"source_doc_index": doc_idx})

            self.chunk_metadata.extend(new_chunk_metadata)
            self.chunk_texts.extend(chunks_for_bm25)

            import faiss

            # 4. 更新 FAISS 索引
            if faiss:
                import numpy as np
                new_vectors = np.array(new_vectors).astype('float32')
                faiss.normalize_L2(new_vectors)
                if self.faiss_index is None:
                    self.vector_dimension = new_vectors.shape[1]
                    self.faiss_index = faiss.IndexFlatIP(self.vector_dimension)
                self.faiss_index.add(new_vectors)

            from rank_bm25 import BM25Okapi
            import jieba

            # 5. 重建 BM25 索引 (注意：对于频繁更新，这不是最高效的方式，但最简单可靠)
            if BM25Okapi and jieba:
                tokenized_corpus = [list(jieba.lcut(chunk)) for chunk in self.chunk_texts if chunk]
                self.bm25_index = BM25Okapi(tokenized_corpus)

            print(f"[RAG] 消息 {msg_idx} 的 {len(content_to_embed)} 个内容项已添加到多模态索引。")
