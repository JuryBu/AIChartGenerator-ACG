import webview
import pathlib

import os
import sys

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path
from webview_apis import HelpApi

# 注意：HelpApi不再需要main_app实例，我们给它传一个None
# 因为它所有的操作（读json，打开本地图片）都不需要与主窗口交互。

class StandaloneHelpApi(HelpApi):
    def __init__(self):
        super().__init__()

if __name__ == '__main__':
    api = StandaloneHelpApi()

    # 使用 resource_path 获取绝对路径，并转换为标准的 file:// URL
    # 这是加载本地网页内容的最佳实践，可确保在开发和打包后都能正常工作
    html_path = resource_path("web/help.html")
    html_url = pathlib.Path(html_path).as_uri()

    webview.create_window(
        "使用说明",
        html_url,  # <-- 使用生成的标准化URL
        js_api=api,
        width=800,
        height=600,
        resizable=True,
        min_size=(600, 400)
    )
    webview.start()
