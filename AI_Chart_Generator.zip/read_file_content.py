import sys
import os
import pandas as pd


def read_and_convert_to_csv(filepath):
    """
    使用 pandas 读取多种格式的文件，并将其内容作为CSV格式的字符串返回。
    """
    try:
        ext = os.path.splitext(filepath)[1].lower()

        # 对 Excel 文件使用 pd.read_excel
        if ext in ['.xlsx', '.xls']:
            df = pd.read_excel(filepath, engine='openpyxl')
            return df.to_csv(index=False)

        # 对 CSV 文件使用更健壮的读取逻辑
        elif ext == '.csv' or os.path.basename(filepath).startswith("preview_for_"):
            try:
                # 优先尝试 UTF-8
                df = pd.read_csv(filepath)
            except UnicodeDecodeError:
                # 失败则尝试 GBK
                df = pd.read_csv(filepath, encoding='gbk')
            return df.to_csv(index=False)

        # 对其他文本文件 (.txt等) 也尝试多种编码
        else:
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    return f.read()
            except UnicodeDecodeError:
                with open(filepath, 'r', encoding='gbk', errors='ignore') as f:
                    return f.read()

    except Exception as e:
        # 将错误信息输出到 stderr，这样主进程可以捕获它
        print(f"Error reading file {os.path.basename(filepath)}: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        file_path_arg = sys.argv[1]
        content_str = read_and_convert_to_csv(file_path_arg)
        # 将成功读取的内容输出到 stdout
        print(content_str)
    else:
        print("Usage: python read_file_content.py <path_to_file>", file=sys.stderr)
        sys.exit(1)