import sys
import os
import pandas as pd


def read_and_convert_to_csv(filepath):
    """
    使用 pandas 读取多种格式的文件，并将其内容作为CSV格式的字符串返回。
    """
    try:
        # 预览文件总是CSV格式
        if os.path.basename(filepath).startswith("preview_for_"):
            df = pd.read_csv(filepath)
            return df.to_csv(index=False)

        # 根据扩展名处理其他文件
        ext = os.path.splitext(filepath)[1].lower()
        if ext in ['.xlsx', '.xls']:
            df = pd.read_excel(filepath, engine='openpyxl')
            return df.to_csv(index=False)
        else:  # .txt, .csv, and others default to text reading
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()

    except Exception as e:
        # 将错误信息输出到 stderr，这样主进程可以捕获它
        print(f"Error reading file {os.path.basename(filepath)}: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        file_path_arg = sys.argv[1]
        content_str = read_and_convert_to_csv(file_path_arg)
        # 将成功读取的内容输出到 stdout
        print(content_str)
    else:
        print("Usage: python read_file_content.py <path_to_file>", file=sys.stderr)
        sys.exit(1)