# navigator.py (FIXED)

import webview
import threading
import json
import re
import markdown
from http.server import SimpleHTTPRequestHandler
from pathlib import Path
from functools import partial
import socketserver
import hashlib
import base64
import uuid
import time
import socket
from html2image import Html2Image
import tempfile
import os
import sys

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

import config
from rag_handler import RAGHandler
from agent import CodeExecutionAgent
from llm_service import LLMService
from utils import get_project_structure
from constants import INPUT_DIR
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'

MD_EXTENSIONS = [
    'pymdownx.highlight',
    'pymdownx.superfences',
    'markdown.extensions.tables',
    'markdown.extensions.fenced_code',
]
MD_EXTENSION_CONFIGS = {
    'pymdownx.highlight': {'use_pygments': False}, # 告诉扩展不要在后端高亮，留给前端Prism.js
    'markdown.extensions.fenced_code': {'lang_prefix': 'language-'}, # 确保 ```python 变为 class="language-python"
}
md_converter = markdown.Markdown(extensions=MD_EXTENSIONS, extension_configs=MD_EXTENSION_CONFIGS)


# --- 资源服务器 (No changes needed here) ---
class VerboseCorsRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        SimpleHTTPRequestHandler.end_headers(self)

    # 【DEBUG】: 恢复日志记录功能，这样我们就能在终端看到GET请求
    def log_message(self, format, *args):
        print(f"[HTTP SERVER LOG] - ", end="")
        super().log_message(format, *args)


def start_asset_server(directory):
    """在一个后台线程中启动一个HTTP服务器来提供指定目录的文件"""
    print(f"DEBUG: 准备启动资源服务器，服务的目录是: {directory}") #【DEBUG】
    port = 8001
    while True:
        try:
            # 【DEBUG】: 使用我们新的 VerboseCorsRequestHandler
            handler = partial(VerboseCorsRequestHandler, directory=str(directory))
            httpd = socketserver.TCPServer(("", port), handler)
            break
        except OSError:
            port += 1
            if port > 9000:
                print("DEBUG: 错误！无法在8001-9000端口范围内找到可用端口。")
                return None

    print(f"DEBUG: 本地资源服务器已在 http://localhost:{port} 启动") #【DEBUG】

    thread = threading.Thread(target=httpd.serve_forever)
    thread.daemon = True
    thread.start()
    return port


# --- Markdown与LaTeX处理 (No changes needed here) ---
def hide_math_from_markdown(text):
    """
    使用哈希占位符，将所有KaTeX公式从Markdown文本中暂时移除。
    这与 test.py 的行为一致。
    """
    math_map = {}

    def replacer(match):
        block = match.group(0)
        # 使用内容的哈希值作为唯一的key
        key = hashlib.md5(block.encode()).hexdigest()
        # 【核心修改】: 使用一个纯文本、非HTML的占位符
        # 这样 Markdown 解析器就不会转义它
        placeholder = f"MATH_PLACEHOLDER_{key}"
        math_map[key] = block
        return placeholder

    # 【核心修正】: 允许 \(...\) 内部包含括号
    # 将原来的 \\\([^\)]*?\\\)  修改为  \\\([\s\S]*?\\\)
    math_pattern = re.compile(r"(\$\$[\s\S]*?\$\$|\$[^\$]*?\$|\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\))", re.DOTALL)

    processed_text = math_pattern.sub(replacer, text)
    return processed_text, math_map


def restore_math_in_html(html, math_map):
    """
    在HTML文本中，将纯文本占位符替换为包含KaTeX公式的<span>标签。
    这是最健壮的做法。
    """
    for key, block in math_map.items():
        # 【核心修改】: 定位纯文本占位符
        placeholder_text = f"MATH_PLACEHOLDER_{key}"
        # 【核心修改】: 构建我们最终想要的、完整的HTML标签
        replacement_html = f'<span class="math-placeholder">{block}</span>'
        # 在HTML中进行替换
        html = html.replace(placeholder_text, replacement_html)
    return html


def preprocess_latex_code_blocks(text):
    """将 ```latex ... ``` 代码块转换为 $$ ... $$ 数学块。"""
    # 使用非贪婪模式匹配 (.*?) 来捕获代码块内容
    pattern = re.compile(r"```latex\s*([\s\S]*?)\s*```", re.DOTALL)

    # 替换为 $$...$$ 格式，\1 代表第一个捕获组的内容
    replacement = r"$$\1$$"

    return pattern.sub(replacement, text)


def markdown_to_html_with_math(text_content):
    """一个集成的函数，处理从Markdown到最终HTML的完整转换"""
    # --- 在所有处理之前，先进行预处理 ---
    normalized_text = preprocess_latex_code_blocks(text_content)
    # ----------------------------------------------------
    # 后续流程使用预处理过的文本
    md_text, math_map = hide_math_from_markdown(normalized_text)
    html = md_converter.convert(md_text)
    restored_html = restore_math_in_html(html, math_map)
    md_converter.reset()
    return restored_html


# --- 核心后端API ---
class Api:
    def __init__(self):
        self.base_url = ""
        self._window = None
        self.chat_history = []
        self.stop_generation_flag = False
        self.is_generating = False
        self.rag_handler = RAGHandler()

        self.llm_service = None
        self.agent = None
        self.is_configured = False

        try:
            app_config = config.load_config()

            # 1. 从 config.json 中获取实际的 api_type (例如 'external')
            api_type = app_config.get("api_type", "external")
            # 2. 根据 api_type 构建对应的配置字典键 (例如 'external_api')
            api_details_key = f"{api_type}_api"
            # 3. 使用这个键来获取正确的API配置字典
            active_api_config = app_config.get(api_details_key, {})
            # 4. 从这个正确的字典中获取 base_url
            base_url = active_api_config.get("base_url", "").strip()

            if base_url:
                # 只有在URL有效时才实例化服务
                # LLMService 内部有自己的逻辑来解析完整的 app_config，所以直接传递即可
                self.llm_service = LLMService(app_config, log_callback=lambda msg: print(msg, end=""))
                self.agent = CodeExecutionAgent(self.llm_service)
                self.is_configured = True
                print("[Navigator] LLM服务初始化成功。")
            else:
                # 如果URL无效，只打印日志，is_configured 标志保持 False
                print("[Navigator] 错误: 无法从配置中找到有效的 API URL。Navi功能将受限。")

        except Exception as e:
            print(f"初始化LLM服务时发生未知错误: {e}")
            self.is_configured = False  # 任何异常都视为未配置成功

        self.first_chunk_received = False
        self.current_stream_full_content = ""

    def set_window(self, window):
        # FIX 2: Update the setter method
        self._window = window

    def on_loaded(self):
        """当webview加载完成时，此函数现在什么都不做，等待JS的信号"""
        pass

    # --- 以下是暴露给JavaScript的函数 ---

    def _load_history(self):
        try:
            with open("navigator_history.json", 'r', encoding='utf-8') as f:
                self.chat_history = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.chat_history = []

        # --- [核心修改] ---
        # 如果历史记录为空，根据配置状态显示不同的初始消息
        if not self.chat_history:
            if self.is_configured:
                # 配置正常，显示欢迎语
                self.chat_history.append({
                    "role": "assistant",
                    "content": "你好，我是Navi，你的智能助手。有什么可以帮你的吗？"
                })
            else:
                # 未配置，显示错误和引导信息
                self.chat_history.append({
                    "role": "assistant",
                    "content": "### 初始化错误\n\n我无法连接到大模型服务，因为**API URL尚未在主程序中配置**。\n\n请返回主界面，在任意工作区的 **“模型设置”** 中填写并保存有效的API URL，然后重新打开我。"
                })
        # --- [修改结束] ---

    def _save_history(self):
        try:
            with open("navigator_history.json", 'w', encoding='utf-8') as f:
                json.dump(self.chat_history, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"保存历史记录出错: {e}")

    def javascript_is_ready(self):
        """由JS在准备就绪后调用，启动后台初始化"""
        print("\nDEBUG: Python后端接收到来自JS的 'javascript_is_ready' 信号！握手成功。\n")
        # 启动一个后台线程来加载数据，避免阻塞
        threading.Thread(target=self._initialize_backend, daemon=True).start()

    def _initialize_backend(self):
        """
        【内部方法 - 新增】
        在后台线程中执行所有耗时的初始化操作，并向前端发送进度。
        """
        self._send_to_js({'event': 'update_loading_progress', 'progress': 10})
        self._load_history()
        self._send_to_js({'event': 'update_loading_progress', 'progress': 40})

        # --- 核心修改：捕获线程对象 ---
        model_thread = self.rag_handler.preload_model_async()
        self._send_to_js({'event': 'update_loading_progress', 'progress': 60})

        # --- 核心修改：捕获线程对象 ---
        # 注意：process_history_async 内部会等待模型加载，所以这两个可以并行启动
        index_thread = self.rag_handler.process_history_async(self.chat_history)
        self._send_to_js({'event': 'update_loading_progress', 'progress': 70})

        messages_data = [self._prepare_message_for_js(msg, i) for i, msg in enumerate(self.chat_history)]
        self._send_to_js({'event': 'load_history', 'messages': messages_data})

        # --- 核心修改：添加等待逻辑 ---
        if model_thread:
            model_thread.join() # 阻塞，直到模型加载线程结束
            self._send_to_js({'event': 'update_loading_progress', 'progress': 85})

        if index_thread:
            index_thread.join() # 阻塞，直到索引构建线程结束
            self._send_to_js({'event': 'update_loading_progress', 'progress': 95})
        # --- 修改结束 ---

        self._send_to_js({'event': 'update_loading_progress', 'progress': 100})
        time.sleep(0.5)

        self._send_to_js({'event': 'initialization_complete'})

    def _prepare_message_for_js(self, message, index):
        """将Python端的历史消息格式化为JS端需要的格式"""
        role = message.get("role")
        content = message.get("content", "")
        message_id = f"history-msg-{index}"

        raw_text = ""
        raw_md = ""
        content_html = ""

        if isinstance(content, dict):
            # 处理用户发送的包含引用的消息
            raw_text = content.get("text", "")
            raw_md = content.get("markdown", "")
            content_html = markdown_to_html_with_math(raw_text) # 用户消息直接显示纯文本
        else:
            # 处理助手或不含引用的纯文本消息
            raw_text = content
            raw_md = content
            content_html = markdown_to_html_with_math(content)

        # 【核心修正】
        # 1. 无条件地创建基础的 options 字典。这确保了它总是存在的。
        options = {
            "messageId": message_id,
            "rawText": raw_text,
            "rawMd": raw_md,
            "isHistory": True
        }

        # 2. 如果消息中包含有效的 'replyInfo'，再向已经存在的 options 字典中添加键值对。
        if 'replyInfo' in message and message.get('replyInfo', {}).get('ids'):
            options['replyInfo'] = message['replyInfo']

        # 3. 返回最终组装好的数据。这里的 'options' 变量现在可以安全使用。
        return {
            "role": role,
            "contentHTML": content_html,
            "options": options
        }

    # --- 以下是暴露给JavaScript的函数 ---

    def send_message(self, user_input, attached_files, quoted_messages):
        """由JS调用，处理用户发送的消息(现在包含Base64文件)"""
        if self.is_generating: return

        # --- [核心修改] ---
        # 在函数开头增加一道运行时防线
        if not self.is_configured:
            self._send_to_js({'event': 'show_alert', 'content': '错误：API未配置，无法发送消息。请先在主程序中设置API URL。'})
            # self.is_generating 状态在前面已经检查过了，这里不需要再设置
            return
        # --- [修改结束] ---

        self.is_generating = True

        processed_attachments = []
        for file_data in attached_files:
            try:
                # 1. 解码 Base64 内容
                header, encoded = file_data['content'].split(",", 1)
                decoded_content = base64.b64decode(encoded)

                # 2. 创建一个唯一的文件名以避免冲突
                original_name = file_data['name']
                name, ext = os.path.splitext(original_name)
                unique_filename = f"{name}_{uuid.uuid4().hex[:8]}{ext}"
                server_filepath = os.path.join(INPUT_DIR, unique_filename)

                # 3. 将解码后的内容写入服务器上的文件
                with open(server_filepath, "wb") as f:
                    f.write(decoded_content)

                print(f"DEBUG: 文件 '{original_name}' 已保存到服务器: '{server_filepath}'")

                # 4. 创建一个新的字典，包含服务器路径，用于LLM处理
                processed_attachments.append({
                    "name": original_name,  # 保留原始文件名用于显示
                    "path": server_filepath,  # <-- 这是关键，提供给LLMService的服务器端路径
                    "type": file_data['type']
                })

            except Exception as e:
                print(f"错误: 处理上传的文件 '{file_data.get('name', '未知文件')}' 失败: {e}")

        # --- 【核心修改】: 将附件分类为图片和文件 ---
        user_files = []
        user_images = []
        for attachment in processed_attachments:
            # 根据MIME类型判断
            if attachment.get('type', '').startswith('image/'):
                user_images.append(attachment['path'])
            else:
                user_files.append(attachment['path'])

        # 使用新的、更丰富的格式构建消息
        user_message_content = {
            "text": user_input,
            "files": user_files,
            "images": user_images
        }
        # 【注意】: 'attachments' 键不再需要，但为了不破坏LLM部分的逻辑，我们暂时保留它
        # 一个更好的重构是在未来让LLM部分也直接使用 files 和 images
        user_message_content['attachments'] = processed_attachments

        user_message = {
            "role": "user",
            "content": user_message_content
        }
        # 【核心修改】: 如果有引用信息，将其作为顶层 'replyInfo' 字段添加
        if quoted_messages and quoted_messages.get('ids'):
            user_message['replyInfo'] = quoted_messages

        self.chat_history.append(user_message)

        # --- 【核心新增】: 立即将用户的多模态消息异步添加到RAG索引 ---
        user_message_index = len(self.chat_history) - 1
        self.rag_handler.add_message_async(user_message, user_message_index)
        # ----------------------------------------------------------------

        # 【核心修改】调用新的启动函数，而不是直接启动线程
        self._start_llm_generation()

    def stop_generation(self):
        self.stop_generation_flag = True

    def open_file_dialog(self):
        try:
            from webview import FileDialog
            file_types = ('All files (*.*)',)
            # 【修改】使用 FileDialog.OPEN 替代旧的常量
            result = self._window.create_file_dialog(FileDialog.OPEN, allow_multiple=True, file_types=file_types)
            return result if result else []
        except Exception as e:
            print(f"打开文件对话框失败: {e}")
            return []

    # --- 内部逻辑 ---
    def _get_context_from_main_app(self):
        """通过IPC连接到主程序，获取实时上下文。"""
        HOST = '127.0.0.1'
        PORT = 65432
        context = {}
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((HOST, PORT))
                s.sendall(b'GET_CONTEXT')

                # 接收数据直到收到结束符
                buffer = b""
                while True:
                    data = s.recv(4096)
                    if not data:
                        break
                    buffer += data
                    if b"<END_OF_MESSAGE>" in buffer:
                        break

                response_data = buffer.split(b"<END_OF_MESSAGE>")[0]
                context = json.loads(response_data.decode('utf-8'))
                print("DEBUG: 成功从主程序获取上下文。")
        except Exception as e:
            print(f"DEBUG: 无法连接到主程序获取上下文: {e}")
            context = {
                "app_status": "未知 (无法连接主程序)",
                "workspace_state": {"描述": "无法获取工作区状态"},
                "file_structure": "无法获取项目文件结构",
                "model_config": {}
            }
        return context

    def _start_llm_generation(self, context_history=None, retry_index=None):
        """
        【新函数】
        此函数在主API线程中被调用。
        它的职责是：1. 准备LLM请求所需的数据。 2. 立即在前端创建“思考中”气泡。 3. 启动后台线程来处理真正的LLM请求。
        """
        try:
            # 【核心修改】: 如果提供了临时上下文，则使用它；否则，使用完整的聊天历史
            history_to_use = context_history if context_history is not None else self.chat_history

            # 1. 准备LLM API所需的上下文和消息 (这部分逻辑从旧的 _handle_llm_request 移过来)
            id_to_message_map = {f"history-msg-{i}": msg for i, msg in enumerate(history_to_use)}

            # 【重要】: 这里的 history_to_use 已经包含了用户最新消息，所以格式化时用 [:-1]
            formatted_history = self._format_history_for_api(history_to_use[:-1])

            # --- 【核心修复】 ---
            # 必须从 history_to_use (我们正在处理的上下文) 中获取最后一条消息
            last_user_message_obj = history_to_use[-1]
            # --- 【修复结束】 ---

            content_dict = last_user_message_obj.get('content', {})
            user_content_parts = []

            # (处理引用信息的逻辑保持不变)
            reply_info = last_user_message_obj.get('replyInfo', {})
            if reply_info and reply_info.get('ids'):
                quote_texts = []
                for msg_id in reply_info['ids']:
                    quoted_msg = id_to_message_map.get(msg_id)
                    if quoted_msg:
                        role = quoted_msg.get('role', '未知')
                        msg_content = quoted_msg.get('content', '')
                        text = msg_content.get('text', '') if isinstance(msg_content, dict) else str(msg_content)
                        author = "你" if role == "user" else "Navi"
                        quote_texts.append(f"- {author}: \"{text[:150].strip()}...\"")
                if quote_texts:
                    quotes_block = "\n".join(quote_texts)
                    user_content_parts.append(
                        {"type": "text", "text": f"--- 用户引用了以下消息 ---\n{quotes_block}\n---"})

            if content_dict.get('text'):
                user_content_parts.append({"type": "text", "text": content_dict['text']})

            # (处理附件的逻辑保持不变)
            for file_info in content_dict.get('attachments', []):
                filepath, mime_type = file_info['path'], file_info['type']
                try:
                    if mime_type and mime_type.startswith('image/'):
                        with open(filepath, "rb") as image_file:
                            base64_image = base64.b64encode(image_file.read()).decode('utf-8')
                        user_content_parts.append(
                            {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{base64_image}"}})
                    else:
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                            file_content = f.read()
                        user_content_parts.append({"type": "text",
                                                   "text": f"--- 用户上传的文件: `{os.path.basename(filepath)}` ---\n```\n{file_content}\n```\n---"})
                except Exception as e:
                    user_content_parts.append(
                        {"type": "text", "text": f"--- 无法读取文件: `{os.path.basename(filepath)}` (错误: {e}) ---"})

            current_user_message_for_api = {"role": "user", "content": user_content_parts}
            last_user_message_text = content_dict.get('text', '')

            # --- RAG 核心集成 (多模态适配) ---
            rag_context_str = ""
            # find_relevant_context 现在返回的是 'documents'
            relevant_docs = self.rag_handler.find_relevant_context(last_user_message_text)

            self.current_rag_source_ids = []

            if relevant_docs:
                print(f"[RAG] 找到 {len(relevant_docs)} 条相关的多模态历史记录。")
                rag_context_str += "【作为参考，这里有一些可能与当前问题最相关的历史记录】\n"

                for doc in relevant_docs:
                    doc_type = doc.get('type')
                    # 统一将源消息的ID记录下来
                    self.current_rag_source_ids.append(f"history-msg-{doc['original_msg_idx']}")

                    rag_context_str += "---\n"
                    if doc_type == 'turn':
                        rag_context_str += f"历史对话:\n{doc.get('text', '')}\n"
                        # 为了兼容前端高亮，也把AI回答的消息ID加上
                        self.current_rag_source_ids.append(f"history-msg-{doc['assistant_msg_idx']}")
                    elif doc_type == 'file':
                        file_name = os.path.basename(doc.get('path', '未知文件'))
                        rag_context_str += f"相关文件: `{file_name}` (来自历史消息)\n"
                    elif doc_type == 'image':
                        image_name = os.path.basename(doc.get('path', '未知图片'))
                        rag_context_str += f"相关图片: `{image_name}` (来自历史消息)\n"
                    else:  # 纯文本或其他
                        rag_context_str += f"相关文本:\n{doc.get('text', '')}\n"

                rag_context_str += "--- [参考结束] ---\n"
            else:
                self.current_rag_source_ids = []
            # --- RAG 集成结束 ---

            # (获取上下文和构建 system_prompt 的逻辑保持不变)
            context = self._get_context_from_main_app()
            project_file_structure = get_project_structure(os.getcwd())
            system_prompt = f"""
            你是一个桌面应用程序的AI助手，名为“ACG Navi”。你的任务是根据我提供的实时程序上下文和你的知识库来回答用户的问题。
            叫Navi的原因有三点，一是Navi有导航（助手）之意，二是致敬实验性动画Lain中的Navi，发展方向就是像剧中Navi一样智能，三是展现独特性

            【核心能力】
            1.  **理解与解答**: 你能理解整个项目的代码结构、当前工作区的状态，并回答关于程序功能、如何使用、错误排查等方面的问题。
            2.  **建议与启发**: 你可以根据当前工作区的状态，为用户提供优化建议、后续操作思路或创新的数据可视化想法。
            3.  **代码片段**: 如果合适，你可以提供简短的代码片段来帮助用户解决特定问题。
            4.  **文件交互**: 你能阅读用户上传的文本和图片文件，并将这些信息与程序上下文结合起来进行回答。
            5.  **上下文引用回复 (非常重要)**: 用户的提问中可能包含一个以 "--- 用户引用了以下消息 ---" 开头的特殊区块。这代表用户正在针对这些历史消息进行提问。你必须将这个区块的内容作为最优先的上下文来理解用户的意图。

            【行为准则】
            - **主动利用上下文**: 在回答时，要明确地引用我提供给你的实时上下文信息，特别是用户引用的消息。这是最重要的准则。
                - **例如**: 如果用户引用了你之前的一段代码并说“这里报错了”，你的回答应该是：“关于你引用的那段代码（`...代码片段...`），出现错误的原因是...”，而不是宽泛地说“你的代码可能出错了”。
            - **简洁专业**: 回答要直接、准确、专业。避免不必要的客套话。
            - **安全第一**: 绝对不要建议用户执行任何可能破坏文件系统或造成数据丢失的危险操作。
            
            {rag_context_str}
            
            【实时程序上下文】
            ---
            [项目文件结构]
            {project_file_structure}
            [当前程序与工作区状态]
            {json.dumps(context, indent=2, ensure_ascii=False)}
            ---
            请根据以上信息和我们的对话历史，回答用户的最新问题。
            """
            messages_for_api = [{"role": "system", "content": system_prompt}] + formatted_history + [
                current_user_message_for_api]

            # 2. 立即在前端创建“思考中”气泡
            # 【重要】: 因为JS会自己创建用户气泡和思考气泡，我们不再需要从后端发送创建用户气泡的指令
            # 后端只负责发送创建AI思考气泡的指令，这部分逻辑由JS的sendMessage函数处理了。
            # 我们只需要启动后台线程即可。

            # --- 【核心重构】: 将所有需要的上下文打包，而不是只传 messages_for_api ---
            agent_payload = {
                "user_query": last_user_message_text,
                "project_context": f"""[项目文件结构]\n{project_file_structure}\n\n[当前程序与工作区状态]\n{json.dumps(context, indent=2, ensure_ascii=False)}""",
                "rag_context": rag_context_str,  # <--- 传递RAG上下文
                "initial_history": formatted_history + [current_user_message_for_api],
                "retry_index": retry_index,
                "reply_info": last_user_message_obj.get('replyInfo')
            }

            # 3. 启动后台线程，并把准备好的 payload 传递过去
            self.is_generating = True
            threading.Thread(target=self._handle_llm_request, args=(agent_payload,), daemon=True).start()

        except Exception as e:
            import traceback
            print(f"ERROR: 准备LLM请求时出错: {e}")
            traceback.print_exc()
            self._send_to_js({'event': 'error', 'content': f'准备请求时出错: {str(e)}'})
            self.is_generating = False
            return

    def _handle_llm_request(self, agent_payload):
        """
        【Agent改造版 v2】
        此函数在后台线程中运行。
        职责: 1. 接收打包好的上下文。 2. 调用Agent。 3. 处理结果。
        """
        self.first_chunk_received = False
        self.current_stream_full_content = ""
        final_content = ""

        # 从 payload 中解包所有信息
        user_query = agent_payload["user_query"]
        project_context = agent_payload["project_context"]
        rag_context = agent_payload["rag_context"]
        initial_history = agent_payload["initial_history"]
        retry_index = agent_payload["retry_index"]
        reply_info_from_payload = agent_payload.get("reply_info")

        try:
            # 【核心修改】: 如果不是重试，才追加空壳。
            if retry_index is None:
                self.chat_history.append({"role": "assistant", "content": ""})

            # 2. 调用Agent执行任务。这是一个阻塞调用。
            print("\n[NAVIGATOR] Handing control to CodeExecutionAgent...")
            if self.agent:
                # 将 RAG 上下文传递给 Agent
                final_content = self.agent.run(user_query, project_context, rag_context, initial_history)
            else:
                final_content = "错误: Agent未被正确初始化。"
            print(f"[NAVIGATOR] Agent finished. Final answer received:\n{final_content}\n")

            # 3. 模拟流式输出Agent返回的最终答案
            if self.stop_generation_flag:
                print("DEBUG: Agent执行完成，但检测到中止信号。")
                final_content += "\n\n---\n*输出已中止*"

            self._send_to_js({'event': 'start'})
            self._send_to_js({'event': 'chunk', 'content': final_content})
            self.current_stream_full_content = final_content

            # 4. 更新后端历史记录
            assistant_message_record = {'role': 'assistant', 'content': final_content}

            # 【核心新增】: 检查是否存在RAG上下文，如果存在，则将其保存为回复信息
            # 这是解决重启后引用丢失问题的关键
            if self.current_rag_source_ids:
                assistant_message_record['replyInfo'] = {
                    "type": "multi",
                    "ids": self.current_rag_source_ids,
                    "source": "rag"  # 添加一个明确的来源标记，让前端可以更好地区分
                }
            # 【新增结束】

            # 【核心修改】: 使用从 payload 直接传入的引用信息，不再回溯查找 self.chat_history
            # 注意：下面的逻辑保持不变，但上面新增的RAG逻辑优先。
            # 如果用户的输入本身也带引用，RAG的引用会覆盖它，这是符合预期的行为，
            # 因为AI的回答是基于RAG上下文的。
            if reply_info_from_payload and not assistant_message_record.get('replyInfo'):
                assistant_message_record['replyInfo'] = reply_info_from_payload

            user_message_index = retry_index if retry_index is not None else -2
            last_user_message = self.chat_history[user_message_index] if len(self.chat_history) > abs(
                user_message_index) else {}

            # 这个逻辑主要是为了处理用户引用，现在我们的RAG引用逻辑更优先，
            # 但保留这个以防万一。
            if 'replyInfo' in last_user_message and not assistant_message_record.get('replyInfo'):
                assistant_message_record['replyInfo'] = last_user_message['replyInfo']

            if retry_index is not None:
                assistant_message_index = retry_index + 1
                self.chat_history.insert(assistant_message_index, assistant_message_record)
            else:
                assistant_message_index = len(self.chat_history) - 1
                self.chat_history[assistant_message_index] = assistant_message_record

            self._save_history()

            # 5. 向前端发送最终渲染指令
            final_content_html = markdown_to_html_with_math(final_content)
            end_payload = {
                'event': 'end',
                'content': final_content_html,
                'rawText': final_content,
                'rawMd': final_content,
                'rag_source_ids': self.current_rag_source_ids
            }
            self._send_to_js(end_payload)

        except Exception as e:
            import traceback
            print(f"ERROR: 在处理Agent请求时发生错误: {e}")
            traceback.print_exc()
            error_message = f"**错误**: Agent执行失败: `{e}`"
            if retry_index is None and self.chat_history:
                self.chat_history[-1]['content'] = error_message
            self._save_history()
            self._send_to_js({'event': 'error', 'content': error_message})
        finally:
            print("DEBUG: _handle_llm_request (Agent Mode) 执行完毕。")
            self.is_generating = False
            self.stop_generation_flag = False
            self._send_to_js({'event': 'generation_complete'})

    def retry_message(self, user_message_index):
        """
        【重构】准备对一个用户提问进行重试。
        此函数现在只负责清理后端的历史记录，并启动LLM生成。
        前端JS将负责处理UI（删除旧气泡，创建新气泡）。
        """
        try:
            index = int(user_message_index)
            print(f"收到重试请求，用户消息索引: {index}")

            if self.is_generating:
                self._send_to_js({'event': 'show_alert', 'content': '请等待当前生成任务完成后再重试。'})
                return

            if not (0 <= index < len(self.chat_history) and self.chat_history[index]['role'] == 'user'):
                print(f"警告: 尝试重试无效的用户消息索引 {index}")
                return

            # 【核心修改 1】: 准备用于LLM的上下文，但不修改 self.chat_history
            context_for_llm = self.chat_history[:index + 1]

            # 检查此用户消息后面是否有一个AI回答, 如果有，从【主历史记录】中移除它
            next_message_index = index + 1
            if next_message_index < len(self.chat_history) and self.chat_history[next_message_index][
                'role'] == 'assistant':
                del self.chat_history[next_message_index]
                print(f"后端的旧AI回答 (索引 {next_message_index}) 已被移除。")

            self._save_history()  # 保存删除旧AI回答后的历史

            # 【核心修改 2】: 调用LLM启动函数，并传入【临时上下文】和【重试索引】
            self._start_llm_generation(context_history=context_for_llm, retry_index=index)
            print(f"已准备好后端历史，正在为索引 '{index}' 的消息重试。")

        except Exception as e:
            import traceback
            print(f"重试消息时出错: {e}")
            traceback.print_exc()

    def delete_message(self, message_index):
        """
        删除一个消息对（用户提问 + AI回答）。
        - 如果删除用户消息，则同时删除其后的AI回答。
        - 如果删除AI回答，则同时删除其前的用户提问。
        """
        try:
            index = int(message_index)
            if not (0 <= index < len(self.chat_history)):
                print(f"警告: 尝试删除无效索引 {index}")
                return

            indices_to_remove = set()
            role = self.chat_history[index]['role']

            if role == 'user':
                indices_to_remove.add(index)
                # 如果后面紧跟着的是一个AI回答，也删除它
                if index + 1 < len(self.chat_history) and self.chat_history[index + 1]['role'] == 'assistant':
                    indices_to_remove.add(index + 1)
            elif role == 'assistant':
                indices_to_remove.add(index)
                # 如果前面紧跟着的是一个用户提问，也删除它
                if index - 1 >= 0 and self.chat_history[index - 1]['role'] == 'user':
                    indices_to_remove.add(index - 1)

            if not indices_to_remove:
                indices_to_remove.add(index)  # 至少删除自己

            # 获取要删除的IDs
            ids_to_remove = [f"history-msg-{i}" for i in sorted(list(indices_to_remove))]
            print(f"准备删除索引: {sorted(list(indices_to_remove))}, 对应IDs: {ids_to_remove}")

            # 重建历史记录列表，排除要删除的项
            self.chat_history = [msg for i, msg in enumerate(self.chat_history) if i not in indices_to_remove]

            # 通知前端删除元素
            self._send_to_js({'event': 'delete_messages', 'ids': ids_to_remove})

            # 【关键】通知前端对剩余的消息进行重新索引
            self._send_to_js({'event': 'reindex_messages'})

            self._save_history()
            self.rag_handler.process_history_async(self.chat_history)
            print("消息对删除并重新索引完成。")

        except Exception as e:
            import traceback
            print(f"删除消息时出错: {e}")
            traceback.print_exc()

    def edit_message(self, message_index, new_content):
        try:
            msg_index = int(message_index)
            print(f"后端收到编辑请求，消息索引: {msg_index}, 新内容: {new_content}")

            if self.is_generating:
                self._send_to_js({'event': 'show_alert', 'content': '请等待当前生成任务完成后再编辑。'})
                return

            if 0 <= msg_index < len(self.chat_history) and self.chat_history[msg_index]['role'] == 'user':
                # 1. 更新用户消息内容
                self.chat_history[msg_index]['content']['text'] = new_content

                # 2. 将更新后的内容立即发回前端显示
                new_html = markdown_to_html_with_math(new_content)
                self._send_to_js({
                    'event': 'update_message_content',
                    'messageId': f'history-msg-{msg_index}',  # JS仍需ID来定位元素
                    'newHtml': new_html,
                    'newRawText': new_content,
                    'newRawMd': new_content
                })

                # 3. 截断历史记录到此用户消息（包含它自己），并删除前端对应的AI气泡
                # 我们需要找到此用户消息之后的所有消息
                ids_to_delete = [f'history-msg-{i}' for i in range(msg_index + 1, len(self.chat_history))]
                if ids_to_delete:
                    self._send_to_js({'event': 'delete_messages', 'ids': ids_to_delete})

                self.chat_history = self.chat_history[:msg_index + 1]
                self._save_history()
                self.rag_handler.process_history_async(self.chat_history)

                # 4. 调用重构后的生成函数
                print(f"消息索引 '{msg_index}' 已编辑，后端数据已更新。等待前端指令以重新生成。")
            else:
                raise ValueError(f"无效的用户消息索引: {msg_index}")

        except Exception as e:
            import traceback
            print(f"编辑消息时出错: {e}")
            traceback.print_exc()
            self._send_to_js({'event': 'show_alert', 'content': f'编辑时发生内部错误: {e}'})

    def regenerate_after_edit(self):
        """
        一个专门的API，由JS在UI准备就绪后调用，
        用于触发基于当前最新历史记录的LLM生成。
        """
        print("收到前端 'regenerate_after_edit' 请求，开始生成...")
        if not self.is_generating:
            self._start_llm_generation()
        else:
            print("警告: regenerate_after_edit被调用，但已有任务在生成中。")

    def export_messages(self, export_data):
        print(f"后端收到导出请求: {export_data}")
        ids_to_export = export_data.get('ids', [])
        export_format = export_data.get('format', 'pdf')

        if not ids_to_export:
            self._send_to_js({'event': 'show_alert', 'content': '没有选中任何消息进行导出。'})
            return

        selected_messages = []
        for i, msg in enumerate(self.chat_history):
            if f'history-msg-{i}' in ids_to_export:
                selected_messages.append(msg)

        html_content = self._create_export_html(selected_messages)
        if not html_content:
            self._send_to_js({'event': 'show_alert', 'content': '创建导出文件时出错。'})
            return

        temp_html_file = None
        try:
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.html', encoding='utf-8') as f:
                f.write(html_content)
                temp_html_file = f.name
            print(f"临时HTML文件已创建: {temp_html_file}")

            # 修正1: 响应pywebview的弃用警告
            from webview import FileDialog
            file_types = {'pdf': ('PDF Documents (*.pdf)',), 'image': ('PNG Images (*.png)',)}
            default_filename = f"chat_export.{'pdf' if export_format == 'pdf' else 'png'}"
            save_path = self._window.create_file_dialog(FileDialog.SAVE, directory=os.getcwd(),
                                                        save_filename=default_filename,
                                                        file_types=file_types[export_format])

            if not save_path:
                print("用户取消了保存。")
                return

            # create_file_dialog 返回的是元组
            save_path = save_path[0] if isinstance(save_path, tuple) and save_path else save_path

            if not save_path:  # 再次检查用户是否取消
                return

            if export_format == 'pdf':
                from weasyprint import HTML
                # 修正2: 使用更稳定的 weasyprint 库
                print(f"正在使用 WeasyPrint 转换为PDF: {save_path}")
                # base_url 确保CSS等相对路径能被正确找到
                web_dir_path = str(Path(__file__).parent / 'web')
                HTML(string=html_content, base_url=web_dir_path).write_pdf(save_path)

            elif export_format == 'image':
                # 修正3: 移除错误的 size 参数，并增加健壮性配置
                print(f"正在转换为图片: {save_path}")
                hti = Html2Image(output_path=os.path.dirname(save_path), custom_flags=['--no-sandbox'])
                save_filename = os.path.basename(save_path)

                # 关键修改：完全移除 size 参数，让库自动计算高度
                hti.screenshot(html_file=temp_html_file, save_as=save_filename)

            self._send_to_js({'event': 'show_alert', 'content': f'成功导出文件到: {save_path}'})

        except Exception as e:
            import traceback
            print(f"导出失败: {e}")
            traceback.print_exc()  # 打印更详细的错误堆栈
            self._send_to_js({'event': 'show_alert', 'content': f'导出文件时发生错误: {e}'})
        finally:
            if temp_html_file and os.path.exists(temp_html_file):
                os.remove(temp_html_file)
                print(f"临时HTML文件已删除: {temp_html_file}")

    def _create_export_html(self, messages):
        """为导出的消息创建一个自包含的HTML字符串"""
        message_bubbles_html = []
        for msg in messages:
            role = msg.get("role", "assistant")
            content = msg.get("content", "")

            # 复用现有的格式化逻辑来生成HTML
            if isinstance(content, dict):
                text_content = content.get("text", "")
            else:
                text_content = str(content)

            content_html = markdown_to_html_with_math(text_content)

            bubble_html = f"""
            <div class="message-wrapper {role}">
                <div class="message-content-wrapper">
                    <div class="message-bubble">
                        {content_html}
                    </div>
                </div>
            </div>
            """
            message_bubbles_html.append(bubble_html)

        # 读取CSS文件内容并嵌入到HTML中
        try:
            with open(Path(__file__).parent / 'web' / 'style.css', 'r', encoding='utf-8') as f:
                css_content = f.read()
            # 为导出微调样式
            css_content += """
                body { background-color: #f7f7f7; }
                #chat-container { padding: 30px; }
                .message-bubble { box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
            """
        except Exception as e:
            print(f"读取CSS文件失败: {e}")
            css_content = ""  # 如果失败则不包含样式

        # 组装最终的完整HTML
        full_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Chat Export</title>
            <style>
                {css_content}
            </style>
        </head>
        <body>
            <div id="chat-container">
                {''.join(message_bubbles_html)}
            </div>
        </body>
        </html>
        """
        return full_html

    # 【新增】一个辅助函数，将历史记录格式化为API兼容的格式
    def _format_history_for_api(self, history):
        """将历史记录格式化为LLM API兼容的格式，并保留必要的上下文。"""
        formatted_history = []
        for msg in history:
            role = msg['role']
            content = msg.get('content', '')

            final_content_str = ""

            # 1. 处理用户消息
            if role == 'user' and isinstance(content, dict):
                # 只提取文本部分，因为附件和引用上下文仅在当前轮次处理
                final_content_str = content.get('text', '')

            # 2. 处理助手 (AI) 消息
            elif role == 'assistant':
                # 【核心修正】: 检查AI消息是否包含引用信息
                reply_info = msg.get('replyInfo')
                # 确保 content 是字符串
                text_content = str(content)

                if reply_info and reply_info.get('ids'):
                    # 如果有引用信息，为其生成一个文本描述前缀
                    num_replies = len(reply_info['ids'])
                    reply_prefix = f"[注意：这是对之前 {num_replies} 条消息的回复] "
                    final_content_str = reply_prefix + text_content
                else:
                    final_content_str = text_content

            # 3. 处理旧格式的或简单的纯文本消息
            elif isinstance(content, str):
                final_content_str = content

            # 只有当最终内容不为空时才添加到历史记录中
            if final_content_str:
                formatted_history.append({'role': role, 'content': final_content_str})

        return formatted_history

    # 【新增】一个辅助函数来向JS发送通用事件
    def _send_to_js(self, data):
        """将JSON数据发送到前端的 window.handlePythonEvent 函数"""
        if self._window:
            json_str = json.dumps(data)
            self._window.evaluate_js(f'window.handlePythonEvent({json_str})')


# --- 主程序入口 ---
if __name__ == '__main__':
    print("DEBUG: 程序开始执行...") #【DEBUG】
    ROOT_DIR = Path(__file__).parent.resolve()
    server_port = start_asset_server(ROOT_DIR)

    if server_port is None:
        # 如果服务器启动失败，就没有必要继续了
        exit()

    api = Api()
    try:
        html_path = ROOT_DIR / 'web' / 'navigator.html'
        print(f"DEBUG: 尝试读取HTML模板文件于: {html_path}") #【DEBUG】
        with open(html_path, 'r', encoding='utf-8') as f:
            html_template = f.read()
    except FileNotFoundError:
        print(f"DEBUG: 错误！未找到 navigator.html 文件。") #【DEBUG】
        html_template = "<html><body><h1>错误</h1><p>未找到 navigator.html 文件。</p></body></html>"

    base_url = f"http://localhost:{server_port}/"
    api.base_url = base_url  # <-- 【核心新增】将 base_url 传递给 API 实例
    print(f"DEBUG: 为HTML模板生成的服务器基础URL是: {base_url}")  # 【DEBUG】
    final_html = html_template.replace("{{BASE_URL}}", base_url)

    # 【DEBUG】: 打印一小部分最终的HTML内容以供检查
    print("DEBUG: 最终将要加载的HTML内容片段 (前500个字符):")
    print(final_html[:500] + "...")
    print("-" * 20)

    window = webview.create_window(
        '智能导航',
        html=final_html,
        js_api=api,
        width=800,
        height=750,
        min_size=(500, 400)
    )

    api.set_window(window)

    print("DEBUG: 所有设置完成，即将启动 pywebview...") #【DEBUG】
    webview.start(debug=False)