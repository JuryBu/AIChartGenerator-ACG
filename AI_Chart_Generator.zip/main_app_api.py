import os
import sys
import json
import tempfile
import threading
import subprocess
import socket
import webview
import re
import webbrowser
import pathlib
import base64
import mimetypes
from typing import Optional

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from config_manager import ConfigManager
from workspace_manager import WorkspaceManager
from history_manager import HistoryManager
import app_logic
import file_handler
from utils import resource_path, get_project_structure, clear_and_recreate_dir, get_python_executable
from constants import INPUT_DIR, OUTPUT_DIR, URL_STATUS_COLORS


class MainAppApi:
    """主应用窗口的后端API，作为前后端通信的唯一桥梁。"""

    def __init__(self):
        self._window = None
        self.sub_processes = {}
        self.is_heavy_install_running = False

        # 任务一：添加 threading.Event 实例作为通信门锁
        self.js_ready_event = threading.Event()
        self.frontend_ready_event = threading.Event()  # 用于等待前端UI完全就绪
        self._initialize_temp_folders()

        # 初始化所有业务逻辑管理器，并将API实例自身作为控制器传入
        self.config_manager = ConfigManager()
        self.workspace_manager = WorkspaceManager(self)
        self.history_manager = HistoryManager(self)
        self._create_initial_workspace()

        # IPC for Navigator
        self.ipc_server_thread = None
        self.server_socket = None
        self.navigator_process = None

        self.history_manager.set_api(self)
        self.history_manager.start_initial_load()

    def _initialize_temp_folders(self):
        """在应用启动时清理 input 和 output 文件夹。"""
        print("正在初始化临时文件夹...")
        clear_and_recreate_dir(INPUT_DIR)
        clear_and_recreate_dir(OUTPUT_DIR)
        print("临时文件夹初始化完成。")

    def _create_initial_workspace(self):
        """如果没有任何工作区，则创建一个默认的。"""
        if not self.workspace_manager.workspaces:
            print("未找到任何工作区，正在创建默认工作区...")
            model_config = self.config_manager.config
            font_config = {"name": self.config_manager.config.get("plotting_font", "NotoSansSC")}
            # 直接调用 create_workspace，但不切换，因为还没有活动工作区
            new_ws = self.workspace_manager.create_workspace("主工作区", model_config, font_config)
            # 手动设置第一个工作区为活动工作区
            self.workspace_manager.active_workspace_id = new_ws.id
            print(f"默认工作区 '{new_ws.name}' (ID: {new_ws.id}) 已创建并激活。")

    def set_window(self, window):
        """由启动器调用，注入webview窗口实例。"""
        self._window = window

    def _prepare_settings_for_frontend(self):
        """
        准备一个扁平化的配置字典，以匹配前端JS的期望。
        """
        config = self.config_manager.config
        api_type = config.get("api_type", "external")
        active_api_config = config.get(f"{api_type}_api", {})

        # 构造前端期望的 model_config 结构
        model_config_for_js = {
            "api_key": active_api_config.get("api_key", ""),
            "api_url": active_api_config.get("base_url", ""),  # 后端是base_url, 前端是api_url
            "model_name": active_api_config.get("model", ""),  # 后端是model, 前端是model_name
            "plotting_font": config.get("plotting_font", "NotoSansSC"),
            # 确保 system_prompt 始终存在，即使 config.json 中没有
            "system_prompt": config.get("system_prompt", "你是一个数据可视化专家。")
        }

        font_mapping = config.get("font_mapping", {})
        font_options = [{"value": k, "text": k} for k in font_mapping.keys()]

        return {
            "model_config": model_config_for_js,
            "app_settings": self.config_manager.settings,
            "font_options": font_options
        }

    # --- 前端调用的API方法 ---

    def js_is_ready(self):
        """
        由JS在前端初始化后调用。
        """
        print("[BACKEND] 接收到 'js_is_ready' 信号，准备返回初始数据。")
        self.js_ready_event.set()

        workspaces_data = {ws_id: ws.to_dict() for ws_id, ws in self.workspace_manager.workspaces.items()}

        # 将ID注入到每个元数据对象中
        history_data = {
            item_id: {**metadata, 'id': item_id}
            for item_id, metadata in self.history_manager.all_history_metadata.items()
        }

        settings_data = self._prepare_settings_for_frontend()

        return {
            "workspaces": {
                "items": workspaces_data,
                "active_id": self.workspace_manager.active_workspace_id
            },
            "history": history_data,  # 使用修复后的数据
            "settings": settings_data
        }

    def frontend_fully_ready(self):
        """
        由JS在前端UI完全初始化（DOM缓存和事件绑定）后调用。
        设置事件以允许后端推送数据。
        """
        print("[BACKEND] 接收到 'frontend_fully_ready' 信号。UI现在可以接收数据推送。")
        self.frontend_ready_event.set()
        return {"status": "ok"}

    def start_generation(self, workspace_id):
        """开始生成图表/数据。"""
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return {"status": "error", "message": "Workspace not found."}

        print(f"工作区 {workspace_id} 开始生成任务，强制清除所有旧输出...")
        # 调用意图明确的“全部清除”方法
        workspace.clear_all_outputs()
        self.refresh_ui_lists()  # 清空输出后立即刷新UI，让界面变干净

        # 使用 threading 确保长时间运行的任务不会阻塞UI
        threading.Thread(target=app_logic.generate_chart, args=(self, workspace_id), daemon=True).start()
        return {"status": "ok", "message": "Generation task started."}

    # --- 供前端调用的文字分析启动函数 ---
    def start_text_analysis(self, workspace_id):
        """开始生成文字分析。"""
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return {"status": "error", "message": "Workspace not found."}

        # 文字分析是基于已有结果的，不需要清除任何内容
        threading.Thread(target=app_logic.generate_text_analysis, args=(self, workspace_id), daemon=True).start()
        return {"status": "ok", "message": "Text analysis task started."}

    def clear_workspace_outputs(self, workspace_id: str, targets: list):
        """
        根据前端请求，选择性地清除当前工作区的输出内容。
        """
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return {"status": "error", "message": "Workspace not found."}

        if not targets:
            return {"status": "ok", "message": "No targets to clear."}

        try:
            print(f"工作区 {workspace_id} 正在清除选定输出: {targets}")
            workspace.clear_selective_outputs(targets)

            # 清除后必须刷新UI，以将更新后的空状态推送到前端
            self.refresh_ui_lists()

            self.show_alert("选定输出区域已清空。", "info")
            return {"status": "success"}
        except Exception as e:
            error_message = f"清除输出时发生错误: {e}"
            print(error_message)
            self.show_alert(error_message, "error")
            return {"status": "error", "message": error_message}

    def run_code(self, workspace_id, code):
        """执行用户指定的代码。"""
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if workspace:
            workspace.last_generated_code = code  # 更新工作区代码
            threading.Thread(target=app_logic.run_code_from_textbox, args=(self, workspace_id), daemon=True).start()
            return {"status": "ok", "message": "Code execution started."}
        return {"status": "error", "message": "Workspace not found."}

    def save_current_workspace_state(self, workspace_id, state):
        """从前端接收并保存当前工作区的状态。"""
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return

        # 更新工作区对象
        workspace.data_input_text = state.get("data_input_text", "")
        workspace.prompt_input_text = state.get("prompt_input_text", "")
        workspace.last_generated_code = state.get("last_generated_code", "")
        workspace.agent_mode_enabled = state.get("agent_mode_enabled", True)

        # --- 保存清除选项 ---
        if "clear_options" in state:
            workspace.clear_options.update(state.get("clear_options"))

    # 任务二：解耦 save_config 方法
    def save_config(self, new_config_flat, new_settings):
        """
        保存模型和应用设置到全局 config.json 和 settings.json。
        此方法会接收前端传来的扁平化数据，并在这里重组为正确的嵌套结构。
        """
        try:
            # 1. 准备重构的 config 字典
            reconstructed_config = {
                "api_type": new_config_flat.get("api_type"),
                "external_api": {
                    "base_url": new_config_flat.get("external_api_url", ""),
                    "api_key": new_config_flat.get("external_api_key", ""),
                    "model": new_config_flat.get("external_model_name", "")
                },
                "local_api": {
                    "base_url": new_config_flat.get("local_api_url", ""),
                    "api_key": new_config_flat.get("local_api_key", ""),
                    "model": new_config_flat.get("local_model_name", "")
                },
                "system_prompt": new_config_flat.get("system_prompt", ""),
                "plotting_font": new_config_flat.get("plotting_font", "NotoSansSC")
            }

            # 2. 将数据传递给 ConfigManager 保存
            # ConfigManager 的 save 方法已经可以处理部分更新，我们直接用
            self.config_manager.save(config_data=reconstructed_config, settings_data=new_settings)

            # 3. （可选但推荐）更新所有现有工作区的配置，如果它们与新的全局配置不同步
            # 这里我们选择不自动更新，让用户自行决定，以保持工作区的独立性。

            self.show_alert("全局配置已成功保存！", "info")
            return {"status": "success", "message": "全局配置已成功保存！"}
        except Exception as e:
            error_msg = f"保存全局配置失败: {e}"
            print(error_msg)
            self.show_alert(error_msg, "error")
            return {"status": "error", "message": error_msg}

    def save_workspace_config(self, workspace_id, config_data):
        """
        保存指定工作区的模型和字体配置。
        """
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return {"status": "error", "message": "Workspace not found."}

        try:
            # --- 核心修复：确保 api_type 在工作区对象和其配置字典中都得到更新 ---

            # 1. 从前端数据中获取新的 api_type
            api_type = config_data.get("api_type", workspace.api_type)

            # 2. 更新工作区对象的顶层 api_type 属性
            workspace.api_type = api_type

            # 3. 【关键】同时更新 model_config 字典内部的 'api_type' 键
            #    这是导致错误的根源，之前这里没有更新
            workspace.model_config['api_type'] = api_type

            # 4. 根据正确的 api_type 确定要更新的配置子字典
            api_config_key = f"{api_type}_api"
            if api_config_key not in workspace.model_config:
                workspace.model_config[api_config_key] = {}

            # 5. 更新URL, Key和模型名到正确的子字典中
            workspace.model_config[api_config_key]['base_url'] = config_data.get("api_url", "")
            workspace.model_config[api_config_key]['api_key'] = config_data.get("api_key", "")
            workspace.model_config[api_config_key]['model'] = config_data.get("model_name", "")

            # 6. 更新其他配置项
            workspace.model_config['system_prompt'] = config_data.get("system_prompt", "")
            workspace.model_config['max_retries'] = int(config_data.get('max_retries', 3))
            workspace.model_config['max_agent_retries'] = int(config_data.get('max_agent_retries', 3))

            workspace.font_config['name'] = config_data.get("plotting_font", "NotoSansSC")

            print(
                f"工作区 {workspace_id} 配置已更新 (API类型: {workspace.api_type})。新URL: {config_data.get('api_url', '')}")

            return {"status": "success"}
        except Exception as e:
            print(f"更新工作区 {workspace_id} 配置失败: {e}")
            return {"status": "error", "message": str(e)}

    def update_code_with_font(self, code_text, font_display_name):
        """根据选择的字体显示名称，重写代码中的字体路径。"""
        try:
            font_mapping = self.config_manager.config.get("font_mapping", {})
            font_filename = font_mapping.get(font_display_name)
            if not font_filename:
                return {"success": False, "error": f"找不到字体 '{font_display_name}' 的配置文件。"}

            font_relative_path = os.path.join("字体", font_filename)
            real_font_path = resource_path(font_relative_path)
            safe_font_path = real_font_path.replace('\\', '/')

            replacement_str = f"font_path = r'{safe_font_path}'"
            pattern = re.compile(r"font_path\s*=\s*r?(['\"]).*?\1")

            new_code, num_replacements = pattern.subn(replacement_str, code_text, count=1)

            if num_replacements > 0:
                return {"success": True, "new_code": new_code}
            else:
                # 如果没有找到精确匹配，作为备用方案，可以尝试在代码末尾或特定位置注入matplotlib的rc设置
                # 但根据方案，我们只处理替换
                return {"success": False, "error": "在代码中未找到 'font_path = ...' 这样的可替换行。"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # --- 工作区管理 ---
    def add_workspace(self, name):
        model_config = self.config_manager.config
        font_config = {"name": self.config_manager.config.get("plotting_font", "NotoSansSC")}
        new_ws = self.workspace_manager.create_workspace(name, model_config, font_config)
        self.workspace_manager.switch_to_workspace(new_ws.id)
        # 创建和切换会自动触发UI刷新
        return {"status": "success", "new_workspace_id": new_ws.id}

    def switch_workspace(self, workspace_id):
        self.workspace_manager.switch_to_workspace(workspace_id)
        return {"status": "success"}

    def delete_workspace(self, workspace_id):
        self.workspace_manager.delete_workspace(workspace_id)
        return {"status": "success"}

    def search_history(self, search_term):
        """根据搜索词过滤历史记录并刷新UI。"""
        filtered_history = self.history_manager.search_items(search_term)
        # 调用修改后的refresh_ui_lists，只更新历史记录部分
        self.refresh_ui_lists(history_override=filtered_history)
        return {"status": "success"}

    # --- 历史记录管理 ---
    def delete_history_item(self, item_ids):
        if not isinstance(item_ids, list):
            item_ids = [item_ids]  # 兼容旧的单项删除调用

        for item_id in item_ids:
            # Manager内部的 delete_item 一次只删一个，我们在API层循环
            self.history_manager.delete_item(item_id)

        # 所有删除完成后，manager内部的refresh可能被多次调用，但没关系
        # 最后一次会刷新最终状态
        return {"status": "success"}

    def rename_history_item(self, item_id, new_name):
        success = self.history_manager.rename_item(item_id, new_name)
        if success:
            return {'status': 'success', 'message': 'Rename successful.'}
        else:
            # HistoryManager 内部已经 show_alert 了，这里返回 error 状态即可
            return {'status': 'error', 'message': 'Rename failed on the backend.'}

    def load_history_to_workspace(self, item_id, active_workspace_id):
        self.history_manager.load_history_into_workspace(item_id, active_workspace_id)
        return {"status": "success"}

    def show_history_input_preview(self, history_id):
        """由前端JS调用，显示指定历史记录的输入预览。"""
        self.history_manager.show_input_preview(history_id)
        return {"status": "ok"}

    def show_history_output_preview(self, history_id):
        """由前端JS调用，显示指定历史记录的输出预览。"""
        self.history_manager.show_output_preview(history_id)
        return {"status": "ok"}

    # --- 文件处理 ---
    def select_files(self, target, workspace_id):
        """打开文件选择对话框。"""
        result = self._window.create_file_dialog(webview.OPEN_DIALOG, allow_multiple=True)
        if result:
            for filepath in result:
                file_handler.add_file_input(self, filepath, target, workspace_id)
        # add_file_input 内部会调用 refresh
        return {"status": "success", "count": len(result) if result else 0}

    def remove_file(self, target, workspace_id, preview_id):
        file_handler.remove_file_input(self, target, workspace_id, preview_id)
        return {"status": "success"}

    def open_file_in_system(self, file_path):
        """用系统默认应用打开指定路径的文件"""
        try:
            if sys.platform == "win32":
                os.startfile(file_path)
            elif sys.platform == "darwin":  # macOS
                subprocess.run(["open", file_path])
            else:  # linux
                subprocess.run(["xdg-open", file_path])
            return {"status": "success"}
        except Exception as e:
            error_msg = f"无法打开文件 {os.path.basename(file_path)}: {e}"
            print(error_msg)
            self.show_alert(error_msg, "error")
            return {"status": "error", "message": error_msg}

    def clear_input_area(self, workspace_id: str, target: str):
        """
        清空指定工作区的输入区，包括文本和所有关联文件。
        :param workspace_id: 工作区ID
        :param target: 'data' 或 'prompt'
        """
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return {"status": "error", "message": "Workspace not found."}

        if target not in ['data', 'prompt']:
            return {"status": "error", "message": f"Invalid target: {target}"}

        try:
            # 1. 清空文本内容
            if target == 'data':
                workspace.data_input_text = ""
            elif target == 'prompt':
                workspace.prompt_input_text = ""

            # 2. 删除物理文件并清空文件列表
            # 创建一个列表副本进行迭代，因为我们将在循环中修改原始列表
            files_to_remove = list(workspace.managed_files.get(target, []))
            for file_info in files_to_remove:
                # 调用现有的单文件删除逻辑，它会处理文件系统和工作区状态
                file_handler.remove_file_input(self, target, workspace_id, file_info['preview_id'])

            # 3. 确保列表最终为空 (remove_file_input 应该已经处理了，但作为双重保险)
            workspace.managed_files[target] = []

            # 4. 刷新UI以反映变化
            self.refresh_ui_lists()
            self.show_alert(f"'{target.capitalize()}' 输入区已清空。", "info")
            return {"status": "success"}
        except Exception as e:
            error_message = f"清空输入区时发生错误: {e}"
            print(error_message)
            self.show_alert(error_message, "error")
            return {"status": "error", "message": error_message}

    def save_single_output_file(self, workspace_id, final_path):
        """
        打开文件保存对话框，以保存由 final_path 指定的单个文件。
        """
        if not os.path.exists(final_path):
            self.show_alert(f"错误：源文件不存在: {os.path.basename(final_path)}", "error")
            return {"status": "error", "message": "Source file not found."}

        # 从路径中提取文件名和扩展名，为对话框提供建议
        filename = os.path.basename(final_path)
        _, ext = os.path.splitext(filename)
        file_types = (f"File (*{ext})",)

        # 调用pywebview的文件保存对话框，并建议文件名
        filepath_tuple = self._window.create_file_dialog(
            webview.SAVE_DIALOG,
            directory=os.path.expanduser('~'),
            save_filename=filename,
            file_types=file_types
        )

        if not filepath_tuple:
            return {"status": "cancelled", "message": "Save cancelled by user."}

        # create_file_dialog 返回的是一个元组，我们取第一个元素
        save_path = filepath_tuple[0]

        try:
            # 使用新线程调用 file_handler 中简化的复制函数
            threading.Thread(
                target=file_handler.save_single_output_file,
                args=(self, final_path, save_path),
                daemon=True
            ).start()
            return {"status": "success", "message": "Save process started."}
        except Exception as e:
            error_msg = f"启动保存线程时出错: {e}"
            self.show_alert(error_msg, "error")
            return {"status": "error", "message": error_msg}

    def save_all_outputs(self, workspace_id: str):
        """
        打开文件保存对话框，将当前工作区的所有输出打包成一个ZIP文件。
        """
        # 1. 获取工作区
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return  # 如果找不到工作区，则直接返回

        # 2. 生成建议的文件名
        default_zip_name = f"{workspace.name}_outputs.zip"

        # 3. 弹出文件保存对话框
        result = self._window.create_file_dialog(
            webview.SAVE_DIALOG,
            save_filename=default_zip_name,
            file_types=('ZIP压缩文件 (*.zip)',)
        )

        # 4. 检查用户是否取消
        if not result:
            return  # 用户取消了操作

        # 5. 提取保存路径
        # create_file_dialog 返回的是一个元组
        zip_save_path = result[0]

        # 6. 在后台线程中执行压缩以避免UI阻塞
        threading.Thread(
            target=file_handler.save_all_outputs_as_zip,
            args=(self, workspace_id, zip_save_path),
            daemon=True
        ).start()

    # --- 子窗口 ---
    def open_font_manager(self):
        # --- 新增：安全检查 ---
        if self.is_heavy_install_running:
            self.show_alert("正在进行后台安装，请稍后重试。", "warning")
            return
        # --- 检查结束 ---
        self._launch_sub_window("font_manager", "font_manager_window.py", self.refresh_font_list)
        return {"status": "ok"}

    def open_navigator(self):
        """启动智能导航助手前增加检查"""
        # --- 新增：安全检查 ---
        if self.is_heavy_install_running:
            self.show_alert("正在进行后台安装，请稍后重试。", "warning")
            return
        # --- 检查结束 ---
        # 检查是否已完成全部安装
        if not self.config_manager.settings.get("full_setup_complete", False):
            # 检查后台安装是否仍在进行
            if self.is_heavy_install_running:
                self.show_alert("智能导航助手正在准备中，请稍等片刻...", "info")
            else:
                # 这种情况可能是上次后台安装失败了
                self.show_alert("智能导航助手组件尚未安装或安装失败。", "warning")
            return

        # 如果检查通过，正常启动
        self._launch_sub_window("navigator", "navigator.py")
        return {"status": "ok"}

    def show_help_window(self):
        # --- 新增：安全检查 ---
        if self.is_heavy_install_running:
            self.show_alert("正在进行后台安装，请稍后重试。", "warning")
            return
        # --- 检查结束 ---
        self._launch_sub_window("help_window", "help_window.py")
        return {"status": "ok"}

    def open_version_checker(self):
        """打开版本检查与更新窗口"""
        if self.is_heavy_install_running:
            self.show_alert("正在进行后台安装，请稍后重试。", "warning")
            return
        self._launch_sub_window("version_checker", "version_check.py")
        return {"status": "ok"}

    def show_preview_window(self, data_dict, window_title):
        """
        核心修正: 将预览窗口的启动逻辑移到这里，因为它属于主应用的职责。
        它会创建一个临时文件来传递数据，然后启动子进程。
        """
        # --- 新增：安全检查 ---
        if self.is_heavy_install_running:
            self.show_alert("正在进行后台安装，请稍后重试。", "warning")
            return
        # --- 检查结束 ---
        try:
            # 1. 将窗口标题也加入数据字典，以便子窗口可以读取
            data_dict["任务名称"] = window_title

            # 2. 创建一个临时JSON文件来安全地传递复杂数据
            #    使用 delete=False 确保在Windows上子进程可以读取它
            #    子进程 preview_window.py 会在读取后自行删除该文件
            with tempfile.NamedTemporaryFile(
                    mode='w',
                    delete=False,
                    suffix='.json',
                    encoding='utf-8'
            ) as fp:
                json.dump(data_dict, fp, ensure_ascii=False)
                temp_file_path = fp.name

            print(f"为预览窗口创建了临时文件: {temp_file_path}")

            # 3. 使用已有的子窗口启动器来启动 preview_window.py
            #    将临时文件路径作为命令行参数传递
            self._launch_sub_window(
                window_key=f"preview_{os.path.basename(temp_file_path)}",  # 创建唯一的key
                script_name="preview_window.py",
                args=[temp_file_path]  # args 必须是列表
            )

            return {"status": "ok"}
        except Exception as e:
            self.show_alert(f"无法启动预览窗口: {e}", "error")
            print(f"启动预览窗口时发生严重错误: {e}")
            return {"status": "error", "message": str(e)}

    def show_full_size_image(self, file_path: Optional[str]):
        """在系统默认的图片查看器中打开指定路径的图片。"""
        if not file_path:  # 更简洁的检查
            self.show_alert("文件路径无效。", "warning")
            return {"status": "warning", "message": "File path is missing."}

        # --- 【核心修复】将传入的相对路径转换为绝对路径 ---
        absolute_file_path = os.path.abspath(file_path)

        if os.path.exists(absolute_file_path):
            try:
                # 使用转换后的绝对路径来创建文件URI
                webbrowser.open(pathlib.Path(absolute_file_path).as_uri())
                return {"status": "success"}
            except Exception as e:
                self.show_alert(f"打开图片失败: {e}", "error")
                return {"status": "error", "message": str(e)}
        else:
            self.show_alert(f"文件不存在: {file_path}", "warning")  # 错误消息中仍显示原始相对路径，对用户更友好
            return {"status": "warning", "message": "File not found."}

    def _launch_sub_window(self, window_key, script_name, callback_on_close=None, args=None):
        if window_key in self.sub_processes and self.sub_processes[window_key].poll() is None:
            print(f"子窗口 '{window_key}' 已在运行。")
            self.show_alert(f"'{window_key}' 窗口已经打开了。", "info")
            return

        try:
            python_exe = get_python_executable()
            absolute_script_path = resource_path(script_name)

            # --- 【核心修复：为子进程设置正确的工作目录】 ---
            # 在主进程中，resource_path('.') 可以正确解析到 _internal 目录
            # 我们将这个目录作为子进程的当前工作目录 (cwd)
            subprocess_cwd = resource_path('.')
            # --- 【修复结束】 ---

            command = [python_exe, absolute_script_path]
            if args:
                command.extend(args)

            # 1. 复制当前的环境变量，避免污染主进程
            proc_env = os.environ.copy()
            # 2. 设置 PYTHONUTF8=1, 这会强制子进程的 Python 解释器
            #    将其标准输入、输出和错误流的默认编码设置为 UTF-8。
            proc_env['PYTHONUTF8'] = '1'

            process = subprocess.Popen(
                command,
                cwd=subprocess_cwd,  # <--- 使用修正后的工作目录
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                env=proc_env,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            )

            self.sub_processes[window_key] = process

            def process_monitor():
                # communicate()会等待子进程结束，并一次性返回所有输出
                stdout, stderr = process.communicate()

                # --- 【鲁棒性优化】 ---
                # 仅当进程返回码不为0时，才将stderr视为致命错误
                # 这样可以忽略TensorFlow等库产生的无害警告
                if process.returncode != 0 and stderr:
                    error_message = f"子窗口 '{script_name}' 运行失败 (Exit Code: {process.returncode}):\n{stderr.strip()}"
                    print(f"[错误] {error_message}")
                    self._send_to_js('window.app.showAlert', error_message, 'error')
                elif stderr:
                    # 如果返回码为0但仍有stderr，则仅作为警告打印
                    print(f"[子窗口 '{script_name}' 警告]:\n{stderr.strip()}")
                # --- 【优化结束】 ---

                if stdout:
                    print(f"[子窗口 '{script_name}' 输出]:\n{stdout.strip()}")

                self.sub_processes.pop(window_key, None)
                if callback_on_close:
                    callback_on_close()

            threading.Thread(target=process_monitor, daemon=True).start()

        except Exception as e:
            error_msg = f"启动 '{script_name}' 失败: {e}"
            print(error_msg)
            self.show_alert(error_msg, "error")

    def refresh_font_list(self):
        """字体管理器关闭后的回调。"""
        self.config_manager.load()
        self.refresh_ui_settings()

    # --- 后端到前端的通信方法 ---

    def _send_to_js(self, func_name, *args):
        """安全地向前端发送事件的通用方法。"""
        if self._window:
            # 将所有参数序列化为JSON字符串
            js_args = ', '.join(json.dumps(arg) for arg in args)
            script = f'{func_name}({js_args})'
            self._window.evaluate_js(script)

    def on_history_loaded(self):
        """等待前端就绪，然后刷新UI列表。"""
        self.history_manager.run_auto_cleanup()
        print("[BACKEND] 历史记录已加载。正在等待JS就绪信号...")
        self.js_ready_event.wait()  # 阶段一：等待JS引擎启动

        print("[BACKEND] JS引擎已启动。正在等待前端UI完全就绪...")
        self.frontend_ready_event.wait()  # 阶段二：等待JS显式通知UI已准备好

        print("[BACKEND] 前端UI已完全就绪。正在向UI发送初始列表数据。")
        self.refresh_ui_lists()

    def update_status(self, message, is_error=False, workspace_id=None):
        # 行为1：更新工作区的状态日志
        if workspace_id:
            workspace = self.workspace_manager.workspaces.get(workspace_id)
            if workspace:
                from datetime import datetime
                timestamp = datetime.now().strftime("%H:%M:%S")
                workspace.status_log.append({"timestamp": timestamp, "message": message, "is_error": is_error})
                # 立即刷新UI，让日志实时显示
                self.refresh_ui_lists()

        # 行为2：更新底部状态栏（保持不变）
        self._send_to_js('window.app.updateStatus', message, is_error, workspace_id)

    def update_progress(self, workspace_id, value, text, visible=True):
        """更新工作区的进度条状态并通知前端。"""
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if workspace:
            workspace.progress = {"value": value, "text": text, "visible": visible}
            # 注意：这里我们不调用 refresh_ui_lists()，因为它会重绘整个列表，效率低。
            # 我们将创建一个专门的JS函数来更新单个工作区的进度条。
            self._send_to_js('window.app.updateWorkspaceProgress', workspace_id, workspace.progress)

    def show_alert(self, message, level='info'):  # level can be 'info', 'warning', 'error'
        self._send_to_js('window.app.showAlert', message, level)

    def update_plot(self, workspace_id: str, image_path: Optional[str]):
        """
        根据提供的图片路径，将其转换为Base64并发送到前端以更新主预览图。
        如果 image_path 为 None，则清空预览区。
        """
        if not image_path:
            self._send_to_js('window.app.displayPlot', workspace_id, None)
            return

        if not os.path.exists(image_path):
            print(f"警告: update_plot 收到一个不存在的路径: {image_path}")
            self._send_to_js('window.app.displayPlot', workspace_id, None)
            return

        try:
            mime_type, _ = mimetypes.guess_type(image_path)
            if not mime_type or not mime_type.startswith('image'):
                mime_type = "image/png"  # 提供一个安全默认值

            with open(image_path, "rb") as image_file:
                encoded_string = base64.b64encode(image_file.read()).decode('utf-8')

            base64_data = f"data:{mime_type};base64,{encoded_string}"

            self._send_to_js('window.app.displayPlot', workspace_id, base64_data)

        except Exception as e:
            print(f"错误: 在 update_plot 中转换图片为Base64时失败: {e}")
            self._send_to_js('window.app.displayPlot', workspace_id, None)

    def update_outputs_list(self, workspace_id: str, outputs_list: list):
        """将生成的输出文件列表推送到前端进行渲染。"""
        self._send_to_js('window.app.renderOutputs', workspace_id, outputs_list)

    def update_code_output(self, workspace_id, code):
        self._send_to_js('window.app.updateCodeOutput', workspace_id, code)

    def start_code_stream(self, workspace_id):
        """通知前端开始接收代码流。"""
        self._send_to_js('window.app.startCodeStream', workspace_id)

    def stream_code_chunk(self, workspace_id, chunk):
        """向前端发送一小块代码文本。"""
        self._send_to_js('window.app.appendCodeChunk', workspace_id, chunk)

    def end_code_stream(self, workspace_id, full_code):
        """通知前端代码流结束。"""
        self._send_to_js('window.app.endCodeStream', workspace_id, full_code)

    def update_console_output(self, workspace_id, text):
        self._send_to_js('window.app.updateConsoleOutput', workspace_id, text)

    # --- 【新增】用于文字分析的流式输出接口 ---
    def start_analysis_stream(self, workspace_id):
        """通知前端开始接收分析流，显示思考动画。"""
        self._send_to_js('window.app.startAnalysisStream', workspace_id)

    def stream_analysis_chunk(self, workspace_id, chunk):
        """向前端发送一小块分析文本。"""
        self._send_to_js('window.app.appendAnalysisChunk', workspace_id, chunk)

    def end_analysis_stream(self, workspace_id, full_text):
        """通知前端分析流结束，并发送完整文本用于后续处理。"""
        self._send_to_js('window.app.endAnalysisStream', workspace_id, full_text)
    # --- 【新增结束】 ---

    def set_ui_lock_state(self, is_locked: bool, workspace_id: Optional[str] = None):
        """
        设置UI的锁定状态。
        :param is_locked: 是否锁定。
        :param workspace_id: (可选) 触发此状态的工作区ID，用于精细化锁定。
        """
        self._send_to_js('window.app.setUILockState', is_locked, workspace_id)

    def refresh_ui_lists(self, history_override=None):
        """获取最新的工作区、历史记录和设置，并推送到前端。"""
        workspaces_data = {ws_id: ws.to_dict() for ws_id, ws in self.workspace_manager.workspaces.items()}

        source_history = history_override if history_override is not None else self.history_manager.all_history_metadata

        history_data = {
            item_id: {**metadata, 'id': item_id}
            for item_id, metadata in source_history.items()
        }

        # --- 核心修复：在这里也准备并包含 settings 数据 ---
        settings_data = self._prepare_settings_for_frontend()

        data = {
            "workspaces": {
                "items": workspaces_data,
                "active_id": self.workspace_manager.active_workspace_id
            },
            "history": history_data,
            "settings": settings_data  # <--- 将 settings 数据添加到 payload 中
        }
        self._send_to_js('window.app.renderLists', data)

    def refresh_ui_settings(self):
        # --- 修改：调用新的辅助方法 ---
        data = self._prepare_settings_for_frontend()
        self._send_to_js('window.app.renderSettings', data)

    # --- IPC 服务器 (for Navigator) ---
    def start_context_server(self):
        """在一个新线程中启动socket服务器。"""
        if self.ipc_server_thread is None or not self.ipc_server_thread.is_alive():
            self.ipc_server_thread = threading.Thread(target=self._ipc_server_loop, daemon=True)
            self.ipc_server_thread.start()

    def _ipc_server_loop(self):
        host, port = '127.0.0.1', 65432
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server_socket.bind((host, port))
            server_socket.listen()
            self.server_socket = server_socket
            print(f"IPC Server listening on {host}:{port}")
            while True:
                conn, _ = server_socket.accept()
                threading.Thread(target=self._handle_navigator_client, args=(conn,), daemon=True).start()
        except OSError:
            print("IPC Server socket closed.")
        finally:
            server_socket.close()

    def _handle_navigator_client(self, conn):
        try:
            while True:
                data = conn.recv(1024)
                if not data or data.decode('utf-8') != "GET_CONTEXT":
                    break
                context_data = self._get_full_context()
                response_payload = json.dumps(context_data, ensure_ascii=False).encode('utf-8')
                conn.sendall(response_payload + b"<END_OF_MESSAGE>")
        except (ConnectionResetError, BrokenPipeError):
            pass
        finally:
            conn.close()

    def _get_full_context(self):
        """为Navigator收集所有必要的上下文。"""
        active_ws = self.workspace_manager.get_active_workspace()
        if not active_ws:
            return {"app_status": "空闲 (无活动工作区)", "workspace_state": {},
                    "file_structure": get_project_structure(), "model_config": {}}

        status = "正在运行..." if active_ws.is_running else "空闲"
        workspace_state = {
            "当前工作区ID": active_ws.id, "应用状态": status,
            "数据文件": [f['original_name'] for f in active_ws.managed_files.get('data', [])],
            "参考文件": [f['original_name'] for f in active_ws.managed_files.get('prompt', [])],
            "数据输入框文本": active_ws.data_input_text.strip(),
            "用户指令": active_ws.prompt_input_text.strip(),
            "最后生成的代码": active_ws.last_generated_code.strip(),
            "控制台输出": active_ws.console_output.strip()
        }
        return {
            "app_status": status, "workspace_state": workspace_state,
            "file_structure": get_project_structure(), "model_config": active_ws.model_config
        }

    def test_llm_connection(self, workspace_id: str):
        """测试当前工作区的大模型API连通性。"""
        workspace = self.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            return {"status": "error", "message": "工作区未找到"}

        # 告知前端开始测试
        self._send_to_js('window.app.updateLLMStatus', {"status": "testing", "message": URL_STATUS_COLORS["testing"][1]})

        api_type = workspace.api_type
        api_config_key = f"{api_type}_api"
        api_config = workspace.model_config.get(api_config_key, {})

        # 在后台线程中执行网络请求
        def run_test():
            result = app_logic.perform_llm_test(api_config)
            # 将结果发送回前端
            self._send_to_js('window.app.updateLLMStatus', result)

        threading.Thread(target=run_test, daemon=True).start()
        return {"status": "ok", "message": "测试已开始"}

    # --- 应用关闭逻辑 ---
    def on_closing(self):
        """处理窗口关闭事件。"""
        active_ws = self.workspace_manager.get_active_workspace()
        if active_ws:
            self.save_current_workspace_state(active_ws.id, active_ws.to_dict())

        self.history_manager.save_cache_on_exit()

        for process in self.sub_processes.values():
            if process.poll() is None:
                process.terminate()

        if self.server_socket:
            self.server_socket.close()

    def _run_pip_install(self, requirements_file, install_type):
        """通用 pip 安装函数"""
        try:
            python_exe = get_python_executable()
            req_path = resource_path(requirements_file)

            # 使用 Popen 实时读取输出，可以用于更详细的进度反馈
            process = subprocess.Popen(
                [python_exe, "-m", "pip", "install", "-r", req_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            )

            for line in iter(process.stdout.readline, ''):
                # 可以在这里解析pip的输出，向前端发送更详细的进度
                print(f"[{install_type} Install]: {line.strip()}")

            process.wait()
            return process.returncode == 0
        except Exception as e:
            self.show_alert(f"{install_type} 安装失败: {e}", "error")
            print(f"ERROR: Pip install failed for {install_type}: {e}")
            return False

    def _perform_startup_checks(self):
        """
        在应用启动时执行检查，决定是否显示安装向导。
        这会在一个新的线程中运行，以避免阻塞主线程。
        """

        def checker():
            # 等待前端完全就绪
            self.frontend_ready_event.wait()

            # 检查安装完成标记
            if not self.config_manager.settings.get("full_setup_complete", False):
                # 如果未完成安装，调用JS函数显示安装向导
                self._send_to_js('window.app.showSetupWizard')

        threading.Thread(target=checker, daemon=True).start()

    def _run_command(self, command, log_prefix, progress_callback=None, progress_start=0, progress_end=100):
        """通用命令执行函数，增加了模拟平滑进度的功能"""
        try:
            # --- 【核心修改：在这里也强制子进程使用UTF-8】 ---
            proc_env = os.environ.copy()
            proc_env['PYTHONUTF8'] = '1'
            # --- 【修改结束】 ---

            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=proc_env,  # <--- 将修改后的环境变量传递给子进程
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
            )

            current_progress = progress_start

            # 因为 Popen 没有设置 text=True, stdout.readline() 返回的是 bytes
            for line_bytes in iter(process.stdout.readline, b''):
                # 所以我们需要在这里手动用 utf-8 解码，现在源头和解码方式一致了
                line = line_bytes.decode('utf-8', errors='ignore').strip()

                if line:
                    print(f"[{log_prefix}]: {line}")

                    # --- 【平滑进度模拟】 ---
                    remaining_distance = progress_end - current_progress
                    increment = remaining_distance * 0.05
                    current_progress += max(increment, 0.01)
                    current_progress = min(current_progress, progress_end)

                    if progress_callback:
                        progress_callback(line, current_progress)
                    # --- 【修改结束】 ---

            process.wait()
            # 确保命令成功结束后，最终进度能准确到达目标点
            if process.returncode == 0 and progress_callback:
                progress_callback("阶段完成。", progress_end)

            return process.returncode == 0
        except Exception as e:
            current_progress = progress_start
            error_message = f"{log_prefix} 失败: {e}"
            self.show_alert(error_message, "error")
            print(f"ERROR: Command failed for {log_prefix}: {e}")
            if progress_callback:
                progress_callback(error_message, current_progress)
            return False

    # 我们将 _run_pip_install 替换为更通用的 _run_command

    def start_full_setup(self):
        """【选择1】完整安装模式 (带实时进度)"""

        def task():
            python_exe = get_python_executable()

            def progress_callback_with_value(line, progress):
                self._send_to_js('window.app.updateSetupProgress', progress, line)

            # --- 【新增步骤 0: 准备构建环境】 (进度 0% -> 5%) ---
            self._send_to_js('window.app.updateSetupProgress', 0, "正在准备安装环境 (0/4)...")
            success = self._run_command(
                [python_exe, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"],
                "Build Tools Upgrade",
                progress_callback=progress_callback_with_value,
                progress_start=0,
                progress_end=5
            )
            if not success:
                self._send_to_js('window.app.setupFailed', "安装环境准备失败，请检查网络或权限。")
                return

            # --- 步骤 1: 安装核心库 (进度范围 5% -> 35%) ---
            self._send_to_js('window.app.updateSetupProgress', 5, "准备安装核心组件 (1/4)...")
            success = self._run_command(
                [python_exe, "-m", "pip", "install", "-r", resource_path('requirements_core.txt')],
                "Core Install",
                progress_callback=progress_callback_with_value,
                progress_start=5,
                progress_end=35
            )
            if not success:
                self._send_to_js('window.app.setupFailed', "核心组件安装失败。")
                return

            # --- 步骤 2: 安装重型库 (进度范围 35% -> 75%) ---
            self._send_to_js('window.app.updateSetupProgress', 35, "正在安装AI引擎 (2/4)，此过程可能较慢...")
            success = self._run_command(
                [python_exe, "-m", "pip", "install", "-r", resource_path('requirements_heavy.txt')],
                "Heavy Libs Install",
                progress_callback=progress_callback_with_value,
                progress_start=35,
                progress_end=75
            )
            if not success:
                self._send_to_js('window.app.setupFailed', "AI引擎安装失败。")
                return

            # --- 步骤 3: 下载AI模型 (进度范围 75% -> 95%) ---
            self._send_to_js('window.app.updateSetupProgress', 75, "正在下载AI模型 (3/4)，请保持网络通畅...")
            success = self._run_command(
                [python_exe, resource_path('download_models.py')],
                "Model Download",
                progress_callback=progress_callback_with_value,
                progress_start=75,
                progress_end=95
            )
            if not success:
                self._send_to_js('window.app.setupFailed', "AI模型下载失败，请检查网络连接。")
                return

            # --- 步骤 4: 全部完成 ---
            self.config_manager.settings["full_setup_complete"] = True
            self.config_manager.save()
            self._send_to_js('window.app.updateSetupProgress', 100, "全部组件安装完成！ (4/4)")
            self._send_to_js('window.app.setupComplete')

        threading.Thread(target=task, daemon=True).start()
        return {"status": "ok", "message": "Full setup started."}

    def start_phased_setup(self):
        """【选择2】快速启动模式 (带实时进度)"""

        def task():
            python_exe = get_python_executable()

            def progress_callback_with_value(line, progress):
                self._send_to_js('window.app.updateSetupProgress', progress, line)

            # --- 【新增步骤 0: 准备构建环境】 (进度 0% -> 5%) ---
            self._send_to_js('window.app.updateSetupProgress', 0, "正在准备安装环境...")
            success = self._run_command(
                [python_exe, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"],
                "Build Tools Upgrade",
                progress_callback=progress_callback_with_value,
                progress_start=0,
                progress_end=5
            )
            if not success:
                self._send_to_js('window.app.setupFailed', "安装环境准备失败，无法启动。")
                return

            # 1. 安装核心库 (进度范围 5% -> 95%)
            self._send_to_js('window.app.updateSetupProgress', 5, "准备安装核心组件...")
            success = self._run_command(
                [python_exe, "-m", "pip", "install", "-r", resource_path('requirements_core.txt')],
                "Core Install",
                progress_callback=progress_callback_with_value,
                progress_start=5,
                progress_end=95
            )

            if not success:
                self._send_to_js('window.app.setupFailed', "核心组件安装失败，无法启动。")
                return

            self._send_to_js('window.app.updateSetupProgress', 100, "核心组件安装完成！应用即将启动...")
            self._send_to_js('window.app.setupComplete')

            # 后续的后台安装部分保持不变...
            self.is_heavy_install_running = True
            self._send_to_js('window.app.setAuxiliaryButtonsDisabled', True)
            try:
                self.update_status("后台准备中：正在安装AI引擎...", is_error=False)
                success = self._run_command(
                    [python_exe, "-m", "pip", "install", "-r", resource_path('requirements_heavy.txt')],
                    "Heavy Libs Install")
                if not success:
                    self.show_alert("AI高级功能安装失败，请稍后在设置中重试。", "error")
                    return

                self.update_status("后台准备中：正在下载AI模型...", is_error=False)
                success = self._run_command([python_exe, resource_path('download_models.py')], "Model Download")

                if success:
                    self.config_manager.settings["full_setup_complete"] = True
                    self.config_manager.save()
                    self.show_alert("所有AI高级功能（如智能导航助手）已准备就绪！", "info")
                else:
                    self.show_alert("AI模型下载失败，请稍后在设置中重试。", "error")
            finally:
                self.is_heavy_install_running = False
                self._send_to_js('window.app.setAuxiliaryButtonsDisabled', False)

        threading.Thread(target=task, daemon=True).start()
        return {"status": "ok", "message": "Phased setup started."}
