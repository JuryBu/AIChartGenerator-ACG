# utils.py

import os
import sys
import shutil


def format_file_size(size_bytes):
    """将字节大小格式化为可读的字符串 (KB, MB, GB)"""
    if not isinstance(size_bytes, (int, float)):
        return ""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    kb = size_bytes / 1024
    if kb < 1024:
        return f"{kb:.1f} KB"
    mb = kb / 1024
    if mb < 1024:
        return f"{mb:.1f} MB"
    gb = mb / 1024
    return f"{gb:.1f} GB"


def get_python_executable():
    """获取嵌入式Python解释器的路径，无论是开发环境还是打包后。"""
    if getattr(sys, 'frozen', False):
        # 打包后，python.exe 位于 .exe 文件旁的 'python' 文件夹中
        base_path = os.path.dirname(sys.executable)
        return os.path.join(base_path, 'python', 'python.exe')
    else:
        # 开发环境中，直接使用当前环境的 python 解释器
        return sys.executable


def resource_path(relative_path):
    """
    获取资源的绝对路径，无论是开发环境还是PyInstaller打包后都可使用。
    这是最稳健的实现方式，能正确处理新版PyInstaller的 _internal 文件夹。
    """
    try:
        base_path = sys._MEIPASS
    except Exception:
        # 如果不是在 PyInstaller 环境中运行，则使用常规路径
        base_path = os.path.dirname(os.path.abspath(__file__))

    return os.path.join(base_path, relative_path)


def get_app_base_path(relative_path='.'):
    """
    获取【应用根目录】的绝对路径，指向 .exe 所在的文件夹。
    用于 python/, models_cache/, history/ 等。
    """
    if getattr(sys, 'frozen', False):
        # 如果是打包状态，基础路径是可执行文件所在的目录
        base_path = os.path.dirname(sys.executable)
    else:
        # 开发环境下，是当前文件所在的目录
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def clean_llm_output(text: str) -> str:
    """
    清理从LLM返回的文本，移除除换行符和制表符之外的所有ASCII控制字符。
    这可以防止因不可见字符（如\f）导致的渲染错误，同时保留段落格式。
    """
    if not isinstance(text, str):
        return ""

    # 构建一个只包含允许字符的新字符串
    # chr.isprintable() 会判断字符是否为可见字符（字母、数字、标点、空格等）
    # 我们额外允许 \n (换行) 和 \t (制表符)
    cleaned_chars = [char for char in text if char.isprintable() or char in ('\n', '\t')]

    return "".join(cleaned_chars)


def get_project_structure(root_dir="."): # <-- 增加默认参数
    """
    生成项目文件结构的字符串表示。
    对特定文件夹会显示其内部文件。
    """
    structure = "项目文件结构概览:\n"
    # 特殊文件夹列表，将对其进行一级深度遍历
    special_dirs = ["说明图片", "字体", "history", "input", "output", "web"] # <-- 增加了 web 文件夹

    try:
        # 确保路径存在
        if not os.path.isdir(root_dir):
            return f"错误: 根目录 '{root_dir}' 不存在。"

        for item in sorted(os.listdir(root_dir)):
            path = os.path.join(root_dir, item)
            # 过滤掉不必要的文件和文件夹
            if item.startswith('.') or item in ['__pycache__', 'dist', 'build']:
                continue

            if os.path.isdir(path):
                structure += f"└── {item}/\n"
                if item in special_dirs:
                    try:
                        sub_items = sorted(os.listdir(path))
                        if not sub_items:
                            structure += f"    ├── (空)\n"
                        else:
                            for sub_item in sub_items:
                                structure += f"    ├── {sub_item}\n"
                    except OSError:
                        structure += f"    ├── (无法访问)\n"
            else: # isfile
                structure += f"└── {item}\n"

    except Exception as e:
        return f"扫描项目结构时出错: {e}"

    return structure


def clear_and_recreate_dir(directory_path):
    """
    安全地清空并重新创建指定目录。
    如果目录存在，则删除整个目录树；然后无论如何都创建一个新目录。
    """
    try:
        if os.path.exists(directory_path):
            shutil.rmtree(directory_path)
        os.makedirs(directory_path, exist_ok=True)
        print(f"已成功清理并重新创建目录: {directory_path}")
    except Exception as e:
        print(f"错误: 清理或创建目录 {directory_path} 失败: {e}")