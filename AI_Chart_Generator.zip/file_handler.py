# file_handler.py

import os
import sys
import shutil
import zipfile
from pathlib import Path
import subprocess
from constants import INPUT_DIR, OUTPUT_DIR, HISTORY_DIR, IMAGE_EXTENSIONS
from utils import resource_path, get_python_executable
from typing import TYPE_CHECKING, Optional
from utils import format_file_size
if TYPE_CHECKING:
    from main_app_api import MainAppApi


def _create_data_preview_if_needed(api: "MainAppApi", original_file_path: str) -> Optional[str]:
    """
    通过调用外部脚本来创建数据文件的预览，以使用未打包的pandas库。
    返回：预览文件的路径，或 None (如果不满足条件或失败)
    """
    supported_extensions = ['.csv', '.txt', '.xlsx', '.xls']
    _, extension = os.path.splitext(original_file_path)

    if extension.lower() not in supported_extensions:
        return None

    try:
        python_exe = get_python_executable() # 获取嵌入式Python解释器路径
        script_path = resource_path("create_preview.py") # 获取预览脚本的路径

        # 准备执行命令
        command = [python_exe, script_path, original_file_path]

        # 执行子进程
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding='utf-8',
            check=False, # 我们手动检查返回码
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        )

        # 检查执行结果
        if result.returncode == 0:
            preview_path = result.stdout.strip()
            if preview_path == "NO_PREVIEW_NEEDED":
                # 文件行数少，不需要预览
                return None
            elif os.path.exists(preview_path):
                # 成功创建并返回路径
                print(f"[DEBUG] 成功创建预览文件: {preview_path}")
                return preview_path
            else:
                # 脚本成功但路径无效，记录错误
                print(f"[DEBUG] 预览脚本成功运行，但返回的路径无效: {preview_path}")
                return None
        else:
            # 子进程执行失败，记录错误日志
            error_message = result.stderr.strip()
            full_error = f"为 {os.path.basename(original_file_path)} 创建预览时出错: {error_message}"
            print(f"[DEBUG] {full_error}")
            api.show_alert(full_error, "warning")
            return None

    except Exception as e:
        # 捕获启动子进程等其他可能的错误
        error_msg = f"启动预览生成器时发生错误: {e}"
        print(f"[DEBUG] {error_msg}")
        api.show_alert(error_msg, "warning")
        return None


def setup_io_folders(api: "MainAppApi"):
    """确保 input, output 和 history 文件夹存在。"""
    os.makedirs(INPUT_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(HISTORY_DIR, exist_ok=True)
    clear_io_folders(api)


def clear_io_folders(api: "MainAppApi"):
    """清空 input 和 output 文件夹下的所有内容。"""
    for folder in [INPUT_DIR, OUTPUT_DIR]:
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                api.show_alert(f"删除 {file_path} 失败. 原因: {e}", "error")


def remove_file_input(api: "MainAppApi", target: str, workspace_id: str, preview_id: str):
    """从数据模型和文件系统中移除一个已添加的文件及其衍生物（如预览）。"""
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        return

    file_to_remove = None
    for f in workspace.managed_files[target]:
        if f['preview_id'] == preview_id:
            file_to_remove = f
            break

    if file_to_remove:
        workspace.managed_files[target].remove(file_to_remove)

        # 删除主文件
        try:
            os.remove(preview_id)
        except OSError as e:
            error_msg = f"删除文件失败 {preview_id}: {e}"
            print(f"[DEBUG] {error_msg}")
            api.show_alert(error_msg, "error")

        # 检查并删除关联的预览文件
        if file_to_remove.get('preview_path') and os.path.exists(file_to_remove['preview_path']):
            try:
                os.remove(file_to_remove['preview_path'])
            except OSError as e:
                # 使用api对象报告错误
                error_msg = f"删除预览文件失败 {file_to_remove['preview_path']}: {e}"
                print(f"[DEBUG] {error_msg}") # 保留用于调试
                api.show_alert(error_msg, "error")

        api.refresh_ui_lists()


def add_file_input(api: "MainAppApi", filepath: str, target: str, workspace_id: str):
    """添加一个文件到文件系统，创建衍生物，并更新工作区数据模型。"""
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        api.show_alert("警告：没有活动的工作区，无法添加文件。", "warning")
        return

    if any(f['original_path'] == filepath for f in workspace.managed_files[target]):
        return

    base_name = os.path.basename(filepath)
    file_ext = os.path.splitext(base_name)[1].lower()

    managed_name = base_name
    dest_path = os.path.join(INPUT_DIR, managed_name)
    counter = 1
    while os.path.exists(dest_path):
        name, ext = os.path.splitext(base_name)
        managed_name = f"{name}_{counter}{ext}"
        dest_path = os.path.join(INPUT_DIR, managed_name)
        counter += 1

    try:
        shutil.copy2(filepath, dest_path)
    except Exception as e:
        api.show_alert(f"文件复制失败: 无法将文件复制到 input 文件夹: {e}", "error")
        return

    preview_path = None
    if target == 'data':
        preview_path = _create_data_preview_if_needed(api, dest_path)

    # --- 核心修改：扩展 file_info ---
    file_size_bytes = os.path.getsize(dest_path)
    file_type = 'image' if file_ext in IMAGE_EXTENSIONS else 'generic'

    # --- 关键修改：先获取绝对路径，然后复用它 ---
    absolute_dest_path = Path(dest_path).resolve() # <-- 1. 先解析出绝对路径对象

    file_info = {
        'original_path': filepath,
        'original_name': base_name,
        'managed_name': managed_name,
        'preview_id': dest_path,
        'preview_path': preview_path,
        'is_preview': bool(preview_path),
        # --- 新增字段 ---
        "full_path": str(absolute_dest_path),               # <-- 2. 使用绝对路径对象
        "preview_uri": absolute_dest_path.as_uri(),         # <-- 3. 对绝对路径对象调用 as_uri()
        "file_type": file_type,                             # 'image' 或 'generic'
        "file_ext": file_ext.replace('.', '').upper(),      # 'PNG', 'CSV', etc.
        "file_size_str": format_file_size(file_size_bytes), # '12.3 KB'
    }
    workspace.managed_files[target].append(file_info)

    api.refresh_ui_lists()


def clear_input_area(api: "MainAppApi", target: str, workspace_id: str):
    """清空指定输入区域的所有文件及其衍生物。"""
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        return

    files_to_remove = list(workspace.managed_files[target])
    for file_info in files_to_remove:
        try:
            os.remove(file_info['preview_id'])
        except OSError as e:
            api.show_alert(f"清空文件时出错 {file_info['preview_id']}: {e}", "error")

        if file_info.get('preview_path') and os.path.exists(file_info['preview_path']):
            try:
                os.remove(file_info['preview_path'])
            except OSError as e:
                api.show_alert(f"清空预览文件时出错 {file_info['preview_path']}: {e}", "error")

    workspace.managed_files[target].clear()

    if target == 'data':
        api.update_status(f"工作区 '{workspace.name}' 的数据输入文件已清空。", workspace_id=workspace_id)

    api.refresh_ui_lists()


def save_single_output_file(api: "MainAppApi", source_path: str, destination_path: str):
    """
    将单个源文件复制到目标路径。
    """
    try:
        shutil.copy2(source_path, destination_path)
        api.show_alert(f"文件已成功保存至\n{destination_path}", "info")
    except Exception as e:
        error_msg = f"保存文件失败: {e}"
        print(f"[ERROR] {error_msg}")
        api.show_alert(error_msg, "error")


def save_all_outputs_as_zip(api: "MainAppApi", workspace_id: str, zip_path: str):
    """
    将指定工作区的所有生成输出打包成一个ZIP文件。
    """
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        return

    if not workspace.generated_outputs:
        api.show_alert("当前工作区没有可保存的输出文件。", "warning")
        return

    try:
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for item in workspace.generated_outputs:
                source_file_path = item.get('final_path')
                file_name_in_zip = item.get('filename')

                # 确保路径和文件名都有效
                if not source_file_path or not file_name_in_zip:
                    continue

                # 检查源文件是否存在
                if os.path.exists(source_file_path):
                    # 使用 arcname 来确保 ZIP 包内是干净的文件名
                    zipf.write(source_file_path, arcname=file_name_in_zip)
                else:
                    print(f"警告: 打包时跳过不存在的文件: {source_file_path}")

        # 压缩成功后通知用户
        api.show_alert(f"所有输出文件已成功打包至\n{zip_path}", "info")

    except Exception as e:
        # 捕获并报告任何压缩错误
        api.show_alert(f"创建ZIP文件失败: {e}", "error")