# config_manager.py

import os
import sys
import json

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path



class ConfigManager:
    """负责加载、保存和管理 config.json 和 settings.json。"""

    def __init__(self):
        """
        初始化配置管理器。
        这个类现在是独立的，不依赖于任何外部应用实例。
        """
        self.config = {}
        self.settings = {}
        self.load()

    def load(self):
        """从文件加载配置和设置到内存字典中。"""
        # --- config.json ---
        try:
            config_path = resource_path("config.json")
            with open(config_path, "r", encoding="utf-8") as f:
                self.config = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            self.config = {
                "api_type": "external", # <-- 新增
                "external_api": {"base_url": "", "api_key": "", "model": ""},
                # --- 新增：本地API默认配置 ---
                "local_api": {
                    "base_url": "http://localhost:1234/v1",
                    "api_key": "not-needed",
                    "model": "local-model"
                },
                # --- 结束新增 ---
                "common_external_models": ["gemini-1.5-pro-latest"],
                "plotting_font": "NotoSansSC",
                # --- 新增默认 system_prompt ---
                "system_prompt": "你是一个数据可视化专家，你的任务是根据用户的要求，编写能够生成高质量图表的Python代码。请直接输出代码，不要包含任何解释或额外的文字。",
                # --- 结束新增 ---
                "font_mapping": {
                    "黑体 (SimHei)": "simhei.ttf",
                    "NotoSansSC": "NotoSansSC.ttf",
                    "Times New Roman": "times.ttf"
                }
            }

        # --- UI和其他设置 (settings.json) ---
        try:
            settings_path = resource_path("settings.json")
            with open(settings_path, "r", encoding="utf-8") as f:
                self.settings = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # A default settings dictionary can be defined here if needed.
            self.settings = {
                "max_retries": 3,  # 最好也在这里为纠错次数提供一个默认值
                "max_agent_retries": 3,  # 新增：Agent评估次数上限
                "auto_cleanup_enabled": False,
                "cleanup_period": "一个月内",
                "cleanup_custom_days": 30
            }

    def save(self, config_data: dict = None, settings_data: dict = None):
        """
        将内存中的配置保存到文件。
        如果提供了 config_data 或 settings_data，会先用它们更新内存中的配置。

        Args:
            config_data (dict, optional): 包含要更新的 config.json 数据的字典。
            settings_data (dict, optional): 包含要更新的 settings.json 数据的字典。
        """
        # 如果传入了新的配置数据，则更新内存中的字典
        if config_data is not None:
            self.config.update(config_data)
        if settings_data is not None:
            self.settings.update(settings_data)

        # 将内存中的字典持久化到JSON文件
        try:
            config_path = resource_path("config.json")
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"保存 config.json 失败: {e}")

        try:
            settings_path = resource_path("settings.json")
            with open(settings_path, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"保存 settings.json 失败: {e}")

    def remove_font(self, font_filename: str) -> bool:
        """从配置中移除一个字体，并处理默认字体回退。"""
        font_mapping = self.config.get("font_mapping", {})
        key_to_delete = None
        for key, value in font_mapping.items():
            if value == font_filename:
                key_to_delete = key
                break

        if key_to_delete:
            del font_mapping[key_to_delete]
            # 如果默认字体被删了，设置一个新的默认字体
            if self.config.get("plotting_font") == key_to_delete:
                # 选择剩余的第一个字体作为新的默认值，如果没有则为空字符串
                new_default = next(iter(font_mapping.keys()), "")
                self.config["plotting_font"] = new_default

            # 立即保存更改。调用 save() 时不带参数，
            # 它会将当前 self.config 的状态写入文件。
            self.save()
            return True
        return False