# constants.py

import os

# --- Constants ---
INPUT_DIR = "input"
OUTPUT_DIR = "output"
HISTORY_DIR = "history"

IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'}


ALLOWED_FILE_TYPES = [
    ("All supported files", "*.txt *.csv *.png *.jpg *.jpeg *.pdf *.xlsx *.xls"),
    ("Data files", "*.csv *.xlsx *.xls *.txt"),
    ("Image files", "*.png *.jpg *.jpeg"),
    ("Document files", "*.pdf *.txt")
]
MAX_PREVIEW_SIZE = (150, 100)

# --- 漂亮的调色板 ---
COLOR_PALETTE = [
    # Reds & Pinks
    "#E57373", "#F06292", "#C2185B", "#D32F2F",
    # Oranges & Yellows
    "#FFB74D", "#FF8F00", "#FBC02D", "#F57C00",
    # Greens
    "#81C784", "#4CAF50", "#2E7D32", "#689F38",
    # Blues
    "#64B5F6", "#1976D2", "#0288D1", "#0097A7",
    # Purples & Violets
    "#9575CD", "#7E57C2", "#512DA8", "#673AB7",
    # Grays & Browns
    "#BDBDBD", "#757575", "#5D4037", "#A1887F",
]

# --- Settings Keys ---
SETTINGS_AUTO_CLEANUP_ENABLED = "auto_cleanup_enabled"
SETTINGS_AUTO_CLEANUP_PERIOD = "auto_cleanup_period"
SETTINGS_AUTO_CLEANUP_CUSTOM_DAYS = "auto_cleanup_custom_days"
SETTINGS_HISTORY_SEARCH_TYPE = "history_search_type"
HISTORY_CACHE_FILE = "history_cache.json"

# --- 新增：URL连通性测试相关常量 ---
URL_TEST_TIMEOUT = 30  # 超时时间（秒）

URL_STATUS_COLORS = {
    "idle": ("#7f8c8d", "待测试"),      # 灰色
    "testing": ("#3498db", "测试中..."),   # 蓝色
    "success": ("#27ae60", "可用"),   # 绿色
    "timeout": ("#f39c12", "超时"),   # 黄色
    "error": ("#c0392b", "无法连接"),      # 红色
}
# --- 结束新增 ---
