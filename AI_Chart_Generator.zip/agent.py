import os
import sys
import re
import subprocess

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from llm_service import LLMService
from utils import get_python_executable, get_app_base_path

# AI生成的代码将被写入这个文件
CODE_FILE = "Navi.py"
MAX_ATTEMPTS = 6  # 设置最大尝试次数，防止无限循环


class CodeExecutionAgent:
    def __init__(self, llm_service: LLMService):
        self.llm_service = llm_service
        self.internal_history = []
        self.attempts = 0

    def _build_system_prompt(self, user_query, project_context,
                             rag_context):  # <--- 正确！现在是 CodeExecutionAgent 类的一个方法
        """构建指导Agent行为的系统Prompt"""
        return f"""
    你是一个能够通过编写和执行Python代码来解决问题的AI智能体。你的名字叫Navi。

    # 目标
    你的最终目标是回答用户的原始问题: "{user_query}"

    # 可用工具
    - 你唯一的工具是一个Python 3.9 代码执行器。
    - 你可以访问当前目录下的所有文件。项目上下文信息如下：
    {project_context}

    # 历史参考信息 (RAG)
    {rag_context if rag_context else "没有可用的历史参考信息。"}

    你将通过一个“思考 -> 编码 -> 观察”的循环来工作：
    1.  **思考 (Thinking)**: 首先，结合历史参考信息和项目上下文，仔细思考你需要哪些信息来回答用户的问题，并制定一个清晰的计划。将你的思考过程和计划写在 `<thinking>`和`</thinking>`包裹之间。
    2.  **编码 (Tool Code)**: 接下来，编写一小段Python代码来实现你计划中的一步。将代码放在 `<tool_code>`和`</tool_code>`包裹之间。你的代码必须是可执行的，并且应该使用 `print()` 函数来输出你需要查看的结果（例如，文件内容、变量值等）。
    3.  **观察 (Observation)**: 我会执行你的代码，并将代码的输出 (stdout) 和错误 (stderr) 作为观察结果反馈给你。你会收到一个 `<observation>` 标签，里面包含了代码执行的**全部**结果。
    4.  **重复**: 你需要分析观察结果。
        - **【极其重要】**: `<observation>` 标签内的内容是代码执行返回的**绝对事实**，是**最高优先级的 ground truth**。你的下一步思考**必须**完全基于这个观察结果，**即使它与你之前的预期或RAG信息不符**。你必须接受并分析这个事实，然后决定下一步是继续编码还是给出最终答案。
        - 如果代码执行成功并获得了你需要的信息，继续思考下一步计划和代码。
        - 如果代码执行出错，仔细阅读错误信息，在下一次的 `<thinking>` 中分析错误原因，并修正你的 `<tool_code>`。
        - 重复这个循环，直到你收集到足够的信息来最终回答用户的问题。
    5.  **最终答案**: 当你确信已经找到答案时，请务必在 `<final_answer>`和`</final_answer>`包裹之间，用友好和完整的语言向用户提供最终的答案，不可只用其一而不包裹。

    #对编写访问程序相关信息的一些代码提醒
    1，对涉及查询之前对话信息的，可以特殊地不进行代码编写读取信息而是由刚刚提供给你的历史参考信息 (RAG)分析，它同时为你提供了相关性可能较高的信息提醒。如有不确定，也可以访问navigator_history.json。
    2，对涉及主程序的历史状态的可以访问history文件夹，history/history_cache.json记录了当前的所有历史记录的状态，history下对应的各个文件夹信息都在其中，每个历史记录文件夹里的inputs文件夹记载了当前历史记录的当时输入文件，metadata.json记录了输入和输出所有与文字相关的部分，其余文件都是输出的对应结果文件。
    3，对涉及用户当前全局模型配置和全局字体配置的问题可以访问config.json。
    4，对涉及“使用说明”功能内容的文字部分内容在help_content.json里，其中标记的对应图片在“说明图片”文件夹里。
    5，对涉及历史记录功能的自动清除设定的信息都在settings.json里。
    6，当前所有已有本地字体信息都在“字体”文件夹里。
    7，程序所有当前工作区的输入内容都在input文件夹里，所有输出内容都在output文件夹里。
    8，程序的核心是main.py，涉及大模型的内容是llm_service.py实现。
    9，和智能助手相关的代码是navigator.py（智能助手主代码），agent.py（单智能体式agent流程自动读取内容），Navi.py（前者用于读取内容的专用文件），rag_handler.py（RAG优化Navi智能助手上下文注意力组件），以及web文件夹的html,css,js对应前端文件。
    10，和工作区相关的代码是 workspace_manager.py, 和 workspace_model.py 代码，主程序运行时创建的工作区信息主要存储在内存中。

    # 重要规则
    - **标签内正文不能出现别的标签**: 比如`<thinking>`和`</thinking>`之间不能出现`<tool_code>`，`</tool_code>`，`<final_answer>`或`</final_answer>`，别的标签之间的正文也类似。
    - **必须使用标签**: 你的每一次回复正文都必须被包含在 `<thinking>` 标签，以及 `<tool_code>` 或 `<final_answer>` 之一，不允许有在这三者之外的内容。
    - **代码要简单**: 每次只编写一小段专注于单一任务的代码。
    - **使用print()**: 你的代码必须通过 `print()` 输出结果，否则我无法知道代码执行了什么。
    - **安全第一**: 任何情况下，不要编写任何删除、修改文件或执行危险系统命令的代码。专注于读取和分析。
    """

    def _execute_code(self, code):
        """安全地执行代码并返回输出和错误"""
        # 1. 【核心修复】获取应用根目录（.exe所在位置）
        app_base_path = get_app_base_path()
        code_file_path = os.path.join(app_base_path, CODE_FILE)
        python_exe = get_python_executable()

        print(f"[AGENT DEBUG] App Base Path: {app_base_path}")
        print(f"[AGENT DEBUG] Python Executable: {python_exe}")
        print(f"[AGENT DEBUG] Code File Path: {code_file_path}")

        try:
            # 将代码写入到正确的、可写的路径
            with open(code_file_path, 'w', encoding='utf-8') as f:
                f.write(code)

            # 准备环境和Windows特定的启动标志 (这部分逻辑不变)
            proc_env = os.environ.copy()
            proc_env['PYTHONUTF8'] = '1'

            creation_flags = 0
            if sys.platform == "win32":
                creation_flags = subprocess.CREATE_NO_WINDOW

            # 使用subprocess在一个独立的、安全的进程中执行代码
            result = subprocess.run(
                [python_exe, code_file_path], # <--- 使用绝对路径
                capture_output=True,
                text=True,
                timeout=30,
                encoding='utf-8',
                errors='replace',
                env=proc_env,
                creationflags=creation_flags,
                cwd=app_base_path  # 【新增】将子进程的工作目录也设置为应用根目录
            )

            # 清理生成的代码文件
            os.remove(code_file_path)

            stdout = result.stdout.strip()
            stderr = result.stderr.strip()

            if stderr:
                return f"代码执行出错:\n{stderr}"
            elif stdout:
                return f"代码执行成功，输出:\n{stdout}"
            else:
                return "代码执行成功，但没有任何输出。"

        except subprocess.TimeoutExpired:
            if os.path.exists(code_file_path):
                os.remove(code_file_path)
            print("[AGENT] Code execution timed out.")
            return "代码执行超时（超过30秒）。请检查代码是否存在无限循环或长时间操作。"
        except Exception as e:
            if os.path.exists(code_file_path):
                os.remove(code_file_path)
            print(f"[AGENT] An unexpected error occurred during code execution: {e}")
            return f"执行代码时发生意外错误: {e}"

    def _parse_llm_response(self, response):
        """
        【全新鲁棒解析器 v2.0】
        使用基于正则表达式分割和状态机的解析方法，以应对LLM输出的各种不规范情况。
        此方法可以极大地提高解析的准确性和健壮性。
        """
        thinking = ""
        code = ""
        final_answer = ""

        # 定义我们关心的所有标签
        tags = ["thinking", "tool_code", "final_answer"]
        pattern = re.compile(f'(<(?:/?)({"|".join(tags)})>)')
        parts = pattern.split(response)
        current_tag = None

        for part in parts:
            if not part:
                continue

            # 检查当前部分是否是一个标签
            match = pattern.match(part)
            if match:
                tag_content = match.group(1)  # a complete tag like '<thinking>' or '</thinking>'
                tag_name = match.group(2)  # just the name like 'thinking'
                is_closing_tag = tag_content.startswith('</')

                if is_closing_tag:
                    # 如果遇到闭合标签，则退出当前状态
                    if current_tag == tag_name:
                        current_tag = None
                else:
                    # 如果遇到开放标签，则进入新状态
                    current_tag = tag_name
            else:
                # 如果当前部分不是标签，并且我们处于某个标签状态内，
                # 就将这部分内容追加到对应的变量中。
                if current_tag == "thinking":
                    thinking += part
                elif current_tag == "tool_code":
                    code += part
                elif current_tag == "final_answer":
                    final_answer += part

        # 返回前去除首尾可能存在的空白字符
        # 对于 code，我们只去除首尾空行，保留内部缩进
        return thinking.strip(), code.strip(), final_answer.strip()

    def run(self, user_query, project_context, rag_context, initial_history):
        """启动并管理整个Agent的执行循环"""
        self.internal_history = []
        self.attempts = 0

        # 构建初始的对话历史
        system_prompt = self._build_system_prompt(user_query, project_context, rag_context)
        self.internal_history.append({"role": "system", "content": system_prompt})

        # 将用户的聊天记录（不含system prompt）作为初始上下文
        self.internal_history.extend(initial_history)

        while self.attempts < MAX_ATTEMPTS:
            self.attempts += 1

            # 调用LLM，注意这里我们不使用流式传输，因为需要完整解析
            response_text = self.llm_service.generate_chat_completion_raw(self.internal_history)

            if not response_text:
                observation = "模型没有返回任何内容，请检查你的输出格式并重试。"
                self.internal_history.append({"role": "user", "content": f"<observation>{observation}</observation>"})
                continue

            # 将模型的回复（包含思考过程）添加到内部历史
            self.internal_history.append({"role": "assistant", "content": response_text})
            thinking, code, final_answer = self._parse_llm_response(response_text)
            if final_answer:
                import re

                # Step 1: 移除所有XML/HTML形式的标签 (例如 <thinking>, </final_answer>)
                clean_final_answer = re.sub(r'</?[^>]+>', '', final_answer)

                # Step 2: 移除您指定的、作为纯文本残留的特定关键词 (不区分大小写)
                keywords_to_remove = [
                    'final_answer', '/final_answer',
                    'thinking', '/thinking',
                    'tool_code', '/tool_code',
                    'observation', '/observation'
                ]
                # 构建正则表达式，匹配这些独立的单词，例如: \b(thinking|final_answer|...)\b
                # \b 是单词边界，确保我们不会错误地删除 "observation" 在 "observational" 单词中的部分
                pattern = r'\b(' + '|'.join(re.escape(k) for k in keywords_to_remove) + r')\b'
                clean_final_answer = re.sub(pattern, '', clean_final_answer, flags=re.IGNORECASE)

                # Step 3: 清理收尾工作。移除可能残留的、位于段首的冒号或多余空格，并整理空白
                # 例如，清理 "final_answer: some text" 变成 ": some text" 后的冒号
                clean_final_answer = re.sub(r'^[\s:：]+', '', clean_final_answer) # 移除开头的空格和中英文冒号
                clean_final_answer = re.sub(r'\s+', ' ', clean_final_answer).strip() # 将多个空白符合并为单个空格

                return clean_final_answer

            if code:
                observation = self._execute_code(code)
                # 将观察结果作为用户消息反馈给模型，让它进行下一步
                self.internal_history.append({"role": "user", "content": f"<observation>{observation}</observation>"})
            else:
                correction_prompt = (
                    "你的思考过程是正确的，但你的回复格式不完整。"
                    "你必须在 `<thinking>` 标签之后，紧跟着提供一个 `<tool_code>` 或 `<final_answer>` 标签。"
                    "<thinking>思考文本（禁止出现<thinking>，<tool_code>，<final_answer>类似标志性标签内容）</thinking> <tool_code>代码内容</tool_code> <final_answer>你的最终回答</final_answer>"
                    "请根据你刚才的思考，重新生成你的完整回复。"
                )
                self.internal_history.append({"role": "user", "content": correction_prompt})
                continue

        return "抱歉，Navi在尝试了多次后仍然无法解决这个问题。请您尝试换一种方式提问，或者提供更详细的信息。"