# config.py

import json
import os
import sys

project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from utils import resource_path


def load_config():
    """
    从 config.json 加载配置。
    这个函数是独立的，可以被主程序和任何子进程调用。
    """
    config_path = resource_path("config.json")
    # --- [新增调试输出] ---
    print(f"[DEBUG in config.py] Process ID: {os.getpid()}")
    print(f"[DEBUG in config.py] Resolved config_path: {os.path.abspath(config_path)}")
    print(f"[DEBUG in config.py] Does it exist? {'Yes' if os.path.exists(config_path) else 'No'}")
    # --- [结束调试输出] ---

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            # --- [新增调试输出] ---
            content = f.read()
            print(f"[DEBUG in config.py] Successfully read config.json content:\n---\n{content[:300]}...\n---")
            # 重置文件指针以供 json.load 读取
            f.seek(0)
            return json.load(f)
            # --- [结束调试输出] ---
    except (FileNotFoundError, json.JSONDecodeError) as e:
        # 如果文件不存在或格式错误，返回一个安全的默认配置
        # --- [新增调试输出] ---
        print(f"[DEBUG in config.py] ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！")
        print(f"[DEBUG in config.py] ERROR: Failed to load or parse config.json.")
        print(f"[DEBUG in config.py] Error details: {e}")
        print(f"[DEBUG in config.py] Falling back to default configuration.")
        print(f"[DEBUG in config.py] ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！")
        # --- [结束调试输出] ---
        return {
            "api_type": "external",
            "external_api": {
                "base_url": "",
                "api_key": "",
                "model": "gemini-1.5-pro-latest"
            },
            "local_api": {
                "base_url": "http://localhost:1234/v1/chat/completions",
                "api_key": "not-needed",
                "model": "local-model"
            },
            "common_external_models": [
                "gemini-1.5-pro-latest"
            ],
            "plotting_font": "NotoSansSC",
            "font_mapping": {
                "黑体 (SimHei)": "simhei.ttf",
                "NotoSansSC": "NotoSansSC.ttf"
            }
        }