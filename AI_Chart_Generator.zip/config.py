# config.py

import json
import os
import sys


def resource_path(relative_path):
    """ 获取资源的绝对路径，兼容PyInstaller打包环境 """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


def load_config():
    """
    从 config.json 加载配置。
    这个函数是独立的，可以被主程序和任何子进程调用。
    """
    try:
        config_path = resource_path("config.json")
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # 如果文件不存在或格式错误，返回一个安全的默认配置
        print("警告: config.json 未找到或格式错误，将使用默认配置。")
        return {
            "api_type": "external",
            "external_api": {
                "base_url": "",
                "api_key": "",
                "model": "gemini-1.5-pro-latest"
            },
            "local_api": {
                "base_url": "http://localhost:1234/v1/chat/completions",
                "api_key": "not-needed",
                "model": "local-model"
            },
            "common_external_models": [
                "gemini-1.5-pro-latest"
            ],
            "plotting_font": "NotoSansSC",
            "font_mapping": {
                "黑体 (SimHei)": "simhei.ttf",
                "NotoSansSC": "NotoSansSC.ttf"
            }
        }
