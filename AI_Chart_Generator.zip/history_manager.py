# history_manager.py

import os
import shutil
import json
from datetime import datetime, timedelta
import re
import base64
import mimetypes
from app_logic import markdown_to_html_with_math
import file_handler
from constants import HISTORY_DIR, HISTORY_CACHE_FILE, OUTPUT_DIR


def _image_to_base64(image_path):
    """将图片文件转换为Base64 Data URI。"""
    if not image_path or not os.path.exists(image_path):
        return None
    try:
        mime_type, _ = mimetypes.guess_type(image_path)
        if not mime_type:
            mime_type = "application/octet-stream"
        with open(image_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
        return f"data:{mime_type};base64,{encoded_string}"
    except Exception as e:
        print(f"图片转Base64失败: {e}")
        return None


class HistoryManager:
    """管理所有与历史记录相关的操作，包括数据处理和文件系统操作。"""

    def __init__(self, api_instance):
        """
        初始化历史记录管理器。
        :param api_instance: MainAppApi 的主应用API实例。
        """
        self.api = api_instance
        self.history_items = {}
        self.all_history_metadata = {}
        self.history_cache_data = {}

    def set_api(self, api):
        """由主API在初始化时调用，注入API实例。"""
        self.api = api

    def start_initial_load(self):
        """启动一个后台线程来加载历史记录元数据。"""
        import threading
        thread = threading.Thread(target=self._perform_initial_load, daemon=True)
        thread.start()

    def _perform_initial_load(self):
        """在后台线程中执行实际的加载操作，并在完成后通知前端。"""
        self._load_all_metadata_from_disk()
        # 加载完成后，通过API安全地通知前端刷新
        if self.api:
            self.api.on_history_loaded()

    def add_or_update_item_in_cache(self, history_id: str):
        """
        读取单个历史项的元数据，并更新到内存缓存中。
        用于新建或重命名后刷新缓存。
        """
        metadata_path = os.path.join(HISTORY_DIR, history_id, "metadata.json")
        if not os.path.exists(metadata_path):
            return

        try:
            mtime = os.path.getmtime(metadata_path)
            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            # 更新两个缓存字典
            self.all_history_metadata[history_id] = metadata
            self.history_cache_data[history_id] = {'meta': metadata, 'mtime': mtime}
            print(f"内存中的历史记录缓存已为 '{history_id}' 更新。")
        except (IOError, json.JSONDecodeError) as e:
            print(f"警告: 无法为 '{history_id}' 更新缓存: {e}")

    def _remove_item_from_cache(self, history_id: str):
        """从内存缓存中安全地移除一个历史项。"""
        self.all_history_metadata.pop(history_id, None)
        self.history_cache_data.pop(history_id, None)
        print(f"内存中的历史记录缓存已将 '{history_id}' 移除。")

    def _load_all_metadata_from_disk(self):
        """
        通过与缓存文件比对，增量加载历史记录元数据。
        """
        print("正在同步历史记录元数据...")
        cache_path = os.path.join(HISTORY_DIR, HISTORY_CACHE_FILE)

        # 1. 加载现有缓存
        cached_data = {}
        if os.path.exists(cache_path):
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    cached_data = json.load(f)
            except (json.JSONDecodeError, IOError):
                print("警告: 历史记录缓存文件损坏，将重新构建。")
                cached_data = {}

        # 2. 获取当前磁盘上的所有历史记录文件夹
        if not os.path.isdir(HISTORY_DIR):
            os.makedirs(HISTORY_DIR)

        disk_folders = {name for name in os.listdir(HISTORY_DIR) if os.path.isdir(os.path.join(HISTORY_DIR, name))}

        # 3. 同步
        final_metadata = {}
        cache_updated = False

        # 遍历磁盘上的文件夹
        for folder_name in disk_folders:
            metadata_path = os.path.join(HISTORY_DIR, folder_name, "metadata.json")
            if not os.path.exists(metadata_path):
                continue

            disk_mtime = os.path.getmtime(metadata_path)

            # 检查是否需要更新
            if folder_name not in cached_data or cached_data[folder_name].get('mtime') != disk_mtime:
                try:
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        metadata = json.load(f)

                    # 检查一个代表性标志，如果不存在，则认为是新格式，需要生成所有标志
                    if 'has_plot' not in metadata:
                        print(f"  [DEBUG] {folder_name}: 正在为旧格式元数据生成状态标志...")
                        outputs = metadata.get('generated_outputs', [])
                        metadata['has_plot'] = any(item.get('type') == 'image' for item in outputs)
                        metadata['has_data_file'] = any(item.get('type') == 'data' for item in outputs)

                        # 其他状态的判断
                        code_content = metadata.get('generated_code', '')
                        metadata['has_code'] = bool(code_content and code_content.strip() != "# 尚未生成任何代码.")

                        console_content = metadata.get('console_output', '')
                        metadata['has_console_output'] = bool(console_content and console_content.strip())

                        # --- 在这里使用与保存时完全相同的逻辑 ---
                        analysis_content = metadata.get('analysis_text', '')
                        placeholder_with_hash = "# 此处将显示对图表的文字分析..."
                        placeholder_without_hash = "此处将显示对图表的文字分析..."
                        # 分解判断逻辑，便于调试
                        is_not_empty = bool(analysis_content and analysis_content.strip())
                        is_not_placeholder1 = analysis_content.strip() != placeholder_with_hash
                        is_not_placeholder2 = analysis_content.strip() != placeholder_without_hash
                        has_analysis_result = is_not_empty and is_not_placeholder1 and is_not_placeholder2
                        metadata['has_analysis'] = has_analysis_result

                    final_metadata[folder_name] = {'meta': metadata, 'mtime': disk_mtime}
                    cache_updated = True
                    print(f"  -> 更新/新增: {folder_name}")
                except (json.JSONDecodeError, IOError) as e:
                    print(f"警告: 无法读取元数据 {metadata_path}: {e}")
            else:
                final_metadata[folder_name] = cached_data[folder_name]

        # 检查是否有被删除的记录
        cached_folders = set(cached_data.keys())
        deleted_folders = cached_folders - disk_folders
        if deleted_folders:
            cache_updated = True
            print(f"  -> 发现已删除记录: {', '.join(deleted_folders)}")

        # 4. 保存更新后的缓存（如果需要）
        if cache_updated:
            try:
                with open(cache_path, 'w', encoding='utf-8') as f:
                    json.dump(final_metadata, f, ensure_ascii=False)
                print("历史记录缓存已更新。")
            except IOError as e:
                print(f"错误: 无法写入历史记录缓存文件: {e}")

        # 5. 更新内存中的元数据
        self.history_cache_data = final_metadata
        self.all_history_metadata = {k: v['meta'] for k, v in self.history_cache_data.items()}
        print(f"元数据同步完成，共 {len(self.all_history_metadata)} 条。")

    def search_items(self, search_term: str):
        """
        根据搜索词在历史记录的显示名称中进行筛选。
        :param search_term: 用户输入的搜索关键词。
        :return: 包含匹配项的元数据字典。
        """
        if not search_term or not search_term.strip():
            return self.all_history_metadata

        lower_term = search_term.lower()

        # 使用字典推导式高效地构建筛选结果
        return {
            history_id: metadata
            for history_id, metadata in self.all_history_metadata.items()
            if lower_term in metadata.get('display_name', '').lower()
        }

    def rename_item(self, history_id, new_name):
        """重命名指定的历史记录项。"""
        if not (new_name and new_name.strip()):
            self.api.show_alert("新名称不能为空。", "warning")
            return False # <-- 新增：返回失败

        try:
            metadata_path = os.path.join(HISTORY_DIR, history_id, "metadata.json")
            if not os.path.exists(metadata_path):
                raise FileNotFoundError(f"元数据文件未找到: {metadata_path}")

            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            metadata['display_name'] = new_name.strip()

            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=4, ensure_ascii=False)

            # 只更新内存缓存，不再刷新UI
            self.add_or_update_item_in_cache(history_id)
            # self.api.refresh_ui_lists() # <--- 【核心修改】注释或删除此行
            return True # <-- 新增：返回成功
        except Exception as e:
            self.api.show_alert(f"重命名失败: {e}", "error")
            print(f"重命名失败: {e}")
            return False # <-- 新增：返回失败

    def delete_item(self, history_id):
        """删除指定的历史记录项。"""
        try:
            shutil.rmtree(os.path.join(HISTORY_DIR, history_id))
            self._remove_item_from_cache(history_id)
            self.api.refresh_ui_lists()
        except Exception as e:
            self.api.show_alert(f"删除历史记录 '{history_id}' 失败: {e}", "error")
            print(f"删除历史记录 '{history_id}' 失败: {e}")

    def load_history_into_workspace(self, history_id, active_workspace_id):
        """将指定的历史记录加载到指定的工作区。"""
        active_ws = self.api.workspace_manager.workspaces.get(active_workspace_id)
        if not active_ws:
            self.api.show_alert(f"加载历史失败: 工作区 '{active_workspace_id}' 不存在。", "error")
            return

        self.api.update_status(f"正在从 '{history_id}' 加载历史记录到 '{active_ws.name}'...", workspace_id=active_workspace_id)
        history_path = os.path.join(HISTORY_DIR, history_id)

        try:
            with open(os.path.join(history_path, "metadata.json"), 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            # 清空工作区现有内容
            active_ws.clear_content()

            # 恢复文本和代码
            active_ws.data_input_text = metadata.get("data_input_text", "")
            active_ws.prompt_input_text = metadata.get("prompt_input_text", "")

            original_code = metadata.get("generated_code", "# 未找到历史代码.")
            new_workspace_id = active_ws.id
            uuid_pattern = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
            modified_code = re.sub(
                f'(plot|data|code)_({uuid_pattern})',
                lambda m: f"{m.group(1)}_{new_workspace_id}",
                original_code,
                flags=re.IGNORECASE
            )

            if modified_code != original_code:
                print(f"代码中的工作区ID路径已自动更新为: {new_workspace_id}")

            active_ws.last_generated_code = modified_code
            active_ws.console_output = metadata.get("console_output", "# 未找到历史代码输出.")
            # --- 同时加载并区分原始MD和渲染后HTML  ---
            # 1. 优先从 'analysis_text_raw_md' 键获取原始Markdown，这是最可靠的数据源
            raw_md = metadata.get("analysis_text_raw_md")
            # 2. 如果找不到（兼容旧版历史记录），则从 'analysis_text' 降级获取
            if raw_md is None:
                raw_md = metadata.get("analysis_text", "# 未找到历史文字分析.")
            # 3. 确保工作区的两个相关属性都被正确填充
            #    - `analysis_text_raw_md` 保存原始文本，用于逻辑判断和复制
            #    - `analysis_text` 保存渲染后的HTML，用于UI直接显示
            active_ws.analysis_text_raw_md = raw_md
            active_ws.analysis_text = markdown_to_html_with_math(raw_md)

            # 恢复输入文件
            history_inputs_path = os.path.join(history_path, "inputs")
            for file_meta in metadata.get("input_files", []):
                src_path = os.path.join(history_inputs_path, file_meta['managed_name'])
                if os.path.exists(src_path):
                    file_handler.add_file_input(self.api, src_path, file_meta['target'], active_workspace_id)

            # --- 【核心修改】重构并加固输出文件的加载逻辑，以兼容新旧两种格式 ---
            outputs_metadata = metadata.get("generated_outputs")
            new_outputs_list = []

            if outputs_metadata is None:
                # --- **旧版历史记录兼容逻辑** ---
                print("检测到旧版历史记录格式，正在进行兼容性加载...")
                # 1. 尝试加载固定的图表文件
                legacy_plot_path = os.path.join(history_path, "output_plot.png")
                if os.path.exists(legacy_plot_path):
                    print(f"找到旧版图表文件: output_plot.png")
                    new_plot_filename = f"image_{active_ws.id}_0.png"
                    plot_dest_path = os.path.join(OUTPUT_DIR, new_plot_filename)
                    shutil.copy2(legacy_plot_path, plot_dest_path)
                    new_outputs_list.append({
                        "type": "image",
                        "filename": "output_plot.png",
                        "final_path": plot_dest_path
                    })

                # 2. 尝试扫描并加载其他非标准文件（通常是数据文件）
                ignored_files = {"metadata.json", "inputs", "outputs", "output_plot.png", "code.py"}
                for filename in os.listdir(history_path):
                    if filename in ignored_files or os.path.isdir(os.path.join(history_path, filename)):
                        continue

                    print(f"找到旧版数据文件: {filename}")
                    legacy_file_path = os.path.join(history_path, filename)
                    _, file_ext = os.path.splitext(filename)
                    # 索引从已有的文件数开始
                    new_filename = f"data_{active_ws.id}_{len(new_outputs_list)}{file_ext}"
                    dest_path = os.path.join(OUTPUT_DIR, new_filename)
                    shutil.copy2(legacy_file_path, dest_path)

                    new_outputs_list.append({
                        "type": "data",  # 假设是数据文件
                        "filename": filename,
                        "final_path": dest_path
                    })

            else:
                # --- **新版历史记录加载逻辑** ---
                for index, item_meta in enumerate(outputs_metadata):
                    # 安全性检查，防止元数据损坏
                    if not isinstance(item_meta, dict) or 'filename' not in item_meta:
                        print(f"警告: 在历史记录 {history_id} 中发现格式不正确的输出项，已跳过: {item_meta}")
                        continue

                    original_filename = item_meta['filename']

                    # 优先使用 `history_relative_path`，它更精确。如果没有，则 fallback 到旧的拼接方式
                    relative_path = item_meta.get('history_relative_path', os.path.join('outputs', original_filename))
                    src_path = os.path.join(history_path, relative_path.replace('/', os.sep))

                    if os.path.exists(src_path):
                        _, ext = os.path.splitext(original_filename)
                        # 构造新的、唯一的输出文件名
                        file_type = item_meta.get('type', 'file')
                        new_filename_base = f"{file_type}_{active_ws.id}_{index}{ext}"
                        dest_path = os.path.join(OUTPUT_DIR, new_filename_base)

                        try:
                            shutil.copy2(src_path, dest_path)
                            # 创建新的元数据项，并更新为 output/ 目录下的新路径
                            new_output_item = item_meta.copy()
                            new_output_item['final_path'] = dest_path
                            new_outputs_list.append(new_output_item)
                        except Exception as e:
                            print(f"从历史记录复制文件失败: {src_path} -> {dest_path}. 错误: {e}")
                    else:
                        print(f"警告：在历史记录 {history_id} 中找不到文件 '{original_filename}' (检查路径: {src_path})")

            # 将重建的、路径已更新的输出列表赋值给活动工作区
            active_ws.generated_outputs = new_outputs_list
            # --- 【核心修改结束】---

            # 刷新UI以显示加载的内容
            self.api.refresh_ui_lists()
            self.api.update_status(f"成功加载历史记录 '{history_id}'。", workspace_id=active_workspace_id)
        except Exception as e:
            error_msg = f"加载历史记录失败: {e}"
            self.api.show_alert(error_msg, "error")
            self.api.update_status(error_msg, is_error=True, workspace_id=active_workspace_id)

    def show_input_preview(self, history_id):
        """为指定历史记录的输入内容准备数据并请求预览。"""
        try:
            history_path = os.path.join(HISTORY_DIR, history_id)
            with open(os.path.join(history_path, "metadata.json"), 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            preview_data = {
                "数据输入框内容": metadata.get("data_input_text", "无"),
                "要求输入框内容": metadata.get("prompt_input_text", "无"),
            }

            inputs_folder = os.path.join(history_path, "inputs")
            image_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.gif')

            for i, file_info in enumerate(metadata.get("input_files", [])):
                original_name = file_info['original_name']
                full_path = os.path.join(inputs_folder, file_info['managed_name'])

                if not os.path.exists(full_path):
                    continue

                if original_name.lower().endswith(image_extensions):
                    base64_image = _image_to_base64(full_path)
                    if base64_image:
                        preview_data[f"输入图像 ({original_name})_image_base64"] = base64_image
                else:
                    file_type = "数据文件" if file_info['target'] == 'data' else "参考文件"
                    preview_data[f"{file_type} {i+1} ({original_name})_file_path"] = full_path

            window_title = f"{metadata.get('display_name', history_id)} - 输入预览"
            self.api.show_preview_window(preview_data, window_title)

        except Exception as e:
            self.api.show_alert(f"加载输入预览时出错: {e}", "error")

    def show_output_preview(self, history_id):
        """为指定历史记录的输出内容准备数据并请求预览。"""
        try:
            history_path = os.path.join(HISTORY_DIR, history_id)
            metadata_path = os.path.join(history_path, "metadata.json")

            if not os.path.exists(metadata_path):
                self.api.show_alert(f"无法找到历史记录 '{history_id}' 的元数据。", "error")
                return

            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)

            # 准备基础的文本预览数据
            preview_data = {
                "生成的代码": metadata.get("generated_code", "无"),
                "代码输出": metadata.get("console_output", "无"),
                "文字分析": metadata.get("analysis_text", "无"),
            }

            # --- 动态地从元数据构建文件预览，并完全兼容新旧结构 ---
            outputs_metadata = metadata.get("generated_outputs")

            if outputs_metadata is None:
                # --- **旧版历史记录预览逻辑** ---
                print("为旧版历史记录生成预览...")
                legacy_plot_path = os.path.join(history_path, "output_plot.png")
                if os.path.exists(legacy_plot_path):
                    base64_image = _image_to_base64(legacy_plot_path)
                    if base64_image:
                        preview_data[f"输出图像 (output_plot.png)_image_base64"] = base64_image
                # 旧版可能存在的数据文件，由于没有元数据记录，预览时通常只关注标准图像输出
            else:
                # --- **新版历史记录预览逻辑** ---
                history_outputs_base_path = os.path.join(history_path, "outputs")
                if not os.path.isdir(history_outputs_base_path):
                    history_outputs_base_path = history_path  # 兼容没有outputs子目录的存档

                for item in outputs_metadata:
                    if not isinstance(item, dict) or 'type' not in item or 'filename' not in item:
                        print(f"警告: 在预览 {history_id} 时跳过格式不正确的输出项: {item}")
                        continue

                    item_type = item['type']
                    filename = item['filename']

                    # 优先使用相对路径构建，以获得最准确的文件位置
                    relative_path = item.get('history_relative_path', os.path.join('outputs', filename))
                    file_path_in_history = os.path.join(history_path, relative_path.replace('/', os.sep))

                    if not os.path.exists(file_path_in_history):
                        preview_data[f"输出文件 ({filename})"] = f"文件丢失 (路径: {file_path_in_history})"
                        continue

                    if item_type == 'image':
                        base64_image = _image_to_base64(file_path_in_history)
                        if base64_image:
                            preview_data[f"输出图像 ({filename})_image_base64"] = base64_image
                        else:
                            preview_data[f"输出图像 ({filename})"] = "图片文件转换失败"
                    elif item_type in ['data', 'text']:
                        # 为数据和文本文件提供可点击打开的链接
                        key_prefix = "输出数据" if item_type == 'data' else "输出文本"
                        preview_data[f"{key_prefix} ({filename})_file_path"] = file_path_in_history
                    # 可以为其他类型添加更多逻辑...
            window_title = f"{metadata.get('display_name', history_id)} - 输出预览"
            self.api.show_preview_window(preview_data, window_title)

        except Exception as e:
            self.api.show_alert(f"加载输出预览时出错: {e}", "error")
            print(f"加载输出预览时出错 ({history_id}): {e}")

    def run_auto_cleanup(self):
        """根据设置检查并删除旧的历史记录。"""
        settings = self.api.config_manager.settings
        if not settings.get("auto_cleanup_enabled") or not os.path.isdir(HISTORY_DIR):
            return

        print("正在执行自动清理...")
        period_map = {"一天内": 1, "三天内": 3, "一周内": 7, "一个月内": 30}
        period_str = settings.get("cleanup_period")

        days_to_keep = 0
        try:
            if period_str == "自定义":
                days_to_keep = int(settings.get("cleanup_custom_days", 0))
            else:
                days_to_keep = period_map.get(period_str, 0)
        except (ValueError, TypeError):
            print(f"自动清理错误: 自定义天数无效。")
            return

        if days_to_keep <= 0: return

        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        deleted_count = 0

        # 创建一个列表副本进行迭代，以避免在迭代时修改目录
        for folder_name in list(os.listdir(HISTORY_DIR)):
            try:
                # 从文件夹名称 "YYYYMMDD_HHMMSS_..." 中解析时间
                folder_time_str = folder_name.split('_')[0] + folder_name.split('_')[1]
                folder_time = datetime.strptime(folder_time_str, "%Y%m%d%H%M%S")
                if folder_time < cutoff_date:
                    shutil.rmtree(os.path.join(HISTORY_DIR, folder_name))
                    self._remove_item_from_cache(folder_name) # 同时从缓存中移除
                    deleted_count += 1
            except (ValueError, IndexError):
                # 忽略不符合命名规范的文件夹
                continue
            except Exception as e:
                print(f"自动清理删除 '{folder_name}' 失败: {e}")

        if deleted_count > 0:
            self.api.update_status(f"自动清理完成，删除了 {deleted_count} 条旧记录。")
            self.api.refresh_ui_lists()

    def save_cache_on_exit(self):
        """
        在程序退出时，将内存中的历史记录缓存数据写回磁盘文件。
        """
        if not hasattr(self, 'history_cache_data') or not self.history_cache_data:
            print("没有历史记录缓存数据可保存。")
            return

        cache_path = os.path.join(HISTORY_DIR, HISTORY_CACHE_FILE)
        print(f"正在将历史记录缓存保存到 {cache_path}...")
        try:
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(self.history_cache_data, f, ensure_ascii=False, indent=2)
            print("缓存保存成功。")
        except IOError as e:
            print(f"错误: 无法写入历史记录缓存文件: {e}")