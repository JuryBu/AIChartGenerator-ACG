# app_logic.py

import os
import re
import subprocess
import sys
from llm_service import LLMService
from constants import *
from constants import HISTORY_DIR, URL_TEST_TIMEOUT, URL_STATUS_COLORS
import shutil
import json
import uuid
from datetime import datetime
import requests
from utils import resource_path
from typing import Optional, TYPE_CHECKING
import markdown
import hashlib
import tempfile
from pathlib import Path

if TYPE_CHECKING:
    from main_app_api import MainAppApi

MD_EXTENSIONS = [
    'pymdownx.highlight',
    'pymdownx.superfences',
    'markdown.extensions.tables',
    'markdown.extensions.fenced_code',
]
MD_EXTENSION_CONFIGS = {
    'pymdownx.highlight': {'use_pygments': False},
    'markdown.extensions.fenced_code': {'lang_prefix': 'language-'},
}
md_converter = markdown.Markdown(extensions=MD_EXTENSIONS, extension_configs=MD_EXTENSION_CONFIGS)


def hide_math_from_markdown(text):
    math_map = {}
    def replacer(match):
        block = match.group(0)
        key = hashlib.md5(block.encode()).hexdigest()
        placeholder = f"MATH_PLACEHOLDER_{key}"
        math_map[key] = block
        return placeholder
    math_pattern = re.compile(r"(\$\$[\s\S]*?\$\$|\$[^\$]*?\$|\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\))", re.DOTALL)
    processed_text = math_pattern.sub(replacer, text)
    return processed_text, math_map


def restore_math_in_html(html, math_map):
    for key, block in math_map.items():
        placeholder_text = f"MATH_PLACEHOLDER_{key}"
        replacement_html = f'<span class="math-placeholder">{block}</span>'
        html = html.replace(placeholder_text, replacement_html)
    return html


def preprocess_latex_code_blocks(text):
    pattern = re.compile(r"```latex\s*([\s\S]*?)\s*```", re.DOTALL)
    replacement = r"$$\1$$"
    return pattern.sub(replacement, text)


def markdown_to_html_with_math(text_content):
    normalized_text = preprocess_latex_code_blocks(text_content)
    md_text, math_map = hide_math_from_markdown(normalized_text)
    html = md_converter.convert(md_text)
    restored_html = restore_math_in_html(html, math_map)
    md_converter.reset()
    return restored_html


def execute_code(api: "MainAppApi", code_to_run, workspace_id):
    """
    在一个安全的临时沙箱目录中执行给定的Python代码，
    并收割所有生成的文件作为输出。

    返回: (status, outputs, stdout, stderr, modified_code)
        status (str): 'success' 或 'failure'
        outputs (List[Dict]): 成功时生成的文件元数据列表，失败时为空列表
        stdout (str): 标准输出
        stderr (str): 错误输出
        modified_code (str): 注入了真实路径的最终代码
    """
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        return ('failure', [], "", f"执行失败：找不到ID为 {workspace_id} 的工作区。", code_to_run)

    # 1. 创建一个临时的沙箱目录
    with tempfile.TemporaryDirectory() as sandbox_dir:
        sandbox_path = Path(sandbox_dir)

        # 将代码中的占位符替换为真实的沙箱路径
        # 确保路径格式对所有操作系统都友好
        safe_sandbox_path = str(sandbox_path).replace('\\', '/')
        code_to_run = code_to_run.replace('__SANDBOX_PATH__', safe_sandbox_path)

        # 2. 注入字体路径（逻辑保持不变）
        try:
            selected_font_display_name = workspace.font_config.get("name", "NotoSansSC")
            font_mapping = api.config_manager.config.get("font_mapping", {})
            font_filename = font_mapping.get(selected_font_display_name, "NotoSansSC.ttf")
            font_asset_path = f"字体/{font_filename}"
            real_font_path = resource_path(font_asset_path)
            safe_font_path = real_font_path.replace('\\', '/')

            # 使用更健壮的占位符替换，而不是硬编码的 `font_path = ...`
            code_to_run = code_to_run.replace('__FONT_PATH_PLACEHOLDER__', safe_font_path)
            # 注入 input 目录的绝对路径
            # 这可以确保无论脚本在哪里执行，都能正确找到输入文件
            safe_input_path = str(Path(INPUT_DIR).resolve()).replace('\\', '/')
            # 使用正则表达式以同时匹配单引号和双引号的情况
            code_to_run = re.sub(r"(?i)(['\"])input/", fr"\1{safe_input_path}/", code_to_run)

        except Exception as e:
            api.show_alert(f"警告：注入字体路径时出错: {e}", "warning")
        # 3. 将最终代码写入沙箱内的脚本文件
        utf8_enforcer = "import sys\nif sys.stdout.encoding != 'utf-8':\n    sys.stdout.reconfigure(encoding='utf-8')\n"
        final_code_to_run = utf8_enforcer + code_to_run
        script_path = sandbox_path / "script.py"

        with open(script_path, "w", encoding='utf-8') as f:
            f.write(final_code_to_run)

        startupinfo = None
        if sys.platform == "win32":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE

        # 4. 执行沙箱内的脚本
        try:
            result = subprocess.run(
                ["python", str(script_path)],
                check=True, timeout=120, capture_output=True,
                text=True, encoding='utf-8', errors='ignore',
                startupinfo=startupinfo
            )

            # 5. 成果收割与迁移
            generated_outputs = []
            output_files = [f for f in os.listdir(sandbox_path) if f != "script.py"]

            for index, filename in enumerate(output_files):
                source_path = sandbox_path / filename
                ext = source_path.suffix.lower()

                # 分类
                file_type = 'other'
                if ext in ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp']:
                    file_type = 'image'
                elif ext in ['.xlsx', '.xls', '.csv']:
                    file_type = 'data'
                elif ext in ['.txt', '.md', '.json', '.html', '.xml']:
                    file_type = 'text'

                # 标准化命名与迁移
                new_filename = f"{workspace_id}_{index}{ext}"
                final_target_path = Path(OUTPUT_DIR) / new_filename

                shutil.move(str(source_path), str(final_target_path))

                # 构建元数据
                output_metadata = {
                    'type': file_type,
                    'filename': filename, # 原始文件名
                    'final_path': str(final_target_path) # 在 output/ 中的最终绝对路径
                }
                generated_outputs.append(output_metadata)

            return ('success', generated_outputs, result.stdout.strip(), result.stderr.strip(), code_to_run)

        except subprocess.CalledProcessError as e:
            return ('failure', [], e.stdout.strip(), f"[错误日志]:\n{e.stderr.strip()}", code_to_run)
        except subprocess.TimeoutExpired:
            return ('failure', [], "", "代码执行超时(120秒)，可能存在死循环或效率问题。", code_to_run)
        except Exception as e:
            return ('failure', [], "", f"执行代码时发生未知错误: {e}", code_to_run)


def run_code_from_textbox(api: "MainAppApi", workspace_id: str):
    """从UI的代码框中获取代码并为当前工作区执行。"""
    api.set_ui_lock_state(True, workspace_id)
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        api.update_status("没有活动的工作区可执行代码。", True)
        api.set_ui_lock_state(False, workspace_id)
        return

    code_to_run = workspace.last_generated_code.strip()
    if not code_to_run or code_to_run == "# 尚未生成任何代码.":
        api.update_status("代码框中没有可执行的代码。", True)
        api.set_ui_lock_state(False, workspace_id)
        return

    workspace.status_log.clear()
    api.update_progress(workspace_id, 0, "任务启动...", visible=True)
    api.update_progress(workspace_id, 15, "准备执行...", visible=True)

    status, outputs, stdout, stderr, modified_code = execute_code(api, code_to_run, workspace.id)

    api.update_progress(workspace_id, 40, "完成执行...", visible=True)

    workspace.last_generated_code = modified_code
    api.update_progress(workspace_id, 50, "完成内存同步...", visible=True)
    workspace.console_output = stdout if stdout else ""
    api.update_console_output(workspace.id, stdout if stdout else "")

    if status == 'success' and outputs:
        api.update_progress(workspace_id, 60, "执行成功...", visible=True)

        # 将新生成的文件列表赋值给工作区
        workspace.generated_outputs = outputs

        final_message_parts = []

        # 查找第一个图片用于预览
        first_image = next((item for item in outputs if item.get('type') == 'image'), None)

        if first_image:
            api.update_progress(workspace_id, 70, "更新图表预览...", visible=True)
            api.update_plot(workspace.id, first_image['final_path'])
            final_message_parts.append(f"图表已生成。")
        else:
            api.update_plot(workspace.id, None) # 如果没有图片，清除预览

        num_data_files = sum(1 for item in outputs if item.get('type') == 'data')
        if num_data_files > 0:
            final_message_parts.append(f"{num_data_files}个数据文件已生成。")

        if stdout:
             final_message_parts.append("代码输出已在控制台更新。")

        final_message = " ".join(final_message_parts) if final_message_parts else f"任务完成，生成了 {len(outputs)} 个文件。"
        api.update_status(final_message)
        api.show_alert(final_message, 'info')

    elif status == 'success' and not outputs:
        api.update_progress(workspace_id, 60, "执行告警...", visible=True)
        final_message = "代码执行成功，但未生成任何输出文件。"
        api.update_status(final_message, is_error=True)
        api.show_alert(final_message, 'warning')

    else: # status == 'failure'
        api.update_progress(workspace_id, 60, "执行失败...", visible=True)
        error_message = f"执行代码时出错:\n{stderr}"
        api.update_status(error_message, is_error=True)
        error_output = f"--- 执行失败 ---\n[标准输出]:\n{stdout}\n\n[错误日志]:\n{stderr}"
        api.update_console_output(workspace.id, error_output)
        api.show_alert("代码执行失败，请查看控制台输出。", 'error')

    _save_generation_to_history(api, workspace)
    api.update_progress(workspace_id, 100, "任务完成!", visible=True)
    api.set_ui_lock_state(False, workspace_id)
    import time
    time.sleep(2)
    api.update_progress(workspace_id, 0, "空闲", visible=False)


def _execute_and_correct_code(api: "MainAppApi", llm: LLMService, workspace, initial_prompt: str,
                              code_to_start_with: Optional[str] = None):
    """
    一个可复用的代码执行与纠错循环。
    如果提供了 code_to_start_with，则首先尝试执行它。
    如果失败或未提供初始代码，则进入基于 initial_prompt 的生成/纠错循环。

    :return: (is_success: bool, final_code: str, last_error: str, outputs: List[Dict])
    """
    max_retries = workspace.model_config.get('max_retries', 3)
    generated_code = code_to_start_with if code_to_start_with else ""
    last_error = ""

    if code_to_start_with:
        api.end_code_stream(workspace.id, code_to_start_with)

    # 尝试执行初始代码（如果有）
    if generated_code:
        status, outputs, stdout, stderr, modified_code = execute_code(api, generated_code, workspace.id)
        workspace.console_output = stdout if stdout else ""

        if status == 'success' and outputs:
            return True, modified_code, "", outputs
        elif status == 'success' and not outputs:
            last_error = "代码执行成功，但未生成任何输出文件。"
        else:
            last_error = stderr

    # 进入生成/修复循环
    for attempt in range(max_retries):
        prompt_for_llm = initial_prompt

        if last_error:
            api.update_status(f"第 {attempt + 1}/{max_retries} 次修复尝试...", is_error=True, workspace_id=workspace.id)
            prompt_for_llm = (
                f"---\n你之前生成的代码在执行时失败了或未产出文件。请根据【用户原始需求】和【错误信息】，并结合所有上下文文件，生成一段全新的、完整的、修正后的Python代码。\n"
                f"【用户原始需求】: {workspace.prompt_input_text.strip()}\n"
                f"【上次失败的代码】:\n```python\n{generated_code}\n```\n"
                f"【错误或问题】:\n{last_error}\n"
                f"请只根据以上信息，重新生成完整代码。"
            )
        else:
             api.update_status(f"第 {attempt + 1} 次请求AI模型...", workspace_id=workspace.id)

        data_files_for_llm = []
        for file_info in workspace.managed_files['data']:
            llm_file_info = file_info.copy()
            llm_file_info['path_for_llm'] = file_info['preview_id']
            llm_file_info['is_preview'] = file_info.get('is_preview', False)
            data_files_for_llm.append(llm_file_info)

        api.start_code_stream(workspace.id)
        generated_code_chunks = []
        # 注意: llm.generate_code 现在返回一个生成器
        code_stream = llm.generate_code(
            user_prompt=prompt_for_llm,
            data_files=data_files_for_llm,
            prompt_files=workspace.managed_files['prompt'],
            workspace_id=workspace.id
        )

        # 假设 llm.generate_code 返回的是一个生成器
        # 如果不是，则需要调整
        if isinstance(code_stream, str): # 兼容非流式返回
            new_generated_code = code_stream
            api.stream_code_chunk(workspace.id, new_generated_code)
        else: # 流式处理
            for chunk in code_stream:
                api.stream_code_chunk(workspace.id, chunk)
                generated_code_chunks.append(chunk)
            new_generated_code = "".join(generated_code_chunks)

        api.end_code_stream(workspace.id, new_generated_code)
        generated_code = new_generated_code

        if not generated_code or generated_code.strip().startswith("# 错误"):
            last_error = f"代码生成失败:\n{generated_code}"
            continue
        if not re.search(r'(import|class|def|plt|pd|print|io|os|from)', generated_code, re.IGNORECASE):
            last_error = f"模型未返回有效的Python代码。返回内容为非代码文本:\n'{generated_code[:200]}...'"
            continue

        api.update_status(f"第 {attempt + 1} 次执行代码...", workspace_id=workspace.id)
        status, outputs, stdout, stderr, modified_code = execute_code(api, generated_code, workspace.id)
        api.update_status(f"第 {attempt + 1} 次执行代码已经执行完毕。", workspace_id=workspace.id)

        workspace.last_generated_code = modified_code
        workspace.console_output = stdout if stdout else ""

        if status == 'success' and outputs:
            return True, modified_code, "", outputs
        elif status == 'success' and not outputs:
            last_error = "代码执行成功，但未生成任何输出文件。"
        else:
            last_error = stderr

    return False, generated_code, last_error, []


def generate_chart(api: "MainAppApi", workspace_id: str):
    """核心逻辑：生成图表的主函数，现在与活动工作区绑定。"""
    api.set_ui_lock_state(True, workspace_id)
    workspace = api.workspace_manager.workspaces.get(workspace_id)
    if not workspace:
        api.show_alert("没有活动的工作区来执行任务！", 'error')
        api.set_ui_lock_state(False, workspace_id)
        return

    original_prompt = workspace.prompt_input_text.strip()
    if not original_prompt and not workspace.managed_files['data'] and not workspace.managed_files['prompt']:
        api.show_alert("请输入您的要求或添加文件！", 'error')
        api.set_ui_lock_state(False, workspace_id)
        return

    workspace.is_running = True
    llm = LLMService(workspace.model_config, log_callback=lambda msg: api.update_status(msg, workspace_id=workspace.id))
    workspace.status_log.clear()
    api.update_progress(workspace_id, 0, "任务启动...", visible=True)

    # --- 阶段一：初始代码生成与纠错 ---
    api.update_status("开始初始代码生成...", workspace_id=workspace.id)
    api.update_progress(workspace_id, 5, "请求AI模型...", visible=True)
    is_success, generated_code, last_error, outputs = _execute_and_correct_code(
        api, llm, workspace, original_prompt
    )
    api.update_progress(workspace_id, 20, "完成初始代码生成与执行...", visible=True)

    if not is_success:
        # ... (错误处理逻辑基本不变)
        final_error_msg = f"已达最大重试次数，仍未成功。\n最后错误:\n{last_error}"
        api.update_status(final_error_msg, is_error=True, workspace_id=workspace.id)
        api.update_code_output(workspace.id, generated_code)
        api.update_console_output(workspace.id, f"[标准输出]:\n{workspace.console_output}\n[错误日志]:\n{last_error}")
        workspace.is_running = False
        api.set_ui_lock_state(False, workspace_id)
        api.update_progress(workspace_id, 100, "任务失败!", visible=True)
        import time
        time.sleep(2)
        api.update_progress(workspace_id, 0, "空闲", visible=False)
        return

    api.update_status("初步代码执行成功！", workspace_id=workspace.id)
    api.update_progress(workspace_id, 40, "初步代码执行成功...", visible=True)

    # --- 阶段二：Agent 优化循环 (如果启用) ---
    if workspace.agent_mode_enabled:
        api.update_progress(workspace_id, 50, "启动Agent评估...", visible=True)

        # 备份初次成功的结果，以便在优化失败时回退
        initial_successful_code = generated_code
        initial_successful_outputs = outputs

        max_agent_retries = workspace.model_config.get('max_agent_retries', 3)
        for agent_attempt in range(max_agent_retries):
            api.update_status(f"Agent: 第 {agent_attempt + 1}/{max_agent_retries} 轮评估...", workspace_id=workspace.id)
            api.update_progress(workspace_id, 60 + agent_attempt * 10, f"Agent评估 {agent_attempt + 1}...",
                                visible=True)

            with tempfile.TemporaryDirectory() as agent_eval_dir:
                if not outputs:  # 注意：这里用的是循环中可能被更新的 outputs
                    # 如果没有输出，也无法评估，直接跳出
                    api.update_status("Agent评估：无文件可评估，跳过优化。", workspace_id=workspace.id)
                    break

                for item in outputs:
                    shutil.copy2(item['final_path'], os.path.join(agent_eval_dir, item['filename']))

                eval_status, new_code = llm.evaluate_and_refine(original_prompt, generated_code, agent_eval_dir)

            api.update_status(f"Agent: 第 {agent_attempt + 1} 轮评估完成。", workspace_id=workspace.id)

            if eval_status == 'complete':
                api.update_status("Agent确认结果符合要求。", workspace_id=workspace.id)
                break
            elif eval_status == 'error':
                api.update_status("Agent评估出错，将使用当前结果。", is_error=True, workspace_id=workspace.id)
                break
            elif eval_status == 'refine':
                api.update_status("Agent发现优化点，开始执行并验证新代码...", workspace_id=workspace.id)

                is_refine_success, refined_code, refine_error, refined_outputs = _execute_and_correct_code(
                    api, llm, workspace, original_prompt, code_to_start_with=new_code
                )

                if is_refine_success:
                    api.update_status("Agent优化代码执行成功。", workspace_id=workspace.id)
                    generated_code = refined_code
                    outputs = refined_outputs
                else:
                    api.update_status("Agent优化代码执行失败，终止优化，使用优化前结果。", is_error=True,
                                      workspace_id=workspace.id)
                    # [修改] 如果优化失败，恢复到优化前的最佳结果
                    generated_code = initial_successful_code
                    outputs = initial_successful_outputs
                    break
        else:
            api.update_status("Agent优化流程已达上限。")

    else:
        api.update_status("Agent模式未启用，跳过优化。", workspace_id=workspace.id)

    # --- 阶段三：最终结果处理与展示 ---
    api.update_progress(workspace_id, 95, "处理最终结果...", visible=True)

    workspace.generated_outputs = outputs
    workspace.last_generated_code = generated_code

    final_message_parts = []
    num_images = sum(1 for item in outputs if item.get('type') == 'image')
    num_data = sum(1 for item in outputs if item.get('type') == 'data')

    if num_images > 0:
        final_message_parts.append(f"生成了 {num_images} 个图表。")
    if num_data > 0:
        final_message_parts.append(f"生成了 {num_data} 个数据文件。")

    if not final_message_parts:
        if outputs:
             final_message_parts.append(f"任务完成，生成了 {len(outputs)} 个文件。")
        else:
            api.update_status("任务完成，但未找到最终输出文件。", is_error=True, workspace_id=workspace.id)

    # 更新UI
    api.update_code_output(workspace.id, workspace.last_generated_code)
    api.update_console_output(workspace.id, workspace.console_output)

    first_image = next((item for item in outputs if item.get('type') == 'image'), None)
    api.update_plot(workspace.id, first_image['final_path'] if first_image else None)

    final_message = " ".join(final_message_parts) if final_message_parts else "任务完成。"
    api.update_status(final_message, workspace_id=workspace.id)
    _save_generation_to_history(api, workspace)

    workspace.is_running = False
    workspace.has_new_result = True
    api.show_alert(final_message, 'info')
    api.set_ui_lock_state(False, workspace_id)
    api.update_progress(workspace_id, 100, "任务完成!", visible=True)
    import time
    time.sleep(2)
    api.update_progress(workspace_id, 0, "空闲", visible=False)


def generate_text_analysis(api: "MainAppApi", workspace_id: str):
    """为当前活动工作区的结果生成文本分析。"""
    api.set_ui_lock_state(True, workspace_id)
    try:
        workspace = api.workspace_manager.workspaces.get(workspace_id)
        if not workspace:
            api.show_alert("没有活动的工作区。", 'warning')
            return

        # --- 【核心修复】检查 generated_outputs 列表是否为空 ---
        if not workspace.generated_outputs:
            api.show_alert("当前工作区没有可供分析的输出结果。", 'warning')
            return

        workspace.status_log.clear()
        api.update_progress(workspace_id, 0, "任务启动...", visible=True)

        llm = LLMService(workspace.model_config,
                         log_callback=lambda msg: api.update_status(msg, workspace_id=workspace.id))

        # 传递原始输入文件作为上下文
        input_data_files_context = workspace.managed_files['data']

        api.update_progress(workspace_id, 20, "配置已准备...", visible=True)

        api.start_analysis_stream(workspace.id)
        api.update_progress(workspace_id, 30, "流式输出就绪...", visible=True)

        full_analysis_text = ""

        # --- 【核心修复】调用新的 analyze_outputs 方法 ---
        analysis_stream = llm.analyze_outputs(workspace.generated_outputs, input_data_files_context)

        api.update_progress(workspace_id, 50, "获取初步结果...", visible=True)

        for chunk in analysis_stream:
            # 【核心修改】流式传输时，我们也需要进行转换，这样前端可以实时看到渲染效果
            # 注意：这里我们对每个块都进行转换，而不是等全部结束后。
            # 这意味着KaTeX公式在完整出现之前可能不会被渲染，这是可接受的。
            html_chunk = markdown_to_html_with_math(chunk)
            api.stream_analysis_chunk(workspace.id, html_chunk)  # 2. 发送转换后的HTML块
            full_analysis_text += chunk # 仍然累加原始文本

        api.update_progress(workspace_id, 60, "获取最终渲染结果...", visible=True)

        # 【核心修改】在流结束后，对完整文本进行最终转换，以确保数据一致性并发送给前端
        final_html_content = markdown_to_html_with_math(full_analysis_text)
        api.end_analysis_stream(workspace.id, final_html_content)
        # --- 【修改结束】 ---

        api.update_progress(workspace_id, 70, "开始后续文本处理...", visible=True)

        # 使用拼接好的完整文本进行后续处理
        if full_analysis_text.strip().startswith("# 错误"):
            api.update_progress(workspace_id, 90, "分析失败...", visible=True)
            api.update_status(f"分析失败: {full_analysis_text}", is_error=True, workspace_id=workspace.id)
            api.update_progress(workspace_id, 100, "任务完成!", visible=True)
        else:
            api.update_progress(workspace_id, 75, "HTML存入工作区...", visible=True)
            # 【核心修改】将转换后的HTML存入工作区，以便保存和加载
            workspace.analysis_text = final_html_content
            api.update_progress(workspace_id, 80, "保存原始Markdown文本...", visible=True)
            # --- [新增] 保存原始Markdown文本用于复制功能 ---
            workspace.analysis_text_raw_md = full_analysis_text
            # --- [新增结束] ---
            api.update_status("文本分析已生成。", workspace_id=workspace.id)
            api.update_progress(workspace_id, 90, "文本分析已生成...", visible=True)

            _save_generation_to_history(api, workspace)

            workspace.has_new_result = True
            api.show_alert("文本分析已生成。", 'info')
            api.update_progress(workspace_id, 100, "任务完成!", visible=True)

    except Exception as e:
        # 在流式模式下，如果发生异常，也应该通知前端
        error_message = f"生成文本分析时发生错误: {e}"
        api.update_progress(workspace_id, 50, "生成文本分析时发生错误...", visible=True)
        workspace = api.workspace_manager.workspaces.get(workspace_id)
        api.end_analysis_stream(workspace.id, error_message)
        api.update_progress(workspace_id, 80, "保存当前结果...", visible=True)
        api.update_status(error_message, is_error=True, workspace_id=workspace.id)
        api.update_progress(workspace_id, 100, "任务完成!", visible=True)
    finally:
        api.set_ui_lock_state(False, workspace_id)
        import time
        time.sleep(2)  # 延迟2秒，让用户看到“完成”状态
        api.update_progress(workspace_id, 0, "空闲", visible=False)


def _save_generation_to_history(api: "MainAppApi", workspace):
    """
    将当前工作区的成功生成结果保存到历史记录中。
    现在会保存代码输出、文字分析以及多文件输出的元数据和副本。
    """
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_id = str(uuid.uuid4())[:8]
        history_folder_name = f"{timestamp}_{unique_id}"
        history_path = os.path.join(HISTORY_DIR, history_folder_name)
        inputs_path = os.path.join(history_path, "inputs")
        outputs_path = os.path.join(history_path, "outputs") # 新增: 用于存放输出文件的目录
        os.makedirs(inputs_path, exist_ok=True)
        os.makedirs(outputs_path, exist_ok=True)

        api.update_status(f"正在保存快照到历史记录: {history_folder_name}", workspace_id=workspace.id)

        # 保存输入文件 (逻辑不变)
        input_files_metadata = []
        for target in ['data', 'prompt']:
            for file_info in workspace.managed_files[target]:
                source_path = os.path.join(INPUT_DIR, file_info['managed_name'])
                if os.path.exists(source_path):
                    shutil.copy2(source_path, os.path.join(inputs_path, file_info['managed_name']))
                    # --- 核心修复：在保存时补充 target 键 ---
                    # 1. 创建一个文件信息的副本
                    file_meta_copy = {k: v for k, v in file_info.items() if k != 'preview_id'}
                    # 2. 将当前循环的 target ('data' 或 'prompt') 添加进去
                    file_meta_copy['target'] = target
                    # 3. 将带有 target 的完整信息添加到列表中
                    input_files_metadata.append(file_meta_copy)

        # 保存输出文件和元数据
        saved_outputs_metadata = []
        for item in workspace.generated_outputs: # index不再需要
            source_path = item.get('final_path')
            filename_in_zip = item.get('filename')

            if source_path and filename_in_zip and os.path.exists(source_path):
                # 使用原始文件名保存到历史记录的 outputs 子目录中
                history_dest_path = os.path.join(outputs_path, filename_in_zip)
                shutil.copy2(source_path, history_dest_path)

                # 创建一个新的元数据副本用于保存
                item_copy = item.copy()
                # 相对路径应相对于 history_folder_name
                item_copy['history_relative_path'] = os.path.join("outputs", filename_in_zip).replace('\\', '/')
                saved_outputs_metadata.append(item_copy)

        raw_md_content = getattr(workspace, 'analysis_text_raw_md', '').strip()
        placeholder_with_hash = "# 此处将显示对图表的文字分析..."
        placeholder_without_hash = "此处将显示对图表的文字分析..."  # 兼容旧的被污染的数据

        # --- 在保存前计算状态标志 ---
        status_flags = {
            'has_plot': any(item.get('type') == 'image' for item in workspace.generated_outputs),
            'has_data_file': any(item.get('type') == 'data' for item in workspace.generated_outputs),
            'has_code': bool(workspace.last_generated_code and workspace.last_generated_code.strip() != "# 尚未生成任何代码."),
            'has_console_output': bool(workspace.console_output and workspace.console_output.strip()),
            'has_analysis': bool(raw_md_content and raw_md_content != placeholder_with_hash and raw_md_content != placeholder_without_hash)
        }

        # 创建元数据JSON
        metadata = {
            "display_name": f"生成于 {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "timestamp": datetime.now().isoformat(),
            "prompt_input_text": workspace.prompt_input_text,
            "input_files": input_files_metadata,
            "generated_code": workspace.last_generated_code,
            "console_output": workspace.console_output,
            "analysis_text": workspace.analysis_text,
            "analysis_text_raw_md": getattr(workspace, 'analysis_text_raw_md', workspace.analysis_text),
            "generated_outputs": saved_outputs_metadata, # 保存带有历史路径的完整输出列表
            **status_flags  # <-- 使用字典解包将所有状态标志添加进去
        }
        with open(os.path.join(history_path, "metadata.json"), 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=4, ensure_ascii=False)

        api.history_manager.add_or_update_item_in_cache(history_folder_name)
        api.refresh_ui_lists()

    except Exception as e:
        error_msg = f"保存历史记录时出错: {e}"
        print(error_msg)
        api.update_status(error_msg, is_error=True, workspace_id=workspace.id)


def perform_llm_test(api_config: dict):
    """
    对给定的API配置执行一个简单的连通性测试。

    Args:
        api_config (dict): 包含 'base_url', 'api_key', 'model' 的字典。

    Returns:
        dict: 包含 'status' 和 'message' 的结果字典。
    """
    base_url = api_config.get('base_url', '').strip()
    api_key = api_config.get('api_key', '').strip()
    model = api_config.get('model', '').strip()

    # 简单的URL验证
    if not base_url or not base_url.startswith(('http://', 'https://')):
        return {"status": "error", "message": "URL格式无效"}

    # 确保URL以 /v1/chat/completions 结尾
    if not base_url.endswith('/v1/chat/completions'):
        if base_url.endswith('/'):
            base_url = base_url[:-1]
        if not base_url.endswith('/v1'):
             base_url += '/v1'
        base_url += '/chat/completions'


    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    # 一个非常简单且无害的测试负载
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "Hello"}],
        "max_tokens": 5
    }

    try:
        response = requests.post(
            base_url,
            headers=headers,
            json=payload,
            timeout=URL_TEST_TIMEOUT,
            stream=False # 确保我们不需要处理流
        )

        # 检查HTTP状态码
        if response.status_code == 200:
            return {"status": "success", "message": URL_STATUS_COLORS["success"][1]}
        elif response.status_code == 401:
             return {"status": "error", "message": f"认证失败 (401)"}
        elif response.status_code == 404:
            return {"status": "error", "message": f"端点未找到 (404)"}
        else:
            # 尝试从响应中获取更详细的错误信息
            try:
                error_detail = response.json().get('error', {}).get('message', '无详细信息')
                return {"status": "error", "message": f"错误 ({response.status_code}): {error_detail[:60]}..."}
            except:
                return {"status": "error", "message": f"连接失败 ({response.status_code})"}

    except requests.exceptions.Timeout:
        return {"status": "timeout", "message": URL_STATUS_COLORS["timeout"][1]}
    except requests.exceptions.RequestException as e:
        # 捕获所有其他 requests 相关的错误，如连接错误
        return {"status": "error", "message": f"无法连接: {str(e.__class__.__name__)}"}
    except Exception as e:
        # 捕获其他未知错误
        return {"status": "error", "message": f"未知错误: {str(e)}"}