import os
import sys


def get_app_base_path(relative_path='.'):
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def get_models_cache_dir():
    # --- 【核心修改】 ---
    # 使用 get_app_base_path 来创建 exe 旁边的 models_cache 文件夹
    return os.path.join(get_app_base_path(), 'models_cache')


# 设置环境变量，Hugging Face 的库会自动使用这个路径
models_cache = get_models_cache_dir()
os.environ['HF_HOME'] = models_cache
os.environ['HUGGINGFACE_HUB_CACHE'] = models_cache # 更现代的变量名

print(f"模型将缓存到: {models_cache}")

# 列出所有 navigator 需要的模型
# 使用 Hugging Face Hub 上的标准名称
MODELS_TO_DOWNLOAD = [
    "moka-ai/m3e-base",
    "sentence-transformers/clip-ViT-B-32"
    # 如果有其他模型，继续在这里添加
]


def download():
    for model_name in MODELS_TO_DOWNLOAD:
        try:
            print(f"正在下载并缓存模型: {model_name} ...")
            from sentence_transformers import SentenceTransformer
            # 这行代码会自动检查缓存，如果模型不存在，就会下载
            SentenceTransformer(model_name, cache_folder=models_cache)
            print(f"模型 '{model_name}' 已成功准备就绪。")
        except Exception as e:
            print(f"错误：下载模型 '{model_name}' 失败: {e}", file=sys.stderr)
            sys.exit(1) # 失败时退出，返回非零状态码


if __name__ == "__main__":
    download()
    print("所有必要的AI模型已下载完毕。")