# download_models.py (MODIFIED)

import os
import sys

# --- [核心新增] ---
# 在导入任何Hugging Face相关库之前，设置镜像地址
# 这会告诉所有底层的huggingface_hub库使用这个国内镜像服务器
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'


# --- [新增结束] ---


def get_app_base_path(relative_path='.'):
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def get_models_cache_dir():
    return os.path.join(get_app_base_path(), 'models_cache')


# 设置环境变量，Hugging Face 的库会自动使用这个路径
models_cache = get_models_cache_dir()
os.environ['HF_HOME'] = models_cache
os.environ['HUGGINGFACE_HUB_CACHE'] = models_cache  # 更现代的变量名

print(f"模型将缓存到: {models_cache}")
print(f"使用的下载镜像: {os.environ.get('HF_ENDPOINT')}")  # 打印出来确认

# 列出所有 navigator 需要的模型
MODELS_TO_DOWNLOAD = [
    "moka-ai/m3e-base",
    "sentence-transformers/clip-ViT-B-32"
    # 如果有其他模型，继续在这里添加
]


def download():
    for model_name in MODELS_TO_DOWNLOAD:
        try:
            print(f"正在下载并缓存模型: {model_name} ...")
            # 导入 SentenceTransformer 的操作放在函数内部
            from sentence_transformers import SentenceTransformer

            # 这行代码会自动检查缓存，如果模型不存在，就会从设置好的镜像下载
            SentenceTransformer(model_name, cache_folder=models_cache)
            print(f"模型 '{model_name}' 已成功准备就绪。")
        except Exception as e:
            print(f"错误：下载模型 '{model_name}' 失败: {e}", file=sys.stderr)
            # 打印更详细的错误信息，帮助排查是网络问题还是其他问题
            import traceback
            traceback.print_exc()
            sys.exit(1)  # 失败时退出，返回非零状态码


if __name__ == "__main__":
    download()
    print("所有必要的AI模型已下载完毕。")