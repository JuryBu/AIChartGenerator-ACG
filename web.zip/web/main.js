// 全局状态和UI元素引用
const ui = {};
ui.colorPalette = ['#82A5D1', '#97B99C', '#F5C578', '#D16D66', '#8884d8'];
let codeMirrorInstance = null;
let activeWorkspaceId = null;
const runningWorkspaces = new Set();
let activeHistoryId = null;
let isMultiSelectMode = false;
let selectedHistoryIds = new Set();
let alertTimeout = null; // 用于管理自定义警告框的计时器
let currentWorkspaceData = {};
let currentApiType = 'external';
let imageCarouselData = []; // 存储轮播图片信息
let currentCarouselIndex = 0; // 当前轮播索引

// --- Python调用的全局函数 ---
window.app = {
    updateStatus: (message, isError = false, workspaceId = null) => {
        ui.statusText.textContent = message;
        ui.statusText.style.color = isError ? 'var(--danger-color)' : 'var(--text-muted-color)';
    },

    showAlert: (message, level = 'info') => {
        clearTimeout(alertTimeout);
        ui.customAlertMessage.textContent = message;
        ui.customAlert.className = 'custom-alert';
        ui.customAlert.classList.add(level); // 'info', 'warning', 'error'
        ui.customAlert.style.display = 'flex';
        alertTimeout = setTimeout(() => {
            ui.customAlert.style.display = 'none';
        }, 5000);
    },

    displayPlot: (workspaceId, base64Image) => {
        if (workspaceId !== activeWorkspaceId) return;

        // 查找容器内是否已有图片或占位符
        let displayElement = ui.plotOutput.querySelector('img, .output-placeholder');

        if (base64Image) {
            if (displayElement && displayElement.tagName === 'IMG') {
                // 如果已有图片，只更新 src
                displayElement.src = base64Image;
            } else {
                // 如果没有图片（或之前是占位符），创建新的 img 元素
                if (displayElement) displayElement.remove(); // 移除旧的占位符
                const img = document.createElement('img');
                img.src = base64Image;
                img.alt = "Generated Plot";
                // 确保图片元素在轮播控件之前
                ui.plotOutput.prepend(img);
            }
        } else {
            // 如果没有 base64 数据，显示占位符
            if (displayElement) displayElement.remove(); // 移除旧的图片或占位符
            const placeholder = document.createElement('div');
            placeholder.className = 'output-placeholder';
            placeholder.textContent = '生成的图表将显示在这里';
            ui.plotOutput.prepend(placeholder);
        }
    },

    updateCodeOutput: (workspaceId, code) => {
        if (workspaceId !== activeWorkspaceId) return;
        // 使用新的 CodeMirror 初始化/更新函数
        initializeCodeMirror(code);
    },

    startCodeStream: (workspaceId) => {
        if (workspaceId !== activeWorkspaceId) return;
        // 开始流式传输时，直接初始化一个空的编辑器
        initializeCodeMirror('');
    },

    appendCodeChunk: (workspaceId, chunk) => {
        if (workspaceId !== activeWorkspaceId) return;
        if (codeMirrorInstance) {
            // 使用高效的方式在末尾追加文本
            const doc = codeMirrorInstance.getDoc();
            doc.replaceRange(chunk, CodeMirror.Pos(doc.lastLine()));
        }
    },

    endCodeStream: (workspaceId, full_code) => {
        if (workspaceId !== activeWorkspaceId) return;
        if (codeMirrorInstance) {
            // 流结束后，用完整代码覆盖，确保最终一致性
            codeMirrorInstance.setValue(full_code);
        }
    },

    updateConsoleOutput: (workspaceId, text) => {
        if (workspaceId !== activeWorkspaceId) return;
        ui.consoleOutputTextarea.value = text;
    },

    // --- 处理分析文本流的系列函数 ---
    startAnalysisStream: (workspaceId) => {
        if (workspaceId !== activeWorkspaceId) return;
        // 显示思考中动画
        ui.analysisOutput.innerHTML = `
            <div class="thinking-animation">
                <span>正在生成分析报告</span>
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>`;
    },

    appendAnalysisChunk: (workspaceId, chunk) => {
        if (workspaceId !== activeWorkspaceId) return;

        // 第一次收到 chunk 时，清空“思考中”动画
        const thinkingEl = ui.analysisOutput.querySelector('.thinking-animation');
        if (thinkingEl) {
            ui.analysisOutput.innerHTML = '';
        }

        // 追加内容
        ui.analysisOutput.innerHTML += chunk;

        // 每次追加内容后，都尝试渲染新出现的公式
        renderAllMath();

        // 实时滚动到底部
        ui.analysisOutput.scrollTop = ui.analysisOutput.scrollHeight;
    },

    endAnalysisStream: (workspaceId, full_text) => {
        if (workspaceId !== activeWorkspaceId) return;

        // 从后端加载的工作区数据中获取原始MD
        // 注意：这是一个简化处理，假设在流结束时，后端已经更新了工作区对象
        // 一个更健壮的方法是在 end_analysis_stream 的Python API中同时传递HTML和原始MD
        if (currentWorkspaceData && currentWorkspaceData.id === workspaceId) {
        }

        // 使用最终的完整内容覆盖，确保数据一致性
        ui.analysisOutput.innerHTML = full_text;

        // 调用渲染函数
        renderAllMath();
    },

    setUILockState: (isLocked, workspaceId) => {
        if (!workspaceId) {
            console.error("setUILockState called without a workspaceId.");
            return;
        }

        if (isLocked) {
            runningWorkspaces.add(workspaceId);
        } else {
            runningWorkspaces.delete(workspaceId);
        }

        // 触发统一的UI更新
        updateUIForCurrentState();
    },

    renderLists: (data) => {
        // --- 核心修复：将接收到的 settings 数据传递给 renderWorkspaces ---
        renderWorkspaces(data.workspaces.items, data.workspaces.active_id, data.settings);
        renderHistory(data.history);
    },

    renderSettings: (data) => {
        renderSettings(data);
    },

    // --- 专门用于更新进度条的方法 ---
    updateWorkspaceProgress: (workspaceId, progress) => {
        const workspaceItem = ui.workspaceList.querySelector(`.list-item[data-id="${workspaceId}"]`);
        if (!workspaceItem) return;

        const progressContainer = workspaceItem.querySelector('.workspace-progress-bar-container');
        const progressFill = workspaceItem.querySelector('.progress-bar-fill');
        const progressText = workspaceItem.querySelector('.progress-bar-text');

        if (progress.visible) {
            progressContainer.style.display = 'flex';
            progressFill.style.width = `${progress.value}%`;
            progressText.textContent = progress.text;
        } else {
            progressContainer.style.display = 'none';
        }
    },

    renderOutputs: (workspaceId, outputsList) => {
        if (workspaceId !== activeWorkspaceId) return;

        // --- 1. 数据分类 ---
        const imageOutputs = (outputsList || []).filter(item => item.type === 'image');
        const nonImageOutputs = (outputsList || []).filter(item => item.type !== 'image');

        const fileListContainer = document.getElementById('output-files-list');
        const template = document.getElementById('output-file-item-template');
        fileListContainer.innerHTML = ''; // 清空旧内容

        // --- 2. 渲染右侧的非图片文件列表 ---
        if (nonImageOutputs.length === 0) {
            fileListContainer.innerHTML = '<div class="output-placeholder">无其他输出文件</div>';
        } else {
            // --- 使用卡片模板渲染 ---
            nonImageOutputs.forEach(item => { // *** 核心修改：只遍历 nonImageOutputs ***
                const clone = template.content.cloneNode(true);
                const card = clone.querySelector('.file-preview-card');
                const iconEl = clone.querySelector('.file-icon');
                const detailsEl = clone.querySelector('.file-details');
                const nameEl = clone.querySelector('.file-name'); // 现在这是一个 div
                const metaEl = clone.querySelector('.file-meta');

                // --- 智能省略逻辑 ---
                const filename = item.filename;
                const dotIndex = filename.lastIndexOf('.');

                // 检查是否存在后缀，且后缀不太长
                if (dotIndex > 0 && dotIndex > filename.length - 7) {
                    const nameStart = filename.substring(0, dotIndex);
                    const nameEnd = filename.substring(dotIndex);

                    const spanStart = document.createElement('span');
                    spanStart.className = 'file-name-start';
                    spanStart.textContent = nameStart;

                    const spanEnd = document.createElement('span');
                    spanEnd.className = 'file-name-end';
                    spanEnd.textContent = nameEnd;

                    nameEl.appendChild(spanStart);
                    nameEl.appendChild(spanEnd);
                } else {
                    // 对于没有后缀或特殊情况的文件，使用原始的末尾省略
                    nameEl.textContent = filename;
                    nameEl.style.textOverflow = 'ellipsis';
                    nameEl.style.whiteSpace = 'nowrap';
                }

                metaEl.textContent = item.file_size_str || '...';

                // 注意：因为已经排除了图片，这里的 if (item.type === 'image') 分支不会被执行，
                // 但为了代码完整性，我们保留它。
                if (item.type === 'image' && item.base64) {
                    // (此逻辑块不会被触发)
                } else {
                    card.classList.add('generic-type');
                    // 设置通用文件图标
                    const getIconForType = (type, filename) => {
                        if (type === 'data') return '../assets/icons/generic_file_icon.png';
                        if (filename.endsWith('.pdf')) return '../assets/icons/quote_icon.png';
                        return '../assets/icons/generic_file_icon.png';
                    };
                    iconEl.src = getIconForType(item.type, item.filename);

                    // 设置卡片点击动作为“用系统应用打开”
                    card.dataset.action = 'open-file';
                    card.dataset.filePath = item.final_path;
                    card.title = `点击打开: ${item.filename}`;
                }

                fileListContainer.appendChild(clone);
            });
        }

        // --- 3. 渲染左侧的图片预览（轮播逻辑） ---
        imageCarouselData = imageOutputs; // *** 核心修改：使用已过滤好的 imageOutputs ***
        currentCarouselIndex = 0;

        if (imageCarouselData.length > 1) {
            // 有多张图片：启用轮播
            ui.plotOutput.classList.add('has-carousel');
            updateCarouselDisplay();
        } else if (imageCarouselData.length === 1) {
            // 只有一张图片：禁用轮播并直接显示
            ui.plotOutput.classList.remove('has-carousel');
            const singleImage = imageCarouselData[0];
            window.app.displayPlot(activeWorkspaceId, singleImage.base64);
            ui.plotOutput.dataset.filePath = singleImage.final_path;
        } else {
            // 没有任何图片：禁用轮播并显示占位符
            ui.plotOutput.classList.remove('has-carousel');
            window.app.displayPlot(activeWorkspaceId, null); // 传递null来清空
            delete ui.plotOutput.dataset.filePath;
        }
    },

    updateLLMStatus: (result) => { // <--- 修正：使用冒号 :
        const indicator = document.getElementById('llm-status-indicator');
        if (!indicator) return;

        const statusTextEl = indicator.querySelector('.status-text');

        // 移除所有旧的状态类
        indicator.className = 'llm-status-indicator';
        // 添加新的状态类
        indicator.classList.add(`status-${result.status}`);

        statusTextEl.textContent = result.message;
    },

    showSetupWizard: () => {
        document.getElementById('loading-overlay').style.display = 'none';
        document.getElementById('setup-wizard').style.display = 'flex';
    },

    updateSetupProgress: (value, text) => {
        // 如果 value 不是-1, 才更新进度条的宽度
        if (value !== -1) {
            document.getElementById('setup-progress-fill').style.width = `${value}%`;
        }
        // 始终更新状态文本
        document.getElementById('setup-status-text').textContent = text;
    },

    setupFailed: (errorMessage) => {
        window.app.showAlert(errorMessage, 'error');
        document.getElementById('setup-status-text').textContent = "安装失败！";
        // 可以在这里启用一个“重试”按钮
    },

    setupComplete: () => {
        // 安装完成后，隐藏向导，显示主应用
        document.getElementById('setup-wizard').style.display = 'none';
        document.getElementById('app-container').classList.remove('hidden');

        // 重新加载一次所有数据，因为可能后台已经有了新的工作区等
        window.pywebview.api.js_is_ready().then(renderAll);
    },


    setAuxiliaryButtonsDisabled: (disabled) => {
    const btnIds = ['help-btn', 'navigator-btn', 'font-manager-btn'];
    btnIds.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.disabled = disabled;
            // (可选) 添加一个视觉提示，比如改变透明度
            btn.style.opacity = disabled ? '0.5' : '1';
        }
    });


},

};

// --- 初始化 ---
window.addEventListener('pywebviewready', init);

async function init() {
    console.log("pywebview is ready. Initializing application...");

    try {
        renderDynamicUI();
        cacheDOMElements();
        const initialData = await window.pywebview.api.js_is_ready();
        renderAll(initialData);
        bindEventListeners();
        await window.pywebview.api.frontend_fully_ready();
        updateButtonStates();
        document.getElementById('loading-overlay').style.display = 'none';
        document.getElementById('app-container').classList.remove('hidden');
        window.app.updateStatus("初始化完成，欢迎使用！");

    } catch (e) {
        console.error("应用初始化失败:", e);
        const loadingOverlay = document.getElementById('loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.innerHTML = `<div class="error-message">应用初始化失败: ${e.message}<br>请检查开发者控制台获取更多信息。</div>`;
        }
        const appContainer = document.getElementById('app-container');
        if (appContainer) {
             appContainer.classList.remove('hidden');
        }
    }
}

function cacheDOMElements() {
    // 辅助函数：将 'kebab-case' 转换为 'camelCase'
    const kebabToCamel = (s) => s.replace(/-(\w)/g, (_, c) => c.toUpperCase());

    const ids = [
        'left-sidebar', 'main-content', 'right-sidebar', 'status-bar',
        'lockable-config-area',
        'model-settings-form', 'font-settings-form', 'save-config-btn', 'help-btn',
        'data-input-area', 'prompt-input-area', 'agent-mode-checkbox',
        'data-input-text', 'prompt-input-text',
        'tabs-container', 'plot-output', 'code-output-container', 'console-output-textarea', 'analysis-output',
        'copy-code-btn', 'copy-code-md-btn',
        'copy-console-btn',
        'copy-analysis-btn', 'copy-analysis-md-btn',
        'workspaces-panel', 'history-panel', 'add-workspace-btn', 'delete-workspace-btn',
        'workspace-list', 'history-search-input', 'load-history-btn', 'delete-history-btn',
        'history-list', 'generate-btn', 'generate-analysis-btn',
        'clear-output-btn', 'toggle-clear-options-btn', 'clear-options-panel',
        'run-code-btn', 'save-output-btn',
        'status-text',
        'custom-alert', 'custom-alert-message', 'custom-alert-close',
        'loading-overlay', 'app-container',
        'rename-history-btn',
        'cleanup-options-panel'
    ];

    // 在存入ui对象时，将key转换为驼峰命名
    ids.forEach(id => {
        const camelCaseKey = kebabToCamel(id);
        ui[camelCaseKey] = document.getElementById(id);
    });

    // --- 手动缓存新的、更复杂的元素引用 ---
    ui.toggleMultiSelectBtn = document.getElementById('toggle-multi-select-btn');
    ui.multiSelectIcon = document.getElementById('multi-select-icon');
    ui.toggleAutoCleanupBtn = document.getElementById('toggle-auto-cleanup-btn');
    ui.autoCleanupIcon = document.getElementById('auto-cleanup-icon');
    ui.cleanupExpanderIcon = document.getElementById('cleanup-expander-icon');

    // --- 缓存图片预览模态框的元素 ---
    ui.imageModal = document.getElementById('image-modal');
    ui.modalImgContent = document.getElementById('modal-img-content');

    // 后续的查询也使用驼峰命名
    ui.tabBtns = document.querySelectorAll('.tab-btn');
    // --- 为Tab按钮分配颜色 ---
    ui.tabBtns.forEach((btn, index) => {
        const color = ui.colorPalette[index % ui.colorPalette.length];
        btn.style.setProperty('--item-color', color);
    });

    ui.sidebarTabBtns = document.querySelectorAll('.sidebar-tab-btn');
    ui.analysisOutput = document.getElementById('analysis-output');
    ui.clearOptionCheckboxes = document.querySelectorAll('#clear-options-panel input[type="checkbox"]');
    ui.codeOutputContainer = document.getElementById('code-output-container');
    ui.consoleOutputTextarea = document.getElementById('console-output-textarea');

    ui.plotOutput = document.getElementById('plot-output'); // 确保已缓存
    ui.carouselControls = document.querySelector('.carousel-controls');
    ui.carouselPrevBtn = document.getElementById('carousel-prev');
    ui.carouselNextBtn = document.getElementById('carousel-next');
    ui.carouselCounter = document.getElementById('carousel-counter');

}

// 动态创建核心UI组件，避免在HTML中硬编码
function renderDynamicUI() {
    const createInputSection = (id, title, placeholder) => {
        const area = document.getElementById(`${id}-input-area`);
    // 为标题栏添加新结构和颜色类
    area.innerHTML = `
        <div class="titled-section-header">
             <img src="../assets/icons/database.png" alt="icon">
             <h4>${title}</h4>
        </div>
        <div class="input-actions-bar"> <!-- 新增一个容器包裹按钮 -->
            <div class="input-actions">
                <button id="add-${id}-file-btn" class="btn-sm">添加文件</button>
                <button id="clear-${id}-files-btn" class="btn-sm btn-danger-sm">清空</button>
                <button id="color-picker-${id}-btn" class="btn-sm" title="颜色选择器 (点击复制HEX)">🎨</button>
                <input type="color" id="color-picker-${id}-input" style="display:none;">
            </div>
        </div>
        <div id="${id}-file-previews" class="file-preview-area"></div>
        <textarea id="${id}-input-text" placeholder="${placeholder}"></textarea>
    `;
    };
    createInputSection('data', '数据输入 (文件或文本)', '或在此处直接粘贴CSV/TSV格式的文本数据...');
    createInputSection('prompt', '绘图要求 (文件或文本)', '在此处输入详细的绘图要求...');
}

function setupColorPicker(buttonId, inputId) {
    const button = document.getElementById(buttonId);
    const input = document.getElementById(inputId);

    if (!button || !input) return;

    button.addEventListener('click', () => {
        input.click();
    });

    input.addEventListener('input', (event) => {
        const color = event.target.value;
        navigator.clipboard.writeText(color).then(() => {
            window.app.updateStatus(`颜色 ${color} 已复制到剪贴板!`);
            button.style.backgroundColor = color;
            setTimeout(() => {
                button.style.backgroundColor = '';
            }, 1500);
        }).catch(err => {
            window.app.showAlert(`复制失败: ${err}`, 'error');
        });
    });
}

// --- 状态与UI管理 ---
function bindEventListeners() {
    // 主操作
    ui.generateBtn.addEventListener('click', handleGeneration);
    ui.generateAnalysisBtn.addEventListener('click', handleGenerateAnalysis);
    ui.runCodeBtn.addEventListener('click', handleRunCode);
    ui.saveOutputBtn.addEventListener('click', handleSaveOutput);

    // 清除按钮事件
    ui.clearOutputBtn.addEventListener('click', handleClearOutput);
    ui.toggleClearOptionsBtn.addEventListener('click', () => {
        ui.clearOptionsPanel.classList.toggle('open');
    });

    // --- 将工作区列表的点击事件统一处理 ---
    ui.workspaceList.addEventListener('click', e => {
        // 1. 首先检查点击的是否是日志切换按钮
        if (e.target.classList.contains('toggle-log-btn')) {
            // 是的，执行展开/折叠逻辑
            e.stopPropagation(); // 关键：阻止事件冒泡！这样就不会触发下面的工作区选择了。

            const logContent = e.target.closest('.workspace-status-log').querySelector('.log-content');
            const isVisible = logContent.style.display === 'block';
            logContent.style.display = isVisible ? 'none' : 'block';
            e.target.textContent = isVisible ? '展开' : '折叠';

        // 2. 如果点击的不是切换按钮，才执行常规的列表项选择逻辑
        } else {
            handleListSelection(e, 'workspace');
        }
    });

    // 点击面板外部时关闭
    document.addEventListener('click', (e) => {
        if (!ui.clearOptionsPanel.contains(e.target) && !ui.toggleClearOptionsBtn.contains(e.target)) {
            ui.clearOptionsPanel.classList.remove('open');
        }
    });

    // 设置
    ui.saveConfigBtn.addEventListener('click', handleSaveConfig);
    document.getElementById('font-manager-btn').addEventListener('click', () => window.pywebview.api.open_font_manager());
    document.getElementById('navigator-btn').addEventListener('click', () => window.pywebview.api.open_navigator());
    ui.helpBtn.addEventListener('click', () => window.pywebview.api.show_help_window());
    document.getElementById('version-check-btn').addEventListener('click', () => window.pywebview.api.open_version_checker());

    // 工作区
    ui.addWorkspaceBtn.addEventListener('click', handleAddWorkspace);
    ui.deleteWorkspaceBtn.addEventListener('click', handleDeleteWorkspace);

    // 历史记录
    ui.historyList.addEventListener('click', e => handleListSelection(e, 'history'));
    ui.loadHistoryBtn.addEventListener('click', handleLoadHistory);
    ui.deleteHistoryBtn.addEventListener('click', handleDeleteHistory);
    ui.historySearchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase().trim();
        window.pywebview.api.search_history(searchTerm);
    });

    // 图表大图预览
    ui.plotOutput.addEventListener('click', () => {
        const imgElement = ui.plotOutput.querySelector('img');
        // 只有当存在图片且图片有有效src时才触发
        if (imgElement && imgElement.src) {
            ui.modalImgContent.src = imgElement.src;
            ui.imageModal.style.display = 'flex';
        }
    });
    ui.plotOutput.style.cursor = 'pointer';

        // ---模态框事件监听 ---
    const modal = document.getElementById('image-modal');
    const modalImg = document.getElementById('modal-img-content');
    const closeModal = document.querySelector('.modal-close');

    const hideModal = () => { modal.style.display = 'none'; };
    closeModal.addEventListener('click', hideModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) { // 点击背景关闭
            hideModal();
        }
    });


    // 文件操作 (动态绑定) -- 大幅修改
    document.body.addEventListener('click', async (e) => {

        // --- 处理卡片点击和移除按钮 ---
        const card = e.target.closest('.file-preview-card');

        if (e.target.classList.contains('remove-file-btn')) {
            e.stopPropagation(); // 阻止事件冒泡到卡片
            const { target, previewId } = e.target.dataset;
            window.pywebview.api.remove_file(target, activeWorkspaceId, previewId);
            return;
        }

        if (card) {
            const action = card.dataset.action;
            if (action === 'view-image') {
                modalImg.src = card.dataset.imageSrc;
                modal.style.display = 'flex';
            } else if (action === 'open-file') {
                const filePath = card.dataset.filePath;
                window.pywebview.api.open_file_in_system(filePath);
            }
            return; // 卡片被处理，结束
        }


        // --- 处理添加/清空按钮 ---
        if (e.target.id === 'add-data-file-btn') {
            await saveCurrentWorkspaceState();
            window.pywebview.api.select_files('data', activeWorkspaceId);
        }
        if (e.target.id === 'add-prompt-file-btn') {
            await saveCurrentWorkspaceState();
            window.pywebview.api.select_files('prompt', activeWorkspaceId);
        }
        if (e.target.id === 'clear-data-files-btn') {
            if (activeWorkspaceId && confirm("确定要清空数据输入区的所有文本和文件吗？")) {
                window.pywebview.api.clear_input_area(activeWorkspaceId, 'data');
            }
        }
        if (e.target.id === 'clear-prompt-files-btn') {
            if (activeWorkspaceId && confirm("确定要清空绘图要求区的所有文本和文件吗？")) {
                window.pywebview.api.clear_input_area(activeWorkspaceId, 'prompt');
            }
        }
    });

    // --- 为左侧配置表单添加实时保存监听器 ---
    // 使用 'change' 事件，当用户修改完一个输入框并失去焦点时触发
    ui.modelSettingsForm.addEventListener('change', (e) => handleWorkspaceConfigChange(e));
    ui.fontSettingsForm.addEventListener('change', (e) => handleWorkspaceConfigChange(e));

    // --- 复制按钮的事件监听器 ---
    document.body.addEventListener('click', (e) => {
        const button = e.target.closest('.bubble-toolbar-button');
        if (!button) return;

        let textToCopy = '';
        const id = button.id;

        // 辅助函数，显示复制成功提示
        const showCopySuccess = () => window.app.showAlert('已复制到剪贴板!', 'info');

        // 移除对 copy-code-btn 和 copy-code-md-btn 的处理逻辑
        // 因为这些按钮现在由 enhanceCodeOutput() 动态创建，并自带 onclick 事件
        if (id === 'copy-console-btn') {
            textToCopy = ui.consoleOutputTextarea.value;
        } else if (id === 'copy-analysis-btn') {
            // 从DOM中提取纯文本
            textToCopy = ui.analysisOutput.innerText;
        } else if (id === 'copy-analysis-md-btn') {
            // 从我们保存的状态中获取原始Markdown
            textToCopy = currentWorkspaceData.analysis_text_raw_md || ui.analysisOutput.innerText;
        }

        if (textToCopy) {
            navigator.clipboard.writeText(textToCopy).then(showCopySuccess);
        }
    });

    // Tabs
    ui.tabBtns.forEach(btn => btn.addEventListener('click', handleTabSwitch));
    ui.sidebarTabBtns.forEach(btn => btn.addEventListener('click', handleSidebarTabSwitch));

    // 自定义警告框关闭按钮
    ui.customAlertClose.addEventListener('click', () => {
        ui.customAlert.style.display = 'none';
    });

    // 初始化颜色选择器
    setupColorPicker('color-picker-data-btn', 'color-picker-data-input');
    setupColorPicker('color-picker-prompt-btn', 'color-picker-prompt-input');

    ui.renameHistoryBtn.addEventListener('click', handleRenameHistory);

    // 1. 多选模式按钮
    ui.toggleMultiSelectBtn.addEventListener('click', () => {
        isMultiSelectMode = !isMultiSelectMode; // 直接切换布尔值状态
        updateMultiSelectUI(); // 调用更新UI的函数
    });

    // 2. 自动清理功能开关 + 面板展开 (统一在一个监听器里)
    ui.toggleAutoCleanupBtn.addEventListener('click', (e) => {
        // 检查点击的是否是展开图标本身
        const isExpanderClick = e.target === ui.cleanupExpanderIcon || e.target.parentElement === ui.cleanupExpanderIcon;

        if (isExpanderClick) {
            // 只负责展开/收起面板
            const isOpen = ui.cleanupOptionsPanel.classList.toggle('open');
            ui.cleanupExpanderIcon.src = `../assets/icons/chevron-${isOpen ? 'up' : 'down'}.png`;
        } else {
            // 点击按钮的其他部分，则切换“自动清理”的开关状态
            const currentState = ui.autoCleanupIcon.src.includes('check-circle.png');
            const newState = !currentState;
            ui.autoCleanupIcon.src = `../assets/icons/${newState ? 'check-circle' : 'circle'}.png`;

            // --- 新增：立即更新按钮UI状态 ---
            ui.toggleAutoCleanupBtn.classList.toggle('active', newState);

            // 通知后端保存设置
            handleAutoCleanupSettingsChange();
        }
    });

    // 使用事件委托处理重命名按钮和复选框
    ui.historyList.addEventListener('click', e => {
        // --- 预览按钮处理逻辑 ---
        const previewButton = e.target.closest('.btn-preview');
        if (previewButton) {
            const itemEl = previewButton.closest('.list-item');
            if (itemEl) {
                const historyId = itemEl.dataset.id;
                const action = previewButton.dataset.action;

                if (action === 'preview-input') {
                    window.pywebview.api.show_history_input_preview(historyId);
                } else if (action === 'preview-output') {
                    window.pywebview.api.show_history_output_preview(historyId);
                }
            }
            return; // 处理完预览点击后，不再执行后续的选择逻辑
        }

        if (e.target.classList.contains('btn-save-rename')) {
            handleSaveRename(e);
        } else if (e.target.classList.contains('btn-cancel-rename')) {
            handleCancelRename(e);
        }
    });

    ui.historyList.addEventListener('change', e => {
        if (e.target.classList.contains('history-select-checkbox')) {
            handleHistoryCheckboxChange(e);
        }
    });

    // 监听 Ctrl 键
    document.addEventListener('keydown', e => {
        if (e.ctrlKey && !isMultiSelectMode) {
            // 只是按下Ctrl时不做任何事, 等待点击
        }
    });

    ui.carouselPrevBtn.addEventListener('click', (event) => {
        event.stopPropagation(); // 阻止事件冒泡
        if (currentCarouselIndex > 0) {
            currentCarouselIndex--;
            updateCarouselDisplay();
        }
    });

    ui.carouselNextBtn.addEventListener('click', (event) => {
        event.stopPropagation(); // 阻止事件冒泡
        if (currentCarouselIndex < imageCarouselData.length - 1) {
            currentCarouselIndex++;
            updateCarouselDisplay();
        }
    });

    // 新增：安装向导按钮
    document.getElementById('btn-full-setup').addEventListener('click', () => {
        document.querySelector('.wizard-options').style.display = 'none'; // 隐藏选项
        window.pywebview.api.start_full_setup();
    });

    document.getElementById('btn-phased-setup').addEventListener('click', () => {
        document.querySelector('.wizard-options').style.display = 'none'; // 隐藏选项
        window.pywebview.api.start_phased_setup();
    });

}
// --- 渲染函数 ---
function renderAll(data) {
    // 【逻辑优化】不再在这里调用 renderSettings，因为它需要工作区上下文。
    // 将 settings 数据传递给 renderWorkspaces，由它进一步传递给 loadWorkspaceState。
    if (data.workspaces) {
        renderWorkspaces(data.workspaces.items, data.workspaces.active_id, data.settings);
    }

    // 历史记录的顺序不影响
    if (data.history) {
        renderHistory(data.history);
    }
}

function renderWorkspaces(items, activeId, settings) {
    // 1. 添加 settings 参数
    if (Object.keys(items).length === 0) {
        if (!ui.workspaceList) {
            console.error("[FATAL] 在 renderWorkspaces 中，ui.workspaceList 为 undefined 或 null！无法设置 innerHTML。");
            return;
        }
        ui.workspaceList.innerHTML = `<div class="empty-state">
                                        <p>还没有工作区</p>
                                        <span>点击 “新增” 来创建一个吧</span>
                                      </div>`;
        updateButtonStates();
        return;
    }

    if (!ui.workspaceList) {
        console.error("[FATAL] 在 renderWorkspaces 中，ui.workspaceList 为 undefined 或 null！无法设置 innerHTML。");
        return;
    }
    ui.workspaceList.innerHTML = '';
    const template = document.getElementById('workspace-item-template');

    // 2. 使用一个合并后的、正确的循环
    Object.values(items).forEach((ws, index) => {
        const clone = template.content.cloneNode(true);
        const itemEl = clone.querySelector('.list-item');
        itemEl.dataset.id = ws.id;

        // --- 分配颜色 ---
        const color = ui.colorPalette[index % ui.colorPalette.length];
        itemEl.style.setProperty('--item-color', color);

        // --- 渲染名称和'新'标记 ---
        itemEl.querySelector('.item-name').textContent = ws.name;
        const indicatorsEl = itemEl.querySelector('.indicators');
        indicatorsEl.innerHTML = '';
        if (ws.has_new_result) {
            const newIndicator = document.createElement('span');
            newIndicator.className = 'indicator new-result';
            newIndicator.textContent = '新';
            indicatorsEl.appendChild(newIndicator);
        }

        // --- 渲染状态指示器 ---
        const statusIndicatorsEl = itemEl.querySelector('.workspace-status-indicators');
        statusIndicatorsEl.innerHTML = '';
        const statusMap = {
            has_plot: '图片', has_data_file: '文件', has_code: '代码',
            has_console_output: '代码输出', has_analysis: '文字分析'
        };
        if (ws.status_flags) {
            for (const key in statusMap) {
                const indicatorContainer = document.createElement('div');
                indicatorContainer.className = 'status-indicator-item';
                const statusText = document.createElement('span');
                statusText.className = 'status-text';
                statusText.textContent = statusMap[key];
                const statusBlock = document.createElement('div');
                statusBlock.className = 'status-block';
                indicatorContainer.appendChild(statusText);
                indicatorContainer.appendChild(statusBlock);
                const isPresent = ws.status_flags[key];
                indicatorContainer.classList.add(isPresent ? 'status-present' : 'status-absent');
                statusIndicatorsEl.appendChild(indicatorContainer);
            }
        }

        // --- 获取进度条和日志的DOM元素引用 ---
        const progressContainer = itemEl.querySelector('.workspace-progress-bar-container');
        const progressFill = itemEl.querySelector('.progress-bar-fill');
        const progressText = itemEl.querySelector('.progress-bar-text');
        const logContent = itemEl.querySelector('.log-content');

        // 渲染进度条
        if (ws.progress && ws.progress.visible) {
            progressContainer.style.display = 'flex';
            progressFill.style.width = `${ws.progress.value}%`;
            progressText.textContent = ws.progress.text;
        } else {
            progressContainer.style.display = 'none';
        }

        // 渲染日志
        logContent.innerHTML = '';
        if (ws.status_log && ws.status_log.length > 0) {
            ws.status_log.forEach(log => {
                const logEntry = document.createElement('div');
                logEntry.className = 'log-entry';
                if (log.is_error) { logEntry.classList.add('error'); }
                logEntry.innerHTML = `<span class="log-ts">[${log.timestamp}]</span><span class="log-msg">${log.message}</span>`;
                logContent.appendChild(logEntry);
            });
        } else {
            logContent.innerHTML = '<div class="log-entry"><span>暂无记录</span></div>';
        }

        // 3. 将激活和加载逻辑放在同一个循环内
        if (ws.id === activeId) {
            itemEl.classList.add('active');
            activeWorkspaceId = ws.id;
            loadWorkspaceState(ws, settings); // <-- settings 现在是正确传递的
            updateUIForCurrentState();
        }

        // 4. 将克隆的节点附加到DOM
        ui.workspaceList.appendChild(clone);
    });

    updateButtonStates();
}

function renderHistory(items) {
    const template = document.getElementById('history-item-template');
    const sortedItems = Object.values(items).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    if (sortedItems.length === 0) {
        ui.historyList.innerHTML = `<div class="empty-state">还没有历史记录。</div>`;
        updateButtonStates();
        return;
    }

    ui.historyList.innerHTML = '';

    sortedItems.forEach((item, index) => {
        const clone = template.content.cloneNode(true);
        const itemEl = clone.querySelector('.list-item');
        itemEl.dataset.id = item.id;

        // --- 分配颜色 ---
        const color = ui.colorPalette[index % ui.colorPalette.length];
        itemEl.style.setProperty('--item-color', color);

        itemEl.querySelector('.item-name').textContent = item.display_name;
        itemEl.querySelector('.item-timestamp').textContent = new Date(item.timestamp).toLocaleString();

        // 使用新的状态指示器容器
        const indicatorsEl = itemEl.querySelector('.history-status-indicators');
        indicatorsEl.innerHTML = ''; // 清空，以防万一

        // 定义状态键到显示文本的映射
        const statusMap = {
            has_plot: '图片',
            has_data_file: '文件',
            has_code: '代码',
            has_console_output: '代码输出', // 新增对代码输出的检查
            has_analysis: '文字分析'
        };

        // 遍历映射，为每个状态创建包含文字和色块的复杂结构
        for (const key in statusMap) {
            // 1. 创建每个状态项的总容器
            const indicatorContainer = document.createElement('div');
            indicatorContainer.className = 'status-indicator-item';

            // 2. 创建状态文字
            const statusText = document.createElement('span');
            statusText.className = 'status-text';
            statusText.textContent = statusMap[key];

            // 3. 创建下方的色块
            const statusBlock = document.createElement('div');
            statusBlock.className = 'status-block';

            // 4. 将文字和色块放入容器
            indicatorContainer.appendChild(statusText);
            indicatorContainer.appendChild(statusBlock);

            // 5. 根据状态是否存在，给总容器添加 'status-present' 或 'status-absent' 类
            const isPresent = item[key];
            indicatorContainer.classList.add(isPresent ? 'status-present' : 'status-absent');

            // 6. 将完整的状态项添加到主指示器区域
            indicatorsEl.appendChild(indicatorContainer);
        }

        // --- 恢复多选UI状态 ---
        // 检查当前项的ID是否在我们的多选集合中
        if (selectedHistoryIds.has(item.id)) {
            // 如果在，则手动恢复其UI为选中状态
            itemEl.classList.add('active'); // 添加高亮
            const checkbox = itemEl.querySelector('.history-select-checkbox');
            if (checkbox) {
                checkbox.checked = true; // 勾选复选框
            }
        }
        // 注意：我们保留了下面的单选高亮逻辑，以防万一在非多选模式下刷新
        else if (item.id === activeHistoryId) {
            itemEl.classList.add('active');
        }

        ui.historyList.appendChild(clone);
    });

    updateButtonStates();
}

function createFormGroup(key, value, type, options = []) {
    let inputHtml;
    const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

    if (type === 'select') {
        inputHtml = `<select id="config-${key}">`;
        options.forEach(opt => {
            inputHtml += `<option value="${opt.value}" ${opt.value === value ? 'selected' : ''}>${opt.text}</option>`;
        });
        inputHtml += `</select>`;
    } else if (type === 'textarea') {
         inputHtml = `<textarea id="config-${key}" rows="4">${value}</textarea>`;
    } else {
        inputHtml = `<input type="${type}" id="config-${key}" value="${value}">`;
    }

    return `
        <div class="form-group">
            <label for="config-${key}">${label}</label>
            ${inputHtml}
        </div>
    `;
}

function renderFilePreviews(target, files) {
    const container = document.getElementById(`${target}-file-previews`);
    if (!container) return;

    container.innerHTML = files.map(file => {
        const removeBtnHtml = `<button class="remove-file-btn" data-target="${target}" data-preview-id="${file.preview_id}" title="移除文件">&times;</button>`;

        if (file.file_type === 'image') {
            return `
                <div class="file-preview-card image-type"
                     data-action="view-image"
                     data-image-src="${file.preview_uri}"
                     title="点击预览: ${file.original_name}">
                    <img src="${file.preview_uri}" alt="${file.original_name}" class="preview-image">
                    ${removeBtnHtml}
                </div>
            `;
        } else {
            return `
                <div class="file-preview-card generic-type"
                     data-action="open-file"
                     data-file-path="${file.full_path}"
                     title="点击打开: ${file.original_name}">
                    <img src="../assets/icons/generic_file_icon.png" class="file-icon" alt="file icon">
                    <div class="file-details">
                        <span class="file-name">${file.original_name}</span>
                        <span class="file-meta">${file.file_ext}, ${file.file_size_str}</span>
                    </div>
                    ${removeBtnHtml}
                </div>
            `;
        }
    }).join('');
}

function loadWorkspaceState(workspace, settings) {
    // 【核心修复】将 renderSettings 提前
    if (settings && workspace) {
        renderSettings(settings, workspace);
    }

    currentWorkspaceData = workspace;
    ui.dataInputText.value = workspace.data_input_text || '';
    ui.promptInputText.value = workspace.prompt_input_text || '';
    ui.agentModeCheckbox.checked = workspace.agent_mode_enabled;

    // --- 加载四个输出区域的内容 ---
    // 1. 加载代码
    initializeCodeMirror(workspace.last_generated_code || '# 尚未生成任何代码.');

    // 2. 加载控制台输出
    ui.consoleOutputTextarea.value = workspace.console_output || '';

    // 3. 加载文字分析 (HTML格式)
    ui.analysisOutput.innerHTML = workspace.analysis_text || '<div class="output-placeholder">此处将显示文字分析...</div>';
    // 渲染可能存在的数学公式
    renderAllMath();

    renderFilePreviews('data', workspace.managed_files.data);
    renderFilePreviews('prompt', workspace.managed_files.prompt);

    if (workspace.clear_options) {
        ui.clearOptionCheckboxes.forEach(checkbox => {
            checkbox.checked = workspace.clear_options[checkbox.value] || false;
        });
    }

    // 渲染输出文件列表和主图表
    window.app.renderOutputs(workspace.id, workspace.generated_outputs);
}

// --- 状态同步 ---
async function saveCurrentWorkspaceState() {
    if (!activeWorkspaceId) return;

    // 获取清除选项的状态
    const clearOptions = {};
    ui.clearOptionCheckboxes.forEach(checkbox => {
        clearOptions[checkbox.value] = checkbox.checked;
    });

    const currentCode = codeMirrorInstance ? codeMirrorInstance.getValue() : '';

    const state = {
        data_input_text: ui.dataInputText.value,
        prompt_input_text: ui.promptInputText.value,
        last_generated_code: currentCode,
        agent_mode_enabled: ui.agentModeCheckbox.checked,
        clear_options: clearOptions,
    };
    try {
        await window.pywebview.api.save_current_workspace_state(activeWorkspaceId, state);
    } catch (e) {
        console.error("Failed to save workspace state:", e);
    }
}

// 处理清除按钮点击的函数
async function handleClearOutput() {
    if (!activeWorkspaceId) {
        showAlert("请先选择一个工作区。", "warning");
        return;
    }

    const targetsToClear = Array.from(ui.clearOptionCheckboxes)
        .filter(cb => cb.checked)
        .map(cb => cb.value);

    if (targetsToClear.length > 0) {
        await window.pywebview.api.clear_workspace_outputs(activeWorkspaceId, targetsToClear);
    } else {
        showAlert("没有选择任何要清除的项。", "info");
    }
}

// --- 事件处理器 ---
// 用于处理左侧配置表单的变化
async function handleWorkspaceConfigChange(event) { // 重新引入 event 参数
    if (!activeWorkspaceId) return;

    // 根据当前激活的类型，从对应的输入框收集数据
    let apiUrl, apiKey, modelName;
    if (currentApiType === 'external') {
        apiUrl = document.getElementById('config-external_api_url').value;
        apiKey = document.getElementById('config-external_api_key').value;
        modelName = document.getElementById('config-external_model_name').value;
    } else {
        apiUrl = document.getElementById('config-local_api_url').value;
        apiKey = document.getElementById('config-local_api_key').value;
        modelName = document.getElementById('config-local_model_name').value;
    }

    const configData = {
        api_type: currentApiType,
        api_url: apiUrl,
        api_key: apiKey,
        model_name: modelName,
        system_prompt: document.getElementById('config-system_prompt').value,
        plotting_font: document.getElementById('config-plotting_font').value,
        max_retries: parseInt(document.getElementById('config-max_retries').value, 10) || 3,
        max_agent_retries: parseInt(document.getElementById('config-max_agent_retries').value, 10) || 3
    };

    // 调用后端API保存配置 (这个逻辑依然需要)
    await window.pywebview.api.save_workspace_config(activeWorkspaceId, configData);
    window.app.updateStatus("当前工作区配置已更新。", false);

    // --- 【新增】如果改变的是字体选择框，则立即更新代码 ---
    // 检查事件源是否是字体选择框，并且代码编辑器实例存在
    if (event && event.target.id === 'config-plotting_font' && codeMirrorInstance) {
        const newFontName = event.target.value;
        const currentCode = codeMirrorInstance.getValue();

        // 如果代码框为空，则不执行替换
        if (!currentCode || currentCode.trim() === '' || currentCode.trim() === '# 尚未生成任何代码.') {
            return;
        }

        // 调用后端API来替换代码中的字体路径
        const result = await window.pywebview.api.update_code_with_font(currentCode, newFontName);

        if (result.success) {
            // 如果成功，用新代码更新编辑器
            codeMirrorInstance.setValue(result.new_code);
            window.app.updateStatus(`代码中的字体已更新为 ${newFontName}。`);
        } else {
            // 如果失败（例如代码中没有找到font_path），在控制台打印日志
            console.warn("Update font in code failed:", result.error);
        }
    }
}

async function handleGeneration() {
    if (!activeWorkspaceId) {
        showAlert("请先选择或创建一个工作区。", "warning");
        return;
    }

    // 保存当前工作区的输入状态，因为后端清空时不会清除输入
    await saveCurrentWorkspaceState();

    // 直接开始生成，后端会负责清空输出
    window.pywebview.api.start_generation(activeWorkspaceId);
}

async function handleGenerateAnalysis() {
    if (!activeWorkspaceId) {
        showAlert("请先选择或创建一个工作区。", "warning");
        return;
    }
    // 文字分析是基于已有结果的，不需要保存当前输入状态，也不需要清空
    window.pywebview.api.start_text_analysis(activeWorkspaceId);
}

async function handleRunCode() {
    if (!activeWorkspaceId) {
        showAlert("请先选择一个工作区。", "warning");
        return;
    }
    if (!codeMirrorInstance) {
    showAlert("代码编辑器未初始化，无法执行。", "error");
    return;
    }
    const code = codeMirrorInstance.getValue();
    window.pywebview.api.run_code(activeWorkspaceId, code);
}

function handleSaveOutput() {
    if (!activeWorkspaceId) {
        showAlert("请先选择一个工作区。", "warning");
        return;
    }
    window.pywebview.api.save_all_outputs(activeWorkspaceId);
}

async function handleSaveConfig() {
    // 这是一个全局保存操作，所以我们弹出一个确认框
    if (!confirm("您确定要将当前活动工作区的配置保存为全局默认设置吗？\n\n这将会覆盖 config.json 文件，影响未来新建的所有工作区。")) {
        return;
    }

    // 1. 收集所有可能的配置项的值
    const newConfigFlat = {
        // API 类型
        api_type: currentApiType,
        // External API
        external_api_url: document.getElementById('config-external_api_url').value,
        external_api_key: document.getElementById('config-external_api_key').value,
        external_model_name: document.getElementById('config-external_model_name').value,
        // Local API
        local_api_url: document.getElementById('config-local_api_url').value,
        local_api_key: document.getElementById('config-local_api_key').value,
        local_model_name: document.getElementById('config-local_model_name').value,
        // Common settings
        system_prompt: document.getElementById('config-system_prompt').value,
        plotting_font: document.getElementById('config-plotting_font').value
    };

    // 2. 收集应用设置
    const newSettings = {
         max_retries: parseInt(document.getElementById('config-max_retries').value, 10) || 3,
         max_agent_retries: parseInt(document.getElementById('config-max_agent_retries').value, 10) || 3
         // 注意：自动清理设置由其自己的事件处理器 handleAutoCleanupSettingsChange 独立保存，无需在此处收集
    };

    // 3. 调用后端 API
    try {
        const result = await window.pywebview.api.save_config(newConfigFlat, newSettings);
        // 后端现在会通过 showAlert 显示成功信息，前端只需处理错误
        if (result.status !== 'success') {
             window.app.showAlert(result.message, 'error');
        }
    } catch (e) {
        console.error("Failed to save global config:", e);
        window.app.showAlert(`保存全局配置时出错: ${e.message}`, 'error');
    }
}
async function handleAddWorkspace() {
    const name = prompt("输入新工作区的名称:", `工作区 ${ui.workspaceList.children.length + 1}`);
    if (name) {
        await window.pywebview.api.add_workspace(name);
    }
}

async function handleDeleteWorkspace() {
    if (!activeWorkspaceId) {
        showAlert("请先选择一个工作区进行删除。", "warning");
        return;
    }
    if (confirm("您确定要永久删除此工作区吗？\n所有相关数据也将被移除。")) {
        await window.pywebview.api.delete_workspace(activeWorkspaceId);
        activeWorkspaceId = null;
        updateButtonStates();
    }
}

async function handleLoadHistory() {
    if (!activeHistoryId) {
        showAlert("请选择一条历史记录进行加载。", "warning");
        return;
    }
    if (!activeWorkspaceId) {
        showAlert("请先选择一个目标工作区。", "warning");
        return;
    }
    if (confirm("是否读取此历史记录？\n\n这将覆盖当前活动工作区的所有内容。")) {
       await window.pywebview.api.load_history_to_workspace(activeHistoryId, activeWorkspaceId);
    }
}

async function handleListSelection(event, type) {
    const item = event.target.closest('.list-item');
    if (!item) return;

    // 如果点击的是编辑控件或复选框，则不触发选择逻辑
    if (event.target.closest('.history-item-edit-controls, .history-item-checkbox, .item-name-edit, .btn-preview')) {
        return;
    }

    const id = item.dataset.id;

    if (type === 'workspace') {
        if (id !== activeWorkspaceId) {
            await saveCurrentWorkspaceState();
            window.pywebview.api.switch_workspace(id);
        }
    } else if (type === 'history') {
        // 多选逻辑
        if (isMultiSelectMode || event.ctrlKey) {
            if (!isMultiSelectMode) {
                // 关键：如果是Ctrl首次点击, 自动进入多选模式
                isMultiSelectMode = true;
                updateMultiSelectUI(); // 调用新的UI更新函数，它会处理图标和面板样式

                // 把之前单选状态下激活的项，也自动加入到多选集合中
                if (activeHistoryId) {
                   selectedHistoryIds.add(activeHistoryId);
                   const activeEl = ui.historyList.querySelector(`.list-item[data-id="${activeHistoryId}"]`);
                   // 确保其UI(复选框)也同步更新
                   if(activeEl) activeEl.querySelector('.history-select-checkbox').checked = true;
                }
            }
            // 无论之前是否在多选模式，都切换当前点击项的选择状态
            toggleHistorySelection(id);
        } else {
            // 单选逻辑 (保持不变)
            activeHistoryId = id;
            selectedHistoryIds.clear();
            selectedHistoryIds.add(id);
            // 更新UI高亮
            ui.historyList.querySelectorAll('.list-item.active').forEach(el => el.classList.remove('active'));
            item.classList.add('active');
            // 确保所有复选框都是未选中状态
            ui.historyList.querySelectorAll('.history-select-checkbox').forEach(cb => cb.checked = false);
        }
        updateButtonStates();
    }
}

function handleTabSwitch(event) {
    const targetTab = event.target.dataset.tab;
    ui.tabBtns.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === targetTab));
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.toggle('active', pane.id === `${targetTab}-tab`);
    });

    // 当切换到代码标签页时，刷新CodeMirror以确保其正确渲染和计算滚动条
    if (targetTab === 'code' && codeMirrorInstance) {
        // 使用setTimeout确保刷新操作在DOM完全可见后执行
        setTimeout(() => {
            codeMirrorInstance.refresh();
        }, 0);
    }
}

function handleSidebarTabSwitch(event) {
     const targetPanel = event.target.dataset.sidebarTab;
    ui.sidebarTabBtns.forEach(btn => btn.classList.toggle('active', btn.dataset.sidebarTab === targetPanel));
    document.querySelectorAll('.sidebar-panel').forEach(panel => {
        panel.classList.toggle('active', panel.id === `${targetPanel}-panel`);
    });
}

// --- 多选模式切换 ---
function updateMultiSelectUI() {
    // 更新图标
    ui.multiSelectIcon.src = `../assets/icons/${isMultiSelectMode ? 'check-circle' : 'circle'}.png`;

    // --- 切换按钮的 .active 类 ---
    ui.toggleMultiSelectBtn.classList.toggle('active', isMultiSelectMode);

    // 更新面板样式
    ui.historyPanel.classList.toggle('multi-select-mode', isMultiSelectMode);

    // 退出多选模式时的清理逻辑 (保持不变)
    if (!isMultiSelectMode) {
        selectedHistoryIds.clear();
        ui.historyList.querySelectorAll('.history-select-checkbox').forEach(cb => cb.checked = false);
        if(activeHistoryId) selectedHistoryIds.add(activeHistoryId);
    }
    updateButtonStates();
}

// --- 切换单个历史记录项的选择状态 ---
function toggleHistorySelection(id) {
    const itemEl = ui.historyList.querySelector(`.list-item[data-id="${id}"]`);
    if (!itemEl) return;
    const checkbox = itemEl.querySelector('.history-select-checkbox');

    if (selectedHistoryIds.has(id)) {
        selectedHistoryIds.delete(id);
        checkbox.checked = false;
        itemEl.classList.remove('active');
        // 如果取消的是当前活动项，则清空activeHistoryId
        if(id === activeHistoryId) activeHistoryId = null;
    } else {
        selectedHistoryIds.add(id);
        checkbox.checked = true;
        itemEl.classList.add('active');
        // 将最后点击的项设为活动项 (用于加载)
        activeHistoryId = id;
    }
    updateButtonStates();
}

// --- 处理复选框变化的辅助函数 ---
function handleHistoryCheckboxChange(event) {
    const itemEl = event.target.closest('.list-item');
    if (itemEl) {
        toggleHistorySelection(itemEl.dataset.id);
    }
}

// --- 更新按钮状态的逻辑 ---
function updateButtonStates() {
    const hasActiveWorkspace = !!activeWorkspaceId;
    const selectionCount = selectedHistoryIds.size;

    ui.deleteWorkspaceBtn.disabled = !hasActiveWorkspace;

    // 加载按钮: 仅当选中一项时可用
    ui.loadHistoryBtn.disabled = selectionCount !== 1;
    // 删除按钮: 选中至少一项时可用
    ui.deleteHistoryBtn.disabled = selectionCount === 0;
    // 重命名按钮: 选中至少一项时可用
    ui.renameHistoryBtn.disabled = selectionCount === 0;
}

function updateUIForCurrentState() {
    if (!activeWorkspaceId) return; // 如果没有活动工作区，则不执行任何操作

    const isAnyWorkspaceRunning = runningWorkspaces.size > 0;
    const isCurrentWorkspaceRunning = runningWorkspaces.has(activeWorkspaceId);

    // 1. 特殊逻辑：只要有任何工作区在运行，就锁定“保存为全局配置”按钮
    // 在您的代码中，这个按钮的ID是 'save-config-btn'
    if (ui.saveConfigBtn) { // 确保元素已缓存
        ui.saveConfigBtn.disabled = isAnyWorkspaceRunning;
    }

    // 2. 锁定/解锁左侧配置区域 (使用我们新添加的ID)
    if (ui.lockableConfigArea) {
        if (isCurrentWorkspaceRunning) {
            ui.lockableConfigArea.classList.add('locked');
        } else {
            ui.lockableConfigArea.classList.remove('locked');
        }
    }

    // 3. 锁定/解锁右侧核心操作按钮
    ui.generateBtn.disabled = isCurrentWorkspaceRunning;
    ui.generateAnalysisBtn.disabled = isCurrentWorkspaceRunning;
    ui.runCodeBtn.disabled = isCurrentWorkspaceRunning;

    // 4. 如果当前工作区没有在运行，则恢复按钮的常规状态检查
    if (!isCurrentWorkspaceRunning) {
        updateButtonStates();
    }
}

// --- 删除历史记录的处理函数 ---
function handleDeleteHistory() {
    if (selectedHistoryIds.size === 0) {
        showAlert("请选择要删除的历史记录。", "warning");
        return;
    }
    if (confirm(`您确定要永久删除选中的 ${selectedHistoryIds.size} 条历史记录吗？`)) {
        // 将Set转换为Array传给后端
        window.pywebview.api.delete_history_item(Array.from(selectedHistoryIds));
        activeHistoryId = null;
        selectedHistoryIds.clear();
        updateButtonStates();
    }
}

// --- 重命名相关处理函数 ---
function handleRenameHistory() {
    if (selectedHistoryIds.size === 0) return;
    selectedHistoryIds.forEach(id => {
        const itemEl = ui.historyList.querySelector(`.list-item[data-id="${id}"]`);
        if (itemEl) {
            itemEl.classList.add('is-editing');
            const nameEl = itemEl.querySelector('.item-name');
            const editEl = itemEl.querySelector('.item-name-edit');

            // --- 核心修复：移除内联style属性 ---
            // 这将允许 main.css 中的 .is-editing 样式生效
            editEl.removeAttribute('style');
            // --- 修复结束 ---

            editEl.value = nameEl.textContent;
            editEl.focus();
        }
    });
}

function handleSaveRename(event) {
    const itemEl = event.target.closest('.list-item');
    const id = itemEl.dataset.id;
    const editEl = itemEl.querySelector('.item-name-edit');
    const newName = editEl.value.trim(); // 使用 trim() 避免前后空格

    // 添加一个简单的验证
    if (!newName) {
        window.app.showAlert("名称不能为空！", "warning");
        editEl.focus();
        return;
    }

    // 调用后端API，并等待返回结果
    window.pywebview.api.rename_history_item(id, newName).then(result => {
        // 检查后端返回的状态是否成功
        if (result && result.status === 'success') {
            // --- 前端接管UI更新 ---

            // 1. 更新显示的标题文本
            const nameEl = itemEl.querySelector('.item-name');
            if (nameEl) {
                nameEl.textContent = newName;
            }

            // 2. 将这一个项目退出编辑模式
            itemEl.classList.remove('is-editing');

            // 3. 【重要】恢复输入框的隐藏样式，以防万一
            editEl.setAttribute('style', 'display: none;');

            // 4. (可选) 更新状态栏提示
            window.app.updateStatus(`项目已重命名为 "${newName}"。`, false);

        } else {
            // 如果后端返回失败，显示错误提示 (后端通常已经显示了，这里是备用)
            window.app.showAlert(result.message || "保存失败，请重试。", "error");
        }
    }).catch(error => {
        // 处理网络或API调用本身的错误
        console.error("Error renaming item:", error);
        window.app.showAlert("与后端通信时发生错误。", "error");
    });
}

function handleCancelRename(event) {
    // 1. 从点击事件的目标（取消按钮）向上找到最近的 .list-item 祖先元素
    const itemEl = event.target.closest('.list-item');

    // 2. 如果找到了该元素，就移除 'is-editing' 类，让CSS隐藏按钮和标题
    if (itemEl) {
        itemEl.classList.remove('is-editing');

        // 3. 【核心修复】找到输入框并将其内联样式恢复，以确保它被彻底隐藏
        const editEl = itemEl.querySelector('.item-name-edit');
        if (editEl) {
            // 这会将 <input ... style="display: none;"> 加回去
            editEl.setAttribute('style', 'display: none;');
        }
    }
}

// --- 自动清理相关函数 ---
function renderAutoCleanupOptions(settings) {
    const panel = ui.cleanupOptionsPanel;
    const options = ["一天内", "三天内", "一周内", "一个月内", "自定义"];
    let html = '';

    options.forEach(opt => {
        const isChecked = settings.cleanup_period === opt;
        html += `
            <label class="circular-checkbox">
                <input type="radio" name="cleanup-options" value="${opt}" ${isChecked ? 'checked' : ''}>
                <span class="checkmark"></span>
                ${opt}
            </label>
        `;
    });

    // 添加自定义输入行
    html += `
        <div class="cleanup-custom-row">
             <input type="number" id="cleanup-custom-days" min="1" value="${settings.cleanup_custom_days || 30}" style="margin-left: 25px;">
             <span>天</span>
        </div>`;

    panel.innerHTML = html;

    // 为新创建的元素绑定事件
    panel.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', handleAutoCleanupSettingsChange);
    });
}

function handleAutoCleanupSettingsChange() {
    const selectedRadio = ui.cleanupOptionsPanel.querySelector('input[name="cleanup-options"]:checked');
    const isEnabled = ui.autoCleanupIcon.src.includes('check-circle.png'); // 从图标状态读取

    const settings = {
        auto_cleanup_enabled: isEnabled, // 使用新方式获取的值
        cleanup_period: selectedRadio ? selectedRadio.value : '一个月内',
        cleanup_custom_days: parseInt(document.getElementById('cleanup-custom-days').value, 10) || 30
    };
    window.pywebview.api.save_config({}, settings);
    window.app.updateStatus("自动清理设置已更新。", false);
}

// 在renderSettings中调用renderAutoCleanupOptions
function renderSettings(settings, workspace) {
    // 这个函数现在是动态渲染的核心
    if (!workspace) return; // 需要工作区数据来决定初始状态

    const modelFormContainer = ui.modelSettingsForm;
    modelFormContainer.innerHTML = ''; // 清空

    currentApiType = workspace.api_type || 'external';

    // 1. 创建可点击的标题头
    const header = document.createElement('div');
    header.id = 'model-config-header'; // 给ID方便事件绑定
    header.className = 'titled-section-header';
    header.innerHTML = `<img src="../assets/icons/settings.png" alt="icon"><h3 id="model-config-title"></h3>`;
    modelFormContainer.appendChild(header);

    // 2. 创建不同API类型的表单容器
    const externalFields = document.createElement('div');
    externalFields.id = 'external-api-fields';
    const localFields = document.createElement('div');
    localFields.id = 'local-api-fields';

    // 3. 填充表单内容
    const externalConfig = workspace.model_config.external_api || {};
    const localConfig = workspace.model_config.local_api || {};

    externalFields.innerHTML = `
        ${createFormGroup('external_api_key', externalConfig.api_key || '', 'password', [], 'API Key')}
        ${createFormGroup('external_api_url', externalConfig.base_url || '', 'text', [], 'API URL')}
        ${createFormGroup('external_model_name', externalConfig.model || '', 'text', [], 'Model Name')}
    `;
    localFields.innerHTML = `
        ${createFormGroup('local_api_url', localConfig.base_url || '', 'text', [], 'API URL (例如: http://localhost:1234/v1)')}
        ${createFormGroup('local_api_key', localConfig.api_key || '', 'text', [], 'API Key (通常为 "not-needed")')}
        ${createFormGroup('local_model_name', localConfig.model || '', 'text', [], 'Model Name (例如: "local-model")')}
    `;

    modelFormContainer.appendChild(externalFields);
    modelFormContainer.appendChild(localFields);

    // 4. 添加通用字段 (System Prompt)
    const commonFields = document.createElement('div');
    commonFields.innerHTML = createFormGroup('system_prompt', workspace.model_config.system_prompt || '', 'textarea', [], 'System Prompt');
    modelFormContainer.appendChild(commonFields);

    // 5. 添加测试按钮和状态指示器
    const testSection = document.createElement('div');
    testSection.style.marginTop = '15px';
    testSection.innerHTML = `
        <div class="model-test-container">
            <button id="test-llm-btn" class="btn-modern btn-purple">测试当前大模型状态</button>
            <div id="llm-status-indicator" class="status-idle">
                <div class="status-dot"></div>
                <span class="status-text">待测试</span>
            </div>
        </div>
    `;
    modelFormContainer.appendChild(testSection);

    // 6. 渲染字体和其他应用设置 (这部分逻辑可以复用)
    ui.fontSettingsForm.innerHTML = createFormGroup('plotting_font', workspace.font_config.name, 'select', settings.font_options, 'Plotting Font');

    const appSettingsContainer = document.createElement('div');
    appSettingsContainer.innerHTML = `
        <div class="titled-section-header header-cobalt-blue" style="margin-top: 20px;">
            <img src="../assets/icons/sliders.png" alt="icon"><h3>应用设置</h3>
        </div>
        ${createFormGroup('max_retries', workspace.model_config.max_retries, 'number', [], '纠错次数上限')}
        ${createFormGroup('max_agent_retries', workspace.model_config.max_agent_retries, 'number', [], '评估次数上限')}
    `;
    modelFormContainer.appendChild(appSettingsContainer);

    // 7. 绑定事件
    document.getElementById('test-llm-btn').addEventListener('click', () => {
        if (activeWorkspaceId) {
            window.pywebview.api.test_llm_connection(activeWorkspaceId);
        }
    });

    header.addEventListener('click', toggleApiType);

    // 8. 初始化UI状态
    updateApiTypeUI();

    // --- 【核心修复】在这里调用函数，渲染自动清理面板的内容 ---
    // 这个函数会使用传入的 `settings` 对象来决定哪个选项应该被默认选中。
    renderAutoCleanupOptions(settings);
    // --- 修复结束 ---
}

// 新增：切换API类型的函数
function toggleApiType() {
    currentApiType = (currentApiType === 'external') ? 'local' : 'external';
    updateApiTypeUI();
    // 切换后立即保存状态到工作区
    handleWorkspaceConfigChange();
}

// 新增：根据 currentApiType 更新UI的函数
function updateApiTypeUI() {
    const header = document.getElementById('model-config-header');
    const title = document.getElementById('model-config-title');
    const externalFields = document.getElementById('external-api-fields');
    const localFields = document.getElementById('local-api-fields');

    if (currentApiType === 'external') {
        title.textContent = '模型配置 (外源URL)';
        header.classList.remove('header-light-red');
        header.classList.add('header-light-blue');
        externalFields.classList.remove('form-group-hidden');
        localFields.classList.add('form-group-hidden');
    } else {
        title.textContent = '模型配置 (本地部署)';
        header.classList.remove('header-light-blue');
        header.classList.add('header-light-red');
        externalFields.classList.add('form-group-hidden');
        localFields.classList.remove('form-group-hidden');
    }
}

// 新增：一个更通用的创建表单组的函数，可以自定义label
function createFormGroup(key, value, type, options = [], labelText) {
    let inputHtml;
    const label = labelText || key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

    if (type === 'select') {
        inputHtml = `<select id="config-${key}">`;
        options.forEach(opt => {
            inputHtml += `<option value="${opt.value}" ${opt.value === value ? 'selected' : ''}>${opt.text}</option>`;
        });
        inputHtml += `</select>`;
    } else if (type === 'textarea') {
         inputHtml = `<textarea id="config-${key}" rows="4">${value}</textarea>`;
    } else {
        inputHtml = `<input type="${type}" id="config-${key}" value="${value}">`;
    }

    return `
        <div class="form-group">
            <label for="config-${key}">${label}</label>
            ${inputHtml}
        </div>
    `;
}

function updateCarouselDisplay() {
    if (imageCarouselData.length === 0) return;

    // 1. 获取当前要显示的图片数据对象
    const currentImage = imageCarouselData[currentCarouselIndex];
    if (!currentImage || !currentImage.base64) {
        // 数据异常处理
        window.app.displayPlot(activeWorkspaceId, null);
        return;
    }

    // 2. 更新主预览图
    window.app.displayPlot(activeWorkspaceId, currentImage.base64);

    // 3. 更新计数器
    ui.carouselCounter.textContent = `${currentCarouselIndex + 1} / ${imageCarouselData.length}`;

    // 4. 更新按钮的禁用状态
    ui.carouselPrevBtn.disabled = currentCarouselIndex === 0;
    ui.carouselNextBtn.disabled = currentCarouselIndex === imageCarouselData.length - 1;

    // 5. 更新主预览图的可点击路径，以便大图预览功能始终指向当前显示的图片
    ui.plotOutput.dataset.filePath = currentImage.final_path;
}

// 【新增】KaTeX 渲染函数 (直接从 Navigator 项目迁移)
function renderAllMath() {
    // 选择所有尚未被渲染的 .math-placeholder 元素
    const mathElements = document.querySelectorAll('.math-placeholder:not([data-rendered])');

    mathElements.forEach(function(element) {
        const texSource = element.textContent;
        let cleanTex = '';
        let isDisplayMode = false;

        if (texSource.startsWith('$$') && texSource.endsWith('$$')) {
            cleanTex = texSource.slice(2, -2).trim();
            isDisplayMode = true;
        } else if (texSource.startsWith('\\[') && texSource.endsWith('\\]')) {
            cleanTex = texSource.slice(2, -2).trim();
            isDisplayMode = true;
        } else if (texSource.startsWith('$') && texSource.endsWith('$')) {
            cleanTex = texSource.slice(1, -1).trim();
            isDisplayMode = false;
        } else if (texSource.startsWith('\\(') && texSource.endsWith('\\)')) {
            cleanTex = texSource.slice(2, -2).trim();
            isDisplayMode = false;
        } else {
            return;
        }

        try {
            katex.render(cleanTex, element, {
                throwOnError: false,
                displayMode: isDisplayMode
            });
            element.setAttribute('data-rendered', 'true');
        } catch (e) {
            element.textContent = 'KaTeX Error: ' + e.message;
            console.error("KaTeX 渲染时发生错误:", e);
        }
    });
}

// 重构后的函数：初始化CodeMirror并构建符合Navigator风格的完整DOM结构
function initializeCodeMirror(code = '') {
    // 如果实例已存在，只需更新内容
    if (codeMirrorInstance) {
        codeMirrorInstance.setValue(code);
        // 确保编辑器尺寸在tab切换后能正确刷新
        setTimeout(() => codeMirrorInstance.refresh(), 1);
        return;
    }

    // --- 首次创建 ---

    // 1. 清空主容器
    ui.codeOutputContainer.innerHTML = '';

    // 2. 创建我们在CSS中定义的完整结构
    const container = document.createElement('div');
    container.className = 'code-block-container';

    const header = document.createElement('div');
    header.className = 'code-block-header';
    header.innerHTML = `
        <span class="code-lang-name">python</span>
        <div class="code-actions">
            <button class="code-toolbar-button" id="dynamic-copy-code-btn" title="复制代码">
                <img src="../assets/icons/copy_icon.png" alt="Copy"> 复制代码
            </button>
            <button class="code-toolbar-button" id="dynamic-copy-md-btn" title="以Markdown格式复制">
                <img src="../assets/icons/clipboard.png" alt="Copy MD"> 复制MD
            </button>
        </div>
    `;

    // CodeMirror 需要一个直接的挂载点，并为其添加一个类名以便于样式控制
    const editorWrapper = document.createElement('div');
    editorWrapper.className = 'code-block-editor-wrapper';

    // 3. 组装DOM
    container.appendChild(header);
    container.appendChild(editorWrapper);
    ui.codeOutputContainer.appendChild(container);

    // 4. 在指定挂载点初始化 CodeMirror
    codeMirrorInstance = CodeMirror(editorWrapper, {
        value: code,
        mode: 'python',
        theme: 'solarized light',
        lineNumbers: true,
        lineWrapping: true,
        indentUnit: 4,
        smartIndent: true,
    });

    // 确保编辑器尺寸正确
    setTimeout(() => codeMirrorInstance.refresh(), 1);

    // 5. 为动态创建的按钮绑定事件
    header.querySelector('#dynamic-copy-code-btn').addEventListener('click', () => {
        if (!codeMirrorInstance) return;
        navigator.clipboard.writeText(codeMirrorInstance.getValue());
        window.app.showAlert('代码已复制!', 'info');
    });

    header.querySelector('#dynamic-copy-md-btn').addEventListener('click', () => {
        if (!codeMirrorInstance) return;
        const mdText = "```python\n" + codeMirrorInstance.getValue() + "\n```";
        navigator.clipboard.writeText(mdText);
        window.app.showAlert('Markdown代码已复制!', 'info');
    });
}