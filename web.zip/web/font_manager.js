const fontListEl = document.getElementById('font-list');
const toggleDeleteBtn = document.getElementById('toggle-delete-mode-btn');
const toggleDownloadBtn = document.getElementById('toggle-download-btn');
const downloadSection = document.getElementById('download-section');
// 注意：以下是之前代码中可能存在的引用错误，我们现在统一
const fontUrlInput = document.getElementById('font-url-input'); // 确保使用这个ID
const downloadBtn = document.getElementById('download-btn');
const downloadStatusEl = document.getElementById('download-status');

// 新增：定义多彩边框的颜色池
const colorPalette = ['#F5C578', '#82A5D1', '#97B99C', '#D16D66'];

// --- Global Functions for Python to call ---
window.refreshFontList = async function() {
    // 1. 调用Python后端API，获取返回结果对象
    const result = await pywebview.api.get_font_list();

    // 2. 检查返回结果是否成功，并从中提取出真正的字体列表数组
    if (result && result.status === 'success') {
        // 3. 正确地将 result.installed_fonts 数组传递给渲染函数
        renderFontList(result.installed_fonts);
    } else {
        // 4. 如果获取失败，在控制台和弹窗中给出明确提示
        const errorMessage = result ? result.message : "未知错误";
        console.error("获取字体列表失败:", errorMessage);
        alert("获取字体列表失败: " + errorMessage);
    }
};

window.updateDownloadStatus = function(message, isError) {
    downloadStatusEl.textContent = message;
    downloadStatusEl.className = isError ? 'error' : '';
    if (message.includes('成功') || message.includes('失败')) {
        downloadBtn.disabled = false;
    }
};

// --- Helper Functions ---
function renderFontList(fontFiles) {
    fontListEl.innerHTML = '';

    if (!fontFiles || fontFiles.length === 0) {
        fontListEl.innerHTML = '<li class="empty-message">未找到任何字体文件。</li>';
        // (可选) 为空消息添加样式
        const style = document.createElement('style');
        style.innerHTML = `.empty-message {
            background: transparent !important;
            box-shadow: none !important;
            cursor: default !important;
            color: var(--secondary-text-color);
            border: none !important;
        }`;
        document.head.appendChild(style);
        return;
    }

    fontFiles.forEach((font, index) => {
        const li = document.createElement('li');

        // 1. 分配颜色
        const color = colorPalette[index % colorPalette.length];
        li.dataset.color = color; // 将颜色存储在 data-* 属性中

        // --- 核心新增 ---
        // 将颜色应用到 --item-color 变量，供默认状态的辉光边框使用
        li.style.setProperty('--item-color', color);

        const nameSpan = document.createElement('span');
        nameSpan.textContent = font;
        li.appendChild(nameSpan);

        const deleteBtn = document.createElement('button');
        deleteBtn.innerHTML = '&times;'; // 使用 '×' 符号，更美观
        deleteBtn.className = 'font-item-delete-btn';
        deleteBtn.onclick = async (e) => {
            e.stopPropagation(); // 阻止事件冒泡到li的点击事件
            if (confirm(`确定要永久删除字体 '${font}' 吗？`)) {
                const result = await pywebview.api.delete_font(font);
                if (result.status === 'success') {
                    await window.refreshFontList();
                } else {
                    alert(`删除失败: ${result.message}`);
                }
            }
        };
        li.appendChild(deleteBtn);

        fontListEl.appendChild(li);
    });
}

// --- Event Listeners ---
window.addEventListener('pywebviewready', window.refreshFontList);

toggleDeleteBtn.addEventListener('click', () => {
    document.body.classList.toggle('delete-mode');
    if (document.body.classList.contains('delete-mode')) {
        toggleDeleteBtn.textContent = '完成删除';
    } else {
        toggleDeleteBtn.textContent = '删除字体';
    }
});

toggleDownloadBtn.addEventListener('click', () => {
    const isHidden = downloadSection.classList.toggle('hidden');
    toggleDownloadBtn.textContent = isHidden ? '▶ 联网下载字体' : '▼ 联网下载字体';
});


// +++ 修改：重写下载按钮的点击事件，使其更智能 +++
downloadBtn.addEventListener('click', () => {
    const url = fontUrlInput.value.trim();
    if (!url) {
        alert('请输入字体页面或 .zip 文件的链接！');
        return;
    }
    downloadBtn.disabled = true;
    updateDownloadStatus('正在处理链接...', false);
    pywebview.api.start_download(url);
});

fontListEl.addEventListener('click', (e) => {
    const clickedLi = e.target.closest('li');
    if (!clickedLi || clickedLi.classList.contains('empty-message')) return;

    // 如果点击的已经是选中的，则不做任何事
    if (clickedLi.classList.contains('selected')) return;

    // 移除所有其他项的选中状态
    fontListEl.querySelectorAll('li.selected').forEach(li => {
        li.classList.remove('selected');
    });

    // 为被点击的项添加选中状态
    clickedLi.classList.add('selected');

    // JS不再需要手动设置选中颜色了，CSS会通过 .selected 自动处理
});