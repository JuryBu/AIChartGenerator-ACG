// web/preview.js

// --- 步骤 1: 验证JS文件本身是否被执行 ---
console.log("--- [DEBUG preview.js] 文件已加载，脚本开始执行！ ---");


// --- 正确的做法 ---
// 直接在全局作用域监听 'pywebviewready' 事件。
// 这是与 pywebview 通信的黄金法则，可以保证你绝不会错过该事件。
window.addEventListener('pywebviewready', renderPreview);


// -----------------------------------------------------------------------------
// 以下是你编写的渲染逻辑，它们非常棒，无需修改！
// -----------------------------------------------------------------------------


async function renderPreview() {
    console.log("--- [DEBUG preview.js] 'pywebviewready' 事件触发, renderPreview() 函数开始执行 ---");
    try {
        console.log("[DEBUG preview.js] 准备调用 window.pywebview.api.get_preview_data()...");

        const data = await window.pywebview.api.get_preview_data();

        console.log("[DEBUG preview.js] 成功从Python获取到数据!");
        console.log("[DEBUG preview.js] 接收到的数据对象:", data);

        const container = document.getElementById('content-container');
        const loadingIndicator = document.getElementById('loading-indicator');

        if (!container || !loadingIndicator) {
            console.error("[DEBUG preview.js] 错误：无法找到 'content-container' 或 'loading-indicator' 元素。");
            return;
        }

        container.innerHTML = ''; // 清空内容

        // 检查返回的数据是否为空
        if (!data || Object.keys(data).length === 0) {
            container.innerHTML = '<p>没有可供预览的内容。</p>';
            loadingIndicator.style.display = 'none';
            console.log("[DEBUG preview.js] 数据为空，渲染完成。");
            return;
        }

        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                console.log(`[DEBUG preview.js] 正在为 key: "${key}" 创建卡片...`);
                container.appendChild(createPreviewCard(key, data[key]));
            }
        }

        loadingIndicator.style.display = 'none';

        console.log("--- [DEBUG preview.js] 渲染完成，已隐藏加载提示。 ---");

    } catch (e) {
        console.error('渲染预览失败:', e);
        const loadingIndicator = document.getElementById('loading-indicator');
        if (loadingIndicator) {
            loadingIndicator.innerHTML = `<div class="error-message">
                <p><strong>加载预览内容失败！</strong></p>
                <p>请检查Python后端日志和浏览器控制台获取详细错误。</p>
                <p>错误详情: ${e.message}</p>
                <pre>${e.stack}</pre>
            </div>`;
        }
    }
}

function createPreviewCard(rawKey, value) {
    const card = document.createElement('div');
    card.className = 'preview-card';
    const header = document.createElement('div');
    header.className = 'card-header';
    const title = document.createElement('h3');
    const cleanKey = rawKey.replace(/_image_base64|_file_path/g, '');
    title.textContent = cleanKey;
    const body = document.createElement('div');
    body.className = 'card-body';
    if (value === null || value === undefined || String(value).trim() === '') {
        const p = document.createElement('p');
        p.className = 'empty-content';
        p.textContent = '（无内容）';
        body.appendChild(p);
    } else if (rawKey.endsWith('_image_base64')) {
        const img = document.createElement('img');
        img.src = value;
        img.alt = cleanKey;
        body.appendChild(img);
    } else if (rawKey.endsWith('_file_path')) {
        const link = document.createElement('a');
        link.className = 'file-link';
        link.textContent = `在默认应用中打开: ${value.split(/[/\\]/).pop()}`;
        link.href = 'javascript:void(0);';
        link.onclick = () => {
            console.log(`[DEBUG preview.js] 请求打开文件: ${value}`);
            window.pywebview.api.open_file(value);
        };
        body.appendChild(link);
    } else if (typeof value === 'string' && (value.includes('import ') || value.includes('def '))) {
        // 简单判断是否是代码，使用 <pre> 标签
        const pre = document.createElement('pre');
        const code = document.createElement('code');
        code.textContent = value;
        pre.appendChild(code);
        body.appendChild(pre);
    } else if (Array.isArray(value)) {
        const p = document.createElement('p');
        p.textContent = value.length > 0 ? value.join(', ') : '（列表为空）';
        body.appendChild(p);
    } else {
        const p = document.createElement('p');
        p.textContent = String(value);
        body.appendChild(p);
    }
    header.appendChild(title);
    card.appendChild(header);
    card.appendChild(body);
    return card;
}