// web/script.js
console.log("DEBUG: script.js 文件已被加载并开始执行。"); // 【DEBUG】
// 1. 将所有需要被Python调用的函数定义在顶层作用域
// 这样脚本一加载，这些函数就立刻可用了
// 定义一个全局对象来持有DOM元素，避免在函数中重复获取
const ui = {
    chatContainer: null,
    messageInput: null,
    sendBtn: null,
    sendButtonWrapper: null,
    attachFileBtn: null,
    attachImageBtn: null,
    stopGenerationBtn: null, // 修改: 引用新的按钮ID
    filePreviewArea: null,
    fileInput: null,
    imageInput: null,
    customPlaceholder: null,
    loadingOverlay: null,
    progressBar: null,
    runHtmlModal: null,
    runHtmlIframe: null,
    runModalCloseBtn: null,
    copyToast: null
};

let attachedFiles = []; // 存储待发送的 File 对象

// --- 新增: 用于新功能的全局变量 ---
let currentMoreMenu = null;
let isMultiSelectMode = false;
let selectedMessages = new Set(); // 使用 Set 存储选中的消息ID，自动处理重复
let messageDataStore = {}; // 用于存储每条消息的原始内容(纯文本和Markdown)
let currentEditingId = null; // <-- 新增: 跟踪当前正在编辑的消息ID
// --- 结束新增 ---

// --- 【新增】用于菜单悬停逻辑的全局变量 ---
let menuCloseTimer = null; // 用于存放 setTimeout 的 ID
let activeMenuMessageId = null; // 跟踪当前哪个消息的操作栏是激活的
// --- 结束新增 ---

// 【新增】管理当前的引用信息
let currentReplyInfo = {
    type: null, // 'single' or 'multi'
    ids: []
};

// 【新增】DOM 元素引用
let quotePreviewContainer, quotePreviewText, cancelQuoteBtn;

// --- 新增: 用于管理后端初始化状态的全局变量 ---
let isBackendReady = false;
// --- 结束新增 ---

// --- 新增: 用于管理生成状态的全局变量 ---
let isGenerating = false;
let thinkingInterval = null;
let timerInterval = null;
let timerSeconds = 0;
let currentStreamingMessageId = null; // 【新增】用于暂存正在生成的AI消息的唯一ID
// --- 结束新增 ---

// --- Python调用的全局函数 ---

window.setContent = function(html) {
    if (ui.chatContainer) {
        ui.chatContainer.innerHTML = html;
        highlightAllCode();
        enhanceCodeBlocks();
        renderAllMath();
        scrollToBottom();
    }
};

window.appendMessage = function(html) {
    if (ui.chatContainer) {
        ui.chatContainer.insertAdjacentHTML('beforeend', html);
        highlightAllCode();
        enhanceCodeBlocks();
        renderAllMath();
        scrollToBottom();
    }
};

// 新增: Python调用的唯一入口点，处理所有来自后端的事件
window.handlePythonEvent = function(data) {
    switch (data.event) {
        // 处理LLM流式输出的事件
        case 'start':
        case 'chunk':
        case 'end':
        case 'error':
            handleStreamingEvents(data);
            break;

        case 'delete_messages':
            if (data.ids && Array.isArray(data.ids)) {
                data.ids.forEach(id => {
                    const element = document.getElementById(id);
                    if (element) {
                        element.remove();
                    }
                });
                console.log("已从前端移除消息:", data.ids);
            }
            break;

        // --- 【核心新增】 ---
        case 'reindex_messages':
            console.log("收到重新索引指令，开始更新UI...");
            const messages = document.querySelectorAll('.message-wrapper');
            messages.forEach((msg, index) => {
                const oldId = msg.id;
                const newId = `history-msg-${index}`;

                if (oldId !== newId) {
                    // 更新消息存储中的键
                    if (messageDataStore[oldId]) {
                        messageDataStore[newId] = messageDataStore[oldId];
                        delete messageDataStore[oldId];
                    }
                }

                msg.id = newId;
                msg.dataset.index = index;

                // 更新所有内部元素的ID引用
                const checkbox = msg.querySelector('.message-checkbox');
                if(checkbox) checkbox.dataset.messageId = newId;

                // 更新所有操作按钮的 onclick (如果有的话) 或 data-message-id 属性
                const actionButtons = msg.querySelectorAll('[data-message-id]');
                actionButtons.forEach(btn => {
                    btn.dataset.messageId = newId;
                });
            });
            console.log(`重新索引完成。总消息数: ${messages.length}`);
            break;
        // --- 【新增结束】 ---

        // 【新增】处理后端发送的消息内容更新
        case 'update_message_content':
            {
                const { messageId, newHtml, newRawText, newRawMd } = data;
                const messageNode = document.getElementById(messageId);
                if (messageNode) {
                    messageNode.querySelector('.message-content').innerHTML = newHtml;
                    messageDataStore[messageId] = { rawText: newRawText, rawMd: newRawMd };
                    // 重新渲染可能存在的代码块和数学公式
                    highlightAllCode();
                    renderAllMath();
                }
                break;
            }

        // 处理简单的UI指令
        case 'show_alert':
            alert(data.content);
            break;

       // 【新增】处理加载历史记录的事件
        case 'load_history':
            if (data.messages && Array.isArray(data.messages)) {
                loadHistory(data.messages);
            }
            break;

        case 'generation_complete':
            // ...
            console.log("后端确认：生成流程完全结束。");
            updateUIState('idle'); // 确保UI状态被重置为'idle'
            break;

        // --- 【核心新增】 ---
        case 'update_loading_progress':
            if (ui.progressBar) {
                ui.progressBar.style.width = `${data.progress}%`;
            }
            break;

        case 'initialization_complete':
            isBackendReady = true;
            if (ui.loadingOverlay) {
                ui.loadingOverlay.style.opacity = '0';
                // 等待动画结束后再彻底隐藏，防止影响布局
                setTimeout(() => {
                    ui.loadingOverlay.style.display = 'none';
                }, 500);
            }
            break;
        // --- 【新增结束】 ---

        // 未来可以扩展更多事件，如 'delete_dom_element', 'reload_history' 等
        default:
            console.warn("收到了未知的Python事件:", data);
    }
};

// --- JS API (供气泡按钮调用) ---
window.loadHistory = function(messagesData) {
    ui.chatContainer.innerHTML = ''; // 清空现有内容
    // 【核心修改】在 forEach 中获取 index
    messagesData.forEach((msg, index) => {
        // 【核心修改】将 index 添加到 options 对象中传递下去
        const optionsWithIndex = { ...msg.options, index: index };
        createMessageBubble(msg.role, msg.contentHTML, optionsWithIndex);
    });
    // 渲染历史记录中的代码和数学公式
    highlightAllCode();
    enhanceCodeBlocks();
    renderAllMath();
};


// --- 内部辅助函数 (同样可以定义在顶层) ---
// 将原来的 updateChat 逻辑封装到一个新函数中
function handleStreamingEvents(data) {
    const streamingWrapper = document.getElementById('streaming-wrapper');
    if (!streamingWrapper && data.event !== 'error') return;

    const contentDiv = streamingWrapper ? streamingWrapper.querySelector('.message-content') : null;

    switch (data.event) {
        case 'start':
            clearInterval(thinkingInterval);
            clearInterval(timerInterval);
            if (contentDiv) contentDiv.innerHTML = '';
            break;

        case 'chunk':
            if (contentDiv) contentDiv.innerHTML += data.content;
            scrollToBottom();
            break;

        case 'end':
            if (contentDiv) {
                let finalHtmlParts = [];

                // --- 1. 处理RAG源ID，生成文本引用 (逻辑不变) ---
                if (data.rag_source_ids && data.rag_source_ids.length > 0) {
                    console.log("接收到RAG源ID:", data.rag_source_ids);
                    const ragReplyInfo = { type: 'multi', ids: data.rag_source_ids };
                    finalHtmlParts.push(generateReplyPreviewHTML(ragReplyInfo, 'rag'));
                }

                // --- 2. [核心新增] 处理“注意力文件”，生成预览卡片 ---
                if (data.attention_files && data.attention_files.length > 0) {
                    console.log("接收到注意力文件预览数据:", data.attention_files);
                    // 复用现有的附件预览生成函数，它已经足够健壮来处理后端传来的对象
                    const attachmentPreviewHTML = generateAttachmentPreviewHTML(data.attention_files);
                    finalHtmlParts.push(attachmentPreviewHTML);
                }
                // --- [新增结束] ---

                // --- 3. 添加AI回复的主要内容 ---
                finalHtmlParts.push(data.content);

                // --- 4. 组合所有部分并渲染 ---
                contentDiv.innerHTML = finalHtmlParts.join('');

                highlightAllCode();
                enhanceCodeBlocks();
                renderAllMath();
            }
            updateUIState('idle');

            if (streamingWrapper && currentStreamingMessageId) {
                // 【核心新增】: 在恢复ID之前，用收到的最终内容更新数据存储
                if (data.rawText !== undefined && data.rawMd !== undefined) {
                    console.log(`DIAGNOSTIC: Updating messageDataStore for ID ${currentStreamingMessageId} with new content.`);
                    messageDataStore[currentStreamingMessageId] = {
                        rawText: data.rawText,
                        rawMd: data.rawMd
                    };
                }

                // 恢复消息气泡的永久唯一ID (这部分逻辑不变)
                streamingWrapper.id = currentStreamingMessageId;
                currentStreamingMessageId = null; // 清理全局变量
            } else if (streamingWrapper) {
                streamingWrapper.id = '';
            }
            break;

        case 'error':
            if (contentDiv) {
                contentDiv.innerHTML = `<div class="error-message">抱歉，发生错误: ${data.content}</div>`;
            } else {
                // 如果连气泡都没有，就直接alert
                alert(`发生错误: ${data.content}`);
            }
            updateUIState('idle');
            if (streamingWrapper) streamingWrapper.id = '';
            break;
    }
}

function scrollToBottom() {
    if (ui.chatContainer) {
        ui.chatContainer.scrollTop = ui.chatContainer.scrollHeight;
    }
}

// 新增: 统一管理发送按钮和Placeholder的状态
function updateSendButtonAndPlaceholderState() {
    const hasText = ui.messageInput.value.trim().length > 0;
    const hasFiles = attachedFiles.length > 0;

    // 修改: 直接使用全局的 isGenerating 标志位
    // 条件1: 按钮是否可点击
    const isEnabled = (hasText || hasFiles) && !isGenerating;

    if (isEnabled) {
        ui.sendButtonWrapper.classList.remove('disabled');
    } else {
        ui.sendButtonWrapper.classList.add('disabled');
    }

    // 条件2: 是否显示自定义 placeholder
    if (hasText) {
        ui.customPlaceholder.style.opacity = '0';
    } else {
        ui.customPlaceholder.style.opacity = '1';
    }
}

function renderAllMath() {
    console.log("DEBUG: --- renderAllMath() 函数被调用 ---"); // 【DEBUG】 1. 确认函数被调用

    // 选择所有尚未被渲染的 .math-placeholder 元素
    const mathElements = document.querySelectorAll('.math-placeholder:not([data-rendered])');

    // 【DEBUG】 2. 确认是否找到了元素
    console.log(`DEBUG: 找到 ${mathElements.length} 个需要渲染的数学元素。`, mathElements);

    mathElements.forEach(function(element, index) {
        // 【DEBUG】 3. 逐个检查找到的元素
        console.log(`DEBUG: --- 正在处理第 ${index + 1} 个元素 ---`);
        console.log("DEBUG: 元素本身:", element);

        const texSource = element.textContent;
        // 【DEBUG】 4. 检查从元素中提取的原始TeX内容
        console.log("DEBUG: 原始 TeX 内容 (texSource):", texSource);

        let cleanTex = '';
        let isDisplayMode = false;

        // 【核心修改】: 建立一个清晰、无歧义的判断逻辑来处理所有分隔符
        if (texSource.startsWith('$$') && texSource.endsWith('$$')) {
            cleanTex = texSource.slice(2, -2).trim();
            isDisplayMode = true;
        } else if (texSource.startsWith('\\[') && texSource.endsWith('\\]')) {
            cleanTex = texSource.slice(2, -2).trim();
            isDisplayMode = true;
        } else if (texSource.startsWith('$') && texSource.endsWith('$')) {
            cleanTex = texSource.slice(1, -1).trim();
            isDisplayMode = false;
        } else if (texSource.startsWith('\\(') && texSource.endsWith('\\)')) {
            cleanTex = texSource.slice(2, -2).trim();
            isDisplayMode = false;
        } else {
            // 【DEBUG】 5. 如果没有匹配的分隔符
            console.warn("DEBUG: 未匹配到任何已知分隔符，跳过此元素。内容:", texSource);
            return;
        }

        // 【DEBUG】 6. 检查处理后的干净TeX和模式
        console.log("DEBUG: 清理后的 TeX (cleanTex):", cleanTex);
        console.log("DEBUG: 是否为显示模式 (isDisplayMode):", isDisplayMode);

        try {
            // 使用 KaTeX 渲染，并加入错误处理
            katex.render(cleanTex, element, {
                throwOnError: false, // 失败时不要抛出异常，而是显示错误信息
                displayMode: isDisplayMode
            });
            // 添加一个属性标记，防止重复渲染
            element.setAttribute('data-rendered', 'true');
            // 【DEBUG】 7. 渲染成功
            console.log("DEBUG: KaTeX 渲染成功！");
        } catch (e) {
            // 如果渲染出错，在元素内显示错误信息
            element.textContent = 'KaTeX Error: ' + e.message;
            // 【DEBUG】 8. 渲染失败
            console.error("DEBUG: KaTeX 渲染时发生错误:", e);
        }
        console.log(`DEBUG: --- 第 ${index + 1} 个元素处理完毕 ---`);
    });
    console.log("DEBUG: --- renderAllMath() 函数执行完毕 ---");
}

function highlightAllCode() {
    Prism.highlightAll();
}

// 2. 在 'pywebviewready' 事件中，只做两件事：
//    a. 获取 DOM 元素并存入全局的 ui 对象
//    b. 绑定用户交互事件 (如点击、输入)

window.addEventListener('pywebviewready', () => {
    // 【DEBUG】: 用一个大的 try-catch 块包裹所有初始化代码，捕捉任何潜在错误
    console.log("DEBUG: 'pywebviewready' 事件被触发！pywebview API 已准备就绪。");

    try {
        // 【DEBUG】 检查 KaTeX 库是否已加载
        if (typeof katex !== 'undefined') {
            console.log("DEBUG: KaTeX 库已成功加载。版本:", katex.version);
        } else {
            console.error("DEBUG: 严重错误！KaTeX 库 (katex) 未定义。请检查 script 标签是否正确。");
        }
        // a. 获取 DOM 元素
        console.log("DEBUG: 正在获取DOM元素...");
        ui.chatContainer = document.getElementById('chat-container');
        ui.messageInput = document.getElementById('message-input');
        quotePreviewContainer = document.getElementById('quote-preview-container');
        quotePreviewText = document.getElementById('quote-preview-text');
        cancelQuoteBtn = document.getElementById('cancel-quote-btn');
        ui.sendBtn = document.getElementById('send-btn');
        ui.quotePreviewArea = document.getElementById('quote-preview-area');
        ui.sendButtonWrapper = document.getElementById('send-button-wrapper');
        ui.customPlaceholder = document.getElementById('custom-placeholder');
        ui.attachFileBtn = document.getElementById('attach-file-btn');
        ui.attachImageBtn = document.getElementById('attach-image-btn');
        ui.stopGenerationBtn = document.getElementById('stop-generation-btn'); // 修改: 获取新按钮
        ui.filePreviewArea = document.getElementById('file-preview-area');
        ui.fileInput = document.getElementById('file-input');
        ui.imageInput = document.getElementById('image-input');
        ui.runHtmlModal = document.getElementById('run-html-modal-overlay');
        ui.runHtmlIframe = document.getElementById('run-html-iframe');
        ui.runModalCloseBtn = document.getElementById('run-modal-close-btn');
        ui.copyToast = document.getElementById('copy-toast');
        // --- 【新增】获取加载遮罩层元素 ---
        ui.loadingOverlay = document.getElementById('loading-overlay');
        ui.progressBar = document.getElementById('progress-bar');
        // --- 【新增结束】 ---
        console.log("DEBUG: DOM元素获取完成。");

        // b. 绑定用户交互事件
        console.log("DEBUG: 正在绑定用户交互事件...");

        // 新增: 获取多选底部栏的按钮
        ui.multiSelectFooter = document.getElementById('multi-select-footer');
        ui.quoteSelectedBtn = document.getElementById('quote-selected-btn');
        ui.exportPdfBtn = document.getElementById('export-pdf-btn');
        ui.exportImageBtn = document.getElementById('export-image-btn');
        ui.cancelSelectBtn = document.getElementById('cancel-select-btn');

        // 发送消息的函数 (修改为异步)
        const sendMessage = async () => {
            // 【核心新增】增加后端就绪状态检查
            if (!isBackendReady) {
                alert('Navi还在准备中，请稍等片刻...');
                return;
            }

            if (isGenerating || ui.sendButtonWrapper.classList.contains('disabled')) {
                return;
            }

            const messageText = ui.messageInput.value.trim();
            const filesToSend = attachedFiles.slice(); // 复制数组，防止后续修改影响
            // 【核心修复】在清空之前，深度复制当前的引用信息，为生成气泡做准备
            const replyInfoForBubble = JSON.parse(JSON.stringify(currentReplyInfo));

            // 【核心新增】在创建气泡前，计算新消息的索引
            const newUserMessageIndex = document.querySelectorAll('.message-wrapper').length;

            // 1. 【核心修改】使用 await 等待用户气泡创建完成
            const userContentHTML = `<p>${messageText.replace(/\n/g, '<br>')}</p>`;
            await createMessageBubble('user',
                userContentHTML,
                {
                    rawText: messageText,
                    replyInfo: replyInfoForBubble,
                    index: newUserMessageIndex,
                    attachments: filesToSend
                }
            );

            // 【核心新增】计算AI思考气泡的索引
            const assistantBubbleIndex = newUserMessageIndex + 1;

            // 2. 立即创建AI“思考中”占位气泡
            const thinkingContent = `
                <div class="thinking-timer">思考了 0 秒</div>
                <div class="message-content-streaming">Navi正在思考中.</div>
            `;
            // 【最终修复】必须 await 这个异步函数调用！
            const assistantBubbleWrapper = await createMessageBubble('assistant', thinkingContent, { index: assistantBubbleIndex });

            // ... (现在 assistantBubbleWrapper 是一个真实的 DOM 元素，后面的代码可以正常工作了) ...

            // 【核心修正 - 步骤1】: 此时 assistantBubbleWrapper.id 是正确的唯一ID，我们保存它
            currentStreamingMessageId = assistantBubbleWrapper.id;
            console.log("DIAGNOSTIC: Stored correct unique ID:", currentStreamingMessageId);

            // 【核心修正 - 步骤2】: 手动将其ID临时设置为'streaming-wrapper'以供流式输出使用
            const oldStreamWrapper = document.getElementById('streaming-wrapper');
            if (oldStreamWrapper) oldStreamWrapper.id = '';
            assistantBubbleWrapper.id = 'streaming-wrapper';

            // 3. 启动思考动画和计时器
            let dotCount = 1;
            const streamingContentDiv = assistantBubbleWrapper.querySelector('.message-content-streaming');
            thinkingInterval = setInterval(() => {
                dotCount = (dotCount % 3) + 1;
                streamingContentDiv.textContent = "Navi正在思考中" + ".".repeat(dotCount);
            }, 500);

            timerSeconds = 0;
            const timerElement = assistantBubbleWrapper.querySelector('.thinking-timer');
            timerInterval = setInterval(() => {
                timerSeconds++;
                timerElement.textContent = `思考了 ${timerSeconds} 秒`;
            }, 1000);

            // 4. 更新UI状态为“思考中”
            updateUIState('thinking');

            // 5. 清空输入区
            ui.messageInput.value = '';
            attachedFiles = [];
            ui.filePreviewArea.innerHTML = '';
            cancelQuote(); // 【核心修改】发送后清除引用状态和UI
            ui.messageInput.dispatchEvent(new Event('input'));

            // --- 后台通信 ---
            // 将文件转换为Base64并发送到Python
            const filesPayload = await Promise.all(filesToSend.map(async (file) => {
                const base64Content = await readFileAsBase64(file);
                return { name: file.name, type: file.type, content: base64Content };
            }));

            // 【核心修正】: 使用我们之前创建的快照 `replyInfoForBubble`，而不是已被清空的全局变量
            window.pywebview.api.send_message(messageText, filesPayload, replyInfoForBubble);
        };

        // 绑定发送事件
        ui.sendBtn.addEventListener('click', sendMessage);
        ui.messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        // 绑定输入框高度自适应和UI状态更新事件
        ui.messageInput.addEventListener('input', (e) => {
            handleTextareaInput(e);
            updateSendButtonAndPlaceholderState();
        });

        // 【核心修复】: 将多选按钮的事件绑定移到这里
        // 确保 ui.cancelSelectBtn 等元素已成功获取
        ui.cancelSelectBtn.addEventListener('click', exitMultiSelectMode);

        // 【新增】为取消引用按钮绑定事件
        cancelQuoteBtn.addEventListener('click', cancelQuote);

        ui.quoteSelectedBtn.addEventListener('click', () => {
            const selectedIds = Array.from(selectedMessages);
            if (selectedIds.length > 0) {
                setQuote('multi', selectedIds);
            } else {
                // 可以加一个提示，虽然按钮理论上是禁用的
                console.warn("没有选中的消息可引用。");
            }
            // exitMultiSelectMode() 会在 setQuote 内部被调用，这里不需要重复调用
        });

        ui.exportPdfBtn.addEventListener('click', () => {
            console.log('导出选中消息为PDF:', Array.from(selectedMessages));
            window.pywebview.api.export_messages({ ids: Array.from(selectedMessages), format: 'pdf' });
            exitMultiSelectMode();
        });

        ui.exportImageBtn.addEventListener('click', () => {
            console.log('导出选中消息为长图片:', Array.from(selectedMessages));
            window.pywebview.api.export_messages({ ids: Array.from(selectedMessages), format: 'image' });
            exitMultiSelectMode();
        });

        // 绑定上传按钮点击事件
        ui.attachFileBtn.addEventListener('click', () => ui.fileInput.click());
        ui.attachImageBtn.addEventListener('click', () => ui.imageInput.click());

        // 绑定文件选择后的处理事件
        ui.fileInput.addEventListener('change', handleFilesSelected);
        ui.imageInput.addEventListener('change', handleFilesSelected);

        if (ui.stopGenerationBtn) {
            ui.stopGenerationBtn.addEventListener('click', handleStopGeneration);
        }

        console.log("DEBUG: 用户交互事件绑定完成。");

        // 新增: 设置初始UI状态
        updateSendButtonAndPlaceholderState();

        // 【核心修改】: 所有前端设置完成后，通知Python后端发送初始数据
        console.log("DEBUG: 即将调用 python api 'javascript_is_ready()' 来通知后端...");
        window.pywebview.api.javascript_is_ready();
        console.log("DEBUG: Python API 调用已发出。等待后端响应...");

        // 【核心新增】: 使用事件委托处理所有消息操作
        document.body.addEventListener('click', handleGlobalClick);

        // --- 【新增】处理菜单悬停的事件委托 ---
        document.body.addEventListener('mouseover', (e) => {
            const messageWrapper = e.target.closest('.message-wrapper');
            const moreMenu = e.target.closest('.more-menu');

            if (messageWrapper) {
                // 如果鼠标进入了一个消息行，取消任何关闭计划，并显示它的操作栏
                cancelMenuCloseTimer();
                showActions(messageWrapper.id);
            } else if (moreMenu) {
                // 如果鼠标进入了“更多”菜单，也取消关闭计划
                cancelMenuCloseTimer();
            }
        });

        document.body.addEventListener('mouseout', (e) => {
            const messageWrapper = e.target.closest('.message-wrapper');
            const moreMenu = e.target.closest('.more-menu');

            // 如果鼠标离开了消息行或“更多”菜单，启动关闭计时器
            if (messageWrapper || moreMenu) {
                startMenuCloseTimer();
            }
        });

    } catch (e) {
        // 【DEBUG】: 如果 try 块中的任何代码出错，这里会捕捉到并打印出来
        console.error("DEBUG: 在 'pywebviewready' 事件处理器中发生严重错误:", e);
    }
});



// --- 附件处理的辅助函数 (可以放在外面，因为它们不直接依赖DOM加载) ---
function handleTextareaInput(event) {
    const textarea = event.target;
    // 计算单行高度和最大高度（6行）
    const computedStyle = window.getComputedStyle(textarea);
    const lineHeight = parseFloat(computedStyle.lineHeight);
    const paddingTop = parseFloat(computedStyle.paddingTop);
    const paddingBottom = parseFloat(computedStyle.paddingBottom);
    const borderTop = parseFloat(computedStyle.borderTopWidth);
    const borderBottom = parseFloat(computedStyle.borderBottomWidth);

    // 我们需要内容区的高度，所以要减去 padding 和 border
    const singleRowHeight = lineHeight;
    const maxHeight = (singleRowHeight * 6) + paddingTop + paddingBottom + borderTop + borderBottom;

    // 重置高度以获取 scrollHeight
    textarea.style.height = 'auto';

    const scrollHeight = textarea.scrollHeight;

    if (scrollHeight > maxHeight) {
        textarea.style.height = `${maxHeight}px`;
        textarea.style.overflowY = 'scroll'; // 显示滚动条
    } else {
        textarea.style.height = `${scrollHeight}px`;
        textarea.style.overflowY = 'hidden'; // 隐藏滚动条
    }
}

// --- 新增：文件转 Base64 辅助函数 ---
function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result); // reader.result 包含 "data:mime/type;base64,..."
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
}


// 新增: 格式化文件大小的辅助函数
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// 新增: 创建文件预览卡片（核心函数）
function createFilePreviewCard(file) {
    const fileId = `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const card = document.createElement('div');
    card.className = 'file-preview-card';
    card.dataset.fileId = fileId;

    const isImage = file.type.startsWith('image/');
    // 默认的通用图标源
    const genericIconSrc = `${window.BASE_URL}assets/icons/generic_file_icon.png`;

    // 【核心修改】: 统一使用带有 thumbnail-wrapper 的HTML结构，与消息气泡中的预览对齐
    card.innerHTML = `
        <div class="thumbnail-wrapper">
            <img class="thumbnail" src="${isImage ? '' : genericIconSrc}" alt="preview">
        </div>
        <div class="file-info">
            <div class="file-name">${file.name}</div>
            <div class="file-meta">${file.type.split('/')[1] || 'file'} · ${formatFileSize(file.size)}</div>
        </div>
        <button class="delete-btn">×</button>
        <div class="uploading-overlay" style="display: none;">
            <div class="spinner"></div>
            <span class="upload-text">上传中...</span>
        </div>
    `;

    // 如果是图片，使用FileReader异步读取并生成缩略图
    if (isImage) {
        const reader = new FileReader();
        reader.onload = (e) => {
            // 【核心修改】: 精确地选择 wrapper 内的 img 元素来设置 src
            card.querySelector('.thumbnail-wrapper .thumbnail').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }

    // 绑定删除事件
    card.querySelector('.delete-btn').addEventListener('click', () => {
        removeFile(fileId);
    });

    ui.filePreviewArea.appendChild(card);

    // 模拟上传动画
    const overlay = card.querySelector('.uploading-overlay');
    overlay.style.display = 'flex';
    setTimeout(() => {
        overlay.style.display = 'none';
    }, 1500 + Math.random() * 1000); // 模拟1.5-2.5秒的上传时间
}

// 修改: `handleFilesSelected` 调用新函数
function handleFilesSelected(event) {
    const files = event.target.files;
    if (!files) return;

    for (const file of files) {
        if (!attachedFiles.some(f => f.name === file.name && f.size === file.size)) {
            attachedFiles.push(file);
            createFilePreviewCard(file); // 调用新函数
        }
    }
    event.target.value = '';
    updateSendButtonAndPlaceholderState(); // 更新状态
}

// 修改: `removeFile` 的逻辑
function removeFile(fileId) {
    const card = ui.filePreviewArea.querySelector(`[data-file-id="${fileId}"]`);
    if (card) {
        const fileName = card.querySelector('.file-name').textContent;
        // 从 attachedFiles 数组中移除
        attachedFiles = attachedFiles.filter(f => f.name !== fileName);
        // 从 DOM 中移除
        card.remove();
        console.log("剩余文件:", attachedFiles);
        updateSendButtonAndPlaceholderState(); // 更新状态
    }
}


// 新增: 统一的UI状态管理器
function updateUIState(state) {
    isGenerating = (state === 'thinking');

    // 更新输入框和placeholder
    updateSendButtonAndPlaceholderState(); // 这个函数已经存在，我们复用它

    // 更新中止按钮
    ui.stopGenerationBtn.style.display = isGenerating ? 'block' : 'none';

    if (state === 'thinking') {
        // 【重要】: 我们不再在这里创建气泡，只更新状态
        // 启动计时器和动画的逻辑将被移到 sendMessage 中
    } else { // 'idle'
        clearInterval(thinkingInterval);
        clearInterval(timerInterval);
        thinkingInterval = null;
        timerInterval = null;
    }
}

function generateReplyPreviewHTML(replyInfo, context = 'user_quote') {
    // <-- 1. 新增 context 参数并设默认值
    // 【核心修复】修正了判断条件：!replyInfo.ids.length === 0 -> replyInfo.ids.length === 0
    if (!replyInfo || !replyInfo.ids || replyInfo.ids.length === 0) {
        return ''; // 如果没有回复信息，或回复ID列表为空，则返回空字符串
    }

    // --- 优先使用数据自带的source标记来确定上下文 ---
    // 这使得无论是实时生成还是从历史加载，都能正确渲染
    if (replyInfo.source === 'rag') {
        context = 'rag';
    }

    let previewText = '';
    if (replyInfo.type === 'single') {
        const messageId = replyInfo.ids[0];
        const messageData = messageDataStore[messageId];
        const author = document.getElementById(messageId)?.classList.contains('user') ? '你' : 'Navi';

        if (messageData) {
            previewText = `回复 ${author}: ${messageData.rawText.substring(0, 30)}...`;
        } else {
            previewText = `回复 ${author} 的一条消息`;
        }
    } else if (replyInfo.type === 'multi') {
        // 使用传入的 context 参数进行判断，而不是不可靠的 event.type
        if (context === 'rag') {
             previewText = `根据 ${replyInfo.ids.length} 条相关历史回答`;
        } else { // 'user_quote' 或其他情况
             previewText = `回复 ${replyInfo.ids.length} 条消息`;
        }
    }

    // 将id列表存储在data属性中，为将来的点击跳转做准备
    return `
        <div class="reply-preview-in-bubble" data-reply-ids='${JSON.stringify(replyInfo.ids)}'>
            ${previewText}
        </div>
    `;
}

// 【最终修复与调试版】
function generateAttachmentPreviewHTML(attachments) {
    // 【调试点 A】检查进入此函数的原始附件数据
    console.log("DEBUG [generateAttachmentPreviewHTML]: Received attachments:", attachments);

    if (!attachments || attachments.length === 0) {
        return '';
    }

    const cardsHTML = attachments.map((file, index) => {
        const isImage = file.type && file.type.startsWith('image/');
        let previewSrc;

        // 统一逻辑：优先使用 dataURL
        if (isImage && file.dataURL) {
            // 无论是来自后端历史，还是前端刚生成的，只要有 dataURL 就用它
            previewSrc = file.dataURL;
            // 【调试点 B】确认正在为图片使用 dataURL
            console.log(`DEBUG [generateAttachmentPreviewHTML]: Card ${index} (Image) is using dataURL.`);
        } else {
            // 所有非图片文件，或没有 dataURL 的图片，都使用通用图标
            previewSrc = `${window.BASE_URL}assets/icons/generic_file_icon.png`;
            // 【调试点 C】确认正在使用通用图标
            console.log(`DEBUG [generateAttachmentPreviewHTML]: Card ${index} (Non-Image/No-DataURL) is using generic icon.`);
        }

        // HTML结构不变
        return `
            <div class="file-preview-card">
                <div class="thumbnail-wrapper">
                    <img class="thumbnail" src="${previewSrc}" alt="file preview">
                </div>
                <div class="file-info">
                    <div class="file-name">${file.name}</div>
                    <div class="file-meta">${(file.type || '').split('/')[1] || 'file'} · ${formatFileSize(file.size || 0)}</div>
                </div>
            </div>
        `;
    }).join('');

    return `<div class="attachment-previews-in-bubble">${cardsHTML}</div>`;
}

// 【最终修复与调试版】将其改造为 async 函数
async function createMessageBubble(role, contentHTML, options = {}) {
    const { rawText = '', rawMd = '', replyInfo = null, index, attachments = [] } = options;
    const messageId = (index !== undefined)
        ? `history-msg-${index}`
        : `msg-${Date.now()}-${Math.random()}`;

    messageDataStore[messageId] = { rawText, rawMd };

    // --- 【核心修改：异步处理附件】 ---
    let processedAttachments = attachments; // 默认为原始附件

    // 仅当是用户消息且有附件时，才进行异步处理
    if (role === 'user' && attachments && attachments.length > 0) {
        // 【调试点 D】确认进入了新消息的附件处理逻辑
        console.log("DEBUG [createMessageBubble]: Processing new user attachments asynchronously.", attachments);

        // 使用 Promise.all 等待所有文件读取完成
        processedAttachments = await Promise.all(attachments.map(async (file) => {
            // 如果是图片File对象，为其生成 dataURL
            if (file instanceof File && file.type.startsWith('image/')) {
                const dataURL = await readFileAsBase64(file);
                // 返回一个包含 dataURL 的新对象，同时保留原始信息
                return {
                    name: file.name,
                    type: file.type,
                    size: file.size,
                    dataURL: dataURL // <--- 关键！
                };
            }
            // 如果是历史附件（已经有dataURL了）或非图片文件，直接返回
            return file;
        }));
         // 【调试点 E】检查异步处理后的附件数据，确认 dataURL 已添加
        console.log("DEBUG [createMessageBubble]: Asynchronous processing complete. Processed attachments:", processedAttachments);
    }
    // --- 【修改结束】 ---

    const wrapper = document.createElement('div');
    wrapper.className = `message-wrapper ${role}`;
    wrapper.id = messageId;
    if (index !== undefined) {
        wrapper.dataset.index = index;
    }

    const actionButtonsHTML = generateActionButtonsHTML(role, messageId);
    const replyPreviewHTML = generateReplyPreviewHTML(replyInfo);
    // 使用我们处理过的数据来生成预览
    const attachmentPreviewHTML = generateAttachmentPreviewHTML(processedAttachments);

    const finalBubbleContent = `
        ${role === 'assistant' ? `
            <div class="model-header">
                <img src="${window.BASE_URL}assets/icons/ai_model_icon.png" alt="model icon">
                <span>ACG Navi</span>
            </div>` : ''}
        ${replyPreviewHTML ? replyPreviewHTML : ''}
        ${attachmentPreviewHTML ? attachmentPreviewHTML : ''}
        <div class="message-content">${contentHTML}</div>
    `;

    wrapper.innerHTML = `
        <div class="message-checkbox-wrapper">
            <div class="message-checkbox" data-message-id="${messageId}"></div>
        </div>
        <div class="message-content-wrapper">
            <div class="message-bubble">
                ${finalBubbleContent}
            </div>
            ${actionButtonsHTML}
        </div>
    `;

    ui.chatContainer.appendChild(wrapper);
    scrollToBottom();

    // 因为不再使用 createObjectURL，所以不再需要 revokeObjectURL。可以安全地删除这部分代码。
    // 这彻底解决了竞态条件问题。

    return wrapper;
}

// 新增: 动态生成操作按钮的HTML
function generateActionButtonsHTML(role, messageId) {
    const iconPath = (icon) => `${window.BASE_URL}assets/icons/${icon}`;

    let buttons = [];
    if (role === 'user') {
        buttons = [
            { action: 'quote', icon: 'message-circle.png', text: '引用' },
            { action: 'copy', icon: 'copy_icon.png', text: '复制' },
            { action: 'more', icon: 'more-horizontal.png', text: '更多' },
        ];
    } else { // assistant
        buttons = [
            { action: 'quote', icon: 'message-circle.png', text: '引用' },
            { action: 'copy', icon: 'copy_icon.png', text: '复制' },
            { action: 'copy-md', icon: 'clipboard.png', text: '复制MD' },
            { action: 'retry', icon: 'refresh-cw.png', text: '重试' },
            { action: 'more', icon: 'more-horizontal.png', text: '更多' },
        ];
    }

    const buttonsHTML = buttons.map(btn => `
        <div class="action-button" data-action="${btn.action}" data-message-id="${messageId}">
            <img src="${iconPath(btn.icon)}" alt="${btn.text}">
            <span>${btn.text}</span>
        </div>
    `).join('');

    return `<div class="message-actions">${buttonsHTML}</div>`;
}

function handleStopGeneration() {
    console.log("用户点击中止生成。");
    window.pywebview.api.stop_generation(); // 通知后端停止

    const streamingWrapper = document.getElementById('streaming-wrapper');
    if (streamingWrapper) {
        const contentDiv = streamingWrapper.querySelector('.message-content');
        // 在现有内容下方追加中止信息
        contentDiv.innerHTML += `<br><div class="aborted-message">你中止了Navi的输出</div>`;
        streamingWrapper.id = ''; // 移除ID，防止干扰下一次生成
    }

    // 重置UI状态
    updateUIState('idle');
}

// 【新增】一个辅助函数来显示复制成功的提示
function showCopyToast() {
    if (ui.copyToast) {
        ui.copyToast.classList.add('show');
        setTimeout(() => {
            ui.copyToast.classList.remove('show');
        }, 1500); // 1.5秒后自动消失
    }
}

async function handleGlobalClick(e) { // <-- 1. 声明为 async
    // --- 【新增】处理代码块工具栏按钮 ---
    const copyBtn = e.target.closest('.code-copy-btn');
    if (copyBtn) {
        console.log("DEBUG: Copy button clicked.");
        const targetId = copyBtn.dataset.targetId;
        const codeElement = document.getElementById(targetId);
        if (codeElement) {
            // 【核心修正】: 调用我们健壮的、带回退逻辑的辅助函数
            copyToClipboard(codeElement.innerText).then(success => {
                if (success) {
                    showCopyToast(); // 显示成功的提示
                    const originalText = copyBtn.innerHTML;
                    copyBtn.innerHTML = '已复制!';
                    setTimeout(() => {
                        copyBtn.innerHTML = originalText;
                    }, 1500);
                } else {
                    console.error('复制失败。');
                    alert('复制失败，请重试。');
                }
            });
        }
        return; // 处理完毕，提前返回
    }

    const runBtn = e.target.closest('.code-run-btn');
    if (runBtn) {
        console.log("DEBUG: Run button clicked.");
        const targetId = runBtn.dataset.targetId;
        const codeElement = document.getElementById(targetId);
        if (codeElement && ui.runHtmlModal && ui.runHtmlIframe) {
            const htmlContent = codeElement.innerText;
            ui.runHtmlIframe.srcdoc = htmlContent;
            ui.runHtmlModal.style.display = 'flex';
        }
        return; // 处理完毕，提前返回
    }

    // --- 【新增】处理关闭HTML运行模态框 ---
    if (e.target === ui.runModalCloseBtn || e.target === ui.runHtmlModal) {
        console.log("DEBUG: Closing run modal.");
        if (ui.runHtmlModal && ui.runHtmlIframe) {
            ui.runHtmlModal.style.display = 'none';
            ui.runHtmlIframe.srcdoc = ''; // 清空内容，释放资源
        }
        return;
    }
    // --- 【新增结束】 ---


    // --- 1. 处理消息操作按钮点击 ---
    const actionButton = e.target.closest('.action-button');
    if (actionButton) {
        const action = actionButton.dataset.action;
        const messageId = actionButton.dataset.messageId;
        await handleMessageAction(action, messageId, actionButton); // <-- 2. 使用 await 调用
        // 【核心修复】: 只有当点击的不是'更多'按钮时，才关闭菜单。
        // 因为 '更多' 按钮的职责是打开菜单。
        if (action !== 'more') {
            closeMoreMenu();
        }
        return;
    }

    // --- 2. 处理"更多"菜单项点击 ---
    const menuItem = e.target.closest('.menu-item');
    if (menuItem) {
        const action = menuItem.dataset.action;
        const messageId = menuItem.dataset.messageId;
        await handleMessageAction(action, messageId, menuItem); // <-- 3. 这里也要 await
        closeMoreMenu();
        return;
    }

    // --- 3. 处理多选复选框点击 ---
    const checkbox = e.target.closest('.message-checkbox');
    if (checkbox && isMultiSelectMode) {
        toggleMessageSelection(checkbox.dataset.messageId);
        return;
    }

    // --- 【新增】4. 处理气泡内的引用预览点击 ---
    const replyPreview = e.target.closest('.reply-preview-in-bubble');
    if (replyPreview) {
        handleReplyPreviewClick(replyPreview);
        return;
    }

    // --- 5. 如果点击页面其他地方，关闭"更多"菜单 ---
    if (!e.target.closest('.more-menu')) {
        closeMoreMenu();
    }
}

// --- 【核心新增】将 copyToClipboard 提升为全局辅助函数 ---
function copyToClipboard(text) {
    return new Promise((resolve) => {
        // 优先尝试现代、安全的API
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text)
                .then(() => resolve(true))
                .catch(() => resolve(false)); // 如果用户拒绝权限等，也算失败
        } else {
            // 回退到传统方法
            try {
                const textArea = document.createElement('textarea');
                textArea.value = text;
                // 必须将元素添加到DOM中才能选中它
                textArea.style.position = 'absolute';
                textArea.style.left = '-9999px';
                document.body.appendChild(textArea);
                textArea.select();
                const success = document.execCommand('copy');
                document.body.removeChild(textArea);
                resolve(success);
            } catch (err) {
                console.error('回退复制方法失败:', err);
                resolve(false);
            }
        }
    });
}
// --- 【新增结束】---

async function handleMessageAction(action, messageId, element) { // <-- 1. 声明为 async
    // 【诊断日志 1】: 确认函数被调用，并查看传入的参数
    console.log(`--- handleMessageAction triggered ---`);
    console.log(`Action: ${action}, Message ID: ${messageId}`);
    console.log("Clicked element:", element);

    const messageNode = document.getElementById(messageId);
    if (!messageNode) {
        console.error("Error: Could not find message node with ID:", messageId);
        return;
    }

    const messageContent = messageDataStore[messageId] || {};
    // 【诊断日志 2】: 检查我们是否成功获取了消息内容
    console.log("Message content from data store:", messageContent);

    // 辅助函数，用于提供复制成功的视觉反馈
    const showCopyFeedback = (btn) => {
        // 【诊断日志 4】: 检查传入showCopyFeedback的按钮元素
        console.log("showCopyFeedback received button:", btn);
        const span = btn.querySelector('span');
        if (!span) {
            console.error("CRITICAL ERROR: Could not find <span> inside the copy button!", btn);
            return;
        }
        const originalText = span.textContent;
        span.textContent = '已复制!';
        setTimeout(() => {
            span.textContent = originalText;
        }, 1500);
    };

    switch (action) {
        case 'quote':
            console.log("Executing action: quote");
            setQuote('single', [messageId]); // <-- 新的调用
            break;
        case 'copy':
            console.log("Executing action: copy");
            copyToClipboard(messageContent.rawText).then(success => {
                if (success) {
                    showCopyFeedback(element.closest('.action-button'));
                } else {
                    alert('复制失败！');
                }
            });
            break;
        case 'copy-md':
             console.log("Executing action: copy-md");
             copyToClipboard(messageContent.rawMd).then(success => {
                 if (success) {
                    showCopyFeedback(element.closest('.action-button'));
                 } else {
                     alert('复制失败！');
                 }
             });
             break;
        case 'retry':
            console.log("Executing action: retry");
            {
                // 找到对应的用户消息节点
                let userMessageNode = messageNode.classList.contains('user')
                    ? messageNode
                    : messageNode.previousElementSibling;

                if (!userMessageNode || !userMessageNode.classList.contains('user')) {
                     alert("无法找到对应的用户消息进行重试。");
                     return;
                }

                const userMessageIndex = parseInt(userMessageNode.dataset.index);

                // 1. 删除旧的AI回答气泡 (如果存在)
                const nextNode = userMessageNode.nextElementSibling;
                if (nextNode && nextNode.classList.contains('assistant')) {
                    nextNode.remove();
                }

                // 2. 创建“思考中”气泡
                const assistantBubbleIndex = userMessageIndex + 1;
                const thinkingContent = `
                    <div class="thinking-timer">思考了 0 秒</div>
                    <div class="message-content-streaming">Navi正在思考中.</div>
                `;
                // 【最终修复】必须 await 这个异步函数调用！
                const assistantBubbleWrapper = await createMessageBubble('assistant', thinkingContent, { index: assistantBubbleIndex });

                // 将新气泡插入到用户消息之后，而不是追加到末尾
                userMessageNode.parentNode.insertBefore(assistantBubbleWrapper, userMessageNode.nextSibling);

                currentStreamingMessageId = assistantBubbleWrapper.id;
                const oldStreamWrapper = document.getElementById('streaming-wrapper');
                if (oldStreamWrapper) oldStreamWrapper.id = '';
                assistantBubbleWrapper.id = 'streaming-wrapper';

                // 3. 启动思考动画和计时器 (逻辑不变)
                let dotCount = 1;
                const streamingContentDiv = assistantBubbleWrapper.querySelector('.message-content-streaming');
                thinkingInterval = setInterval(() => {
                    dotCount = (dotCount % 3) + 1;
                    streamingContentDiv.textContent = "Navi正在思考中" + ".".repeat(dotCount);
                }, 500);
                timerSeconds = 0;
                const timerElement = assistantBubbleWrapper.querySelector('.thinking-timer');
                timerInterval = setInterval(() => {
                    timerSeconds++;
                    timerElement.textContent = `思考了 ${timerSeconds} 秒`;
                }, 1000);

                // 4. 更新UI状态 (逻辑不变)
                updateUIState('thinking');

                // 5. 调用Python API，它现在只负责处理数据和启动LLM (逻辑不变)
                console.log("UI准备就绪，调用后端 retry_message，索引:", userMessageIndex);
                window.pywebview.api.retry_message(userMessageIndex);
            }
            break;
        case 'more':
            // 【诊断日志 3】: 确认'more'分支被执行
            console.log("Executing action: more");
            showMoreMenu(messageNode, element);
            break;
        case 'edit':
            console.log("Executing action: edit");
            enterEditMode(messageId);
            break;
        case 'delete':
            console.log("Executing action: delete");
            if (confirm('确定要删除这个对话回合吗？(这通常会同时删除提问和回答)')) {
                const messageIndex = messageNode.dataset.index;
                console.log('向后端发送删除请求，索引:', messageIndex);
                window.pywebview.api.delete_message(messageIndex);
            }
            break;
        case 'multi-select':
            console.log("Executing action: multi-select");
            enterMultiSelectMode();
            break;
        default:
            console.warn("Unknown action:", action);
    }
}

// --- "更多"菜单逻辑 ---

let activeMoreMenu = null;
function showMoreMenu(messageNode, buttonElement) {
    cancelMenuCloseTimer(); // 【核心新增】确保在打开菜单时不会有关闭计时器在运行
    closeMoreMenu(); // 先关闭已有的

    const role = messageNode.classList.contains('user') ? 'user' : 'assistant';
    const messageId = messageNode.id;
    const iconPath = (icon) => `${window.BASE_URL}assets/icons/${icon}`;

    let menuItems = [];
    if (role === 'user') {
        menuItems = [
            { action: 'edit', icon: 'edit.png', text: '编辑' },
            { action: 'delete', icon: 'trash-2.png', text: '删除', danger: true },
            { action: 'multi-select', icon: 'list.png', text: '多选' },
        ];
    } else { // assistant
        menuItems = [
            { action: 'delete', icon: 'trash-2.png', text: '删除', danger: true },
            { action: 'multi-select', icon: 'list.png', text: '多选' },
        ];
    }

    const menu = document.createElement('div');
    menu.className = 'more-menu';
    menu.innerHTML = menuItems.map(item => `
        <div class="menu-item ${item.danger ? 'danger' : ''}" data-action="${item.action}" data-message-id="${messageId}">
            <img src="${iconPath(item.icon)}" alt="${item.text}">
            <span>${item.text}</span>
        </div>
    `).join('');

    document.body.appendChild(menu);
    activeMoreMenu = menu;

    // 定位菜单
    const btnRect = buttonElement.getBoundingClientRect();
    const menuRect = menu.getBoundingClientRect();

    let top = btnRect.bottom + 5;
    let left = btnRect.left;

    // 防止菜单超出屏幕右侧
    if (left + menuRect.width > window.innerWidth) {
        left = btnRect.right - menuRect.width;
    }
    // 防止菜单超出屏幕底部
    if (top + menuRect.height > window.innerHeight) {
        top = btnRect.top - menuRect.height - 5;
    }

    menu.style.top = `${top}px`;
    menu.style.left = `${left}px`;
}

function closeMoreMenu() {
    if (activeMoreMenu) {
        activeMoreMenu.remove();
        activeMoreMenu = null;
    }
}

// --- 多选模式逻辑 ---

function enterMultiSelectMode() {
    isMultiSelectMode = true;
    document.body.classList.add('multi-select-mode');
    ui.multiSelectFooter.style.display = 'flex';
    updateMultiSelectFooter();
}

function exitMultiSelectMode() {
    isMultiSelectMode = false;
    document.body.classList.remove('multi-select-mode');
    ui.multiSelectFooter.style.display = 'none';
    selectedMessages.clear();
    // 移除所有消息的选中样式
    document.querySelectorAll('.message-checkbox.selected').forEach(el => el.classList.remove('selected'));
}

function toggleMessageSelection(messageId) {
    const checkbox = document.querySelector(`.message-checkbox[data-message-id="${messageId}"]`);
    if (selectedMessages.has(messageId)) {
        selectedMessages.delete(messageId);
        checkbox.classList.remove('selected');
    } else {
        selectedMessages.add(messageId);
        checkbox.classList.add('selected');
    }
    updateMultiSelectFooter();
}

function updateMultiSelectFooter() {
    const count = selectedMessages.size;
    const canQuote = count > 0 && count <= 5;

    ui.quoteSelectedBtn.disabled = !canQuote;
    ui.quoteSelectedBtn.textContent = count > 0 ? `引用选中 (${count})` : '引用选中';

    ui.exportPdfBtn.disabled = count === 0;
    ui.exportImageBtn.disabled = count === 0;
}
// 【新增】更新引用预览UI的函数
function updateQuotePreview() {
    if (!quotePreviewContainer) return; // 安全检查

    if (currentReplyInfo.ids.length === 0) {
        quotePreviewContainer.style.display = 'none';
        return;
    }

    if (currentReplyInfo.type === 'single') {
        const messageId = currentReplyInfo.ids[0];
        const messageData = messageDataStore[messageId];
        if (messageData) {
            const previewContent = messageData.rawText.substring(0, 50) + (messageData.rawText.length > 50 ? '...' : '');
            quotePreviewText.textContent = `回复: ${previewContent}`;
        }
    } else if (currentReplyInfo.type === 'multi') {
        quotePreviewText.textContent = `正在回复 ${currentReplyInfo.ids.length} 条消息`;
    }

    quotePreviewContainer.style.display = 'flex';
    ui.messageInput.focus();
}

// 【新增】设置引用信息的函数
function setQuote(type, ids) {
    currentReplyInfo.type = type;
    currentReplyInfo.ids = ids;
    updateQuotePreview();
    if (isMultiSelectMode) {
        exitMultiSelectMode();
    }
}

// 【新增】取消引用的函数
function cancelQuote() {
    currentReplyInfo.type = null;
    currentReplyInfo.ids = [];
    updateQuotePreview();
}

function highlightMessage(messageId) {
    const messageEl = document.getElementById(messageId);
    if (messageEl) {
        // 确保移除可能存在的旧高亮
        document.querySelectorAll('.highlighted').forEach(el => el.classList.remove('highlighted'));

        messageEl.classList.add('highlighted');
        setTimeout(() => {
            messageEl.classList.remove('highlighted');
        }, 2000); // 高亮持续2秒
    }
}

function handleReplyPreviewClick(element) {
    const idsStr = element.dataset.replyIds;
    if (!idsStr) return;

    try {
        const ids = JSON.parse(idsStr);
        if (ids.length === 1) {
            // 单条引用：滚动并高亮
            const targetMessage = document.getElementById(ids[0]);
            if (targetMessage) {
                targetMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
                highlightMessage(ids[0]);
            } else {
                alert("抱歉，找不到原始消息。可能已被删除或在历史记录的较早部分。");
            }
        } else if (ids.length > 1) {
            // 多条引用：显示弹窗
            showReplyModal(ids);
        }
    } catch (e) {
        console.error("解析引用ID时出错:", e);
    }
}

function showReplyModal(ids) {
    const modalOverlay = document.getElementById('reply-modal-overlay');
    const modalBody = document.getElementById('modal-body');
    const closeModalBtn = document.getElementById('modal-close-btn');

    // 清空旧内容
    modalBody.innerHTML = '';

    // 克隆并添加每个被引用的消息
    ids.forEach(id => {
        const originalMessage = document.getElementById(id);
        if (originalMessage) {
            const clone = originalMessage.cloneNode(true);
            modalBody.appendChild(clone);
        }
    });

    // 显示弹窗
    modalOverlay.style.display = 'flex';

    // 绑定关闭事件
    closeModalBtn.onclick = closeReplyModal;
    modalOverlay.onclick = (e) => {
        if (e.target === modalOverlay) { // 仅当点击背景时关闭
            closeReplyModal();
        }
    };
}

function closeReplyModal() {
    const modalOverlay = document.getElementById('reply-modal-overlay');
    if (modalOverlay) {
        modalOverlay.style.display = 'none';
    }
}


function enterEditMode(messageId) {
    // 如果已经在编辑另一条消息，先取消它
    if (currentEditingId) {
        cancelEditMode(currentEditingId);
    }

    currentEditingId = messageId;
    const messageNode = document.getElementById(messageId);
    const contentDiv = messageNode.querySelector('.message-content');
    const actionsDiv = messageNode.querySelector('.message-actions');

    // 存储原始HTML以便取消时恢复
    contentDiv.dataset.originalHtml = contentDiv.innerHTML;

    // 获取纯文本内容
    const rawText = messageDataStore[messageId].rawText;

    // 创建编辑UI
    contentDiv.innerHTML = `
        <div class="message-edit-area">
            <textarea class="edit-textarea">${rawText}</textarea>
            <div class="message-edit-actions">
                <button class="cancel-btn">取消</button>
                <button class="save-btn">保存并重新生成</button>
            </div>
        </div>
    `;

    // 隐藏常规操作按钮
    if (actionsDiv) actionsDiv.style.display = 'none';

    // 绑定新按钮的事件
    const textarea = contentDiv.querySelector('.edit-textarea');
    contentDiv.querySelector('.cancel-btn').addEventListener('click', () => cancelEditMode(messageId));
    contentDiv.querySelector('.save-btn').addEventListener('click', () => saveEdit(messageId));

    // 自动调整高度并聚焦
    handleTextareaInput({ target: textarea });
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = textarea.value.length;
}

function cancelEditMode(messageId) {
    if (!currentEditingId || currentEditingId !== messageId) return;

    const messageNode = document.getElementById(messageId);
    const contentDiv = messageNode.querySelector('.message-content');
    const actionsDiv = messageNode.querySelector('.message-actions');

    // 恢复原始内容
    contentDiv.innerHTML = contentDiv.dataset.originalHtml;
    delete contentDiv.dataset.originalHtml;

    // 恢复操作按钮
    if (actionsDiv) actionsDiv.style.removeProperty('display');

    currentEditingId = null;
}

async function saveEdit(messageId) {
    const messageNode = document.getElementById(messageId);
    const textarea = messageNode.querySelector('.edit-textarea');
    const newContent = textarea.value.trim();

    if (!newContent) {
        alert("消息内容不能为空。");
        return;
    }

    // 立即退出编辑模式，让UI看起来更流畅
    cancelEditMode(messageId);

    console.log(`正在保存消息 ${messageId} 的编辑, 新内容:`, newContent);

    // 1. 【变为异步】调用Python API来更新数据和删除旧的AI气泡
    // 'await' 确保我们等待后端完成数据操作
    const messageIndex = messageNode.dataset.index;
    await window.pywebview.api.edit_message(messageIndex, newContent);

    // 2. 【核心新增】复用 sendMessage 中的逻辑来创建“思考中”气泡
    console.log("后端数据同步完成，现在由前端创建'思考中'气泡...");

    const assistantBubbleIndex = parseInt(messageIndex) + 1;

    const thinkingContent = `
        <div class="thinking-timer">思考了 0 秒</div>
        <div class="message-content-streaming">Navi正在思考中.</div>
    `;
    const assistantBubbleWrapper = createMessageBubble('assistant', thinkingContent, { index: assistantBubbleIndex });

    currentStreamingMessageId = assistantBubbleWrapper.id;
    const oldStreamWrapper = document.getElementById('streaming-wrapper');
    if (oldStreamWrapper) oldStreamWrapper.id = '';
    assistantBubbleWrapper.id = 'streaming-wrapper';

    // 3. 【核心新增】启动思考动画和计时器
    let dotCount = 1;
    const streamingContentDiv = assistantBubbleWrapper.querySelector('.message-content-streaming');
    thinkingInterval = setInterval(() => {
        dotCount = (dotCount % 3) + 1;
        streamingContentDiv.textContent = "Navi正在思考中" + ".".repeat(dotCount);
    }, 500);

    timerSeconds = 0;
    const timerElement = assistantBubbleWrapper.querySelector('.thinking-timer');
    timerInterval = setInterval(() => {
        timerSeconds++;
        timerElement.textContent = `思考了 ${timerSeconds} 秒`;
    }, 1000);

    // 4. 【核心新增】更新UI状态
    updateUIState('thinking');

    // 5. 【核心新增】调用新的Python API来真正启动LLM
    console.log("UI准备就绪，调用后端 regenerate_after_edit...");
    window.pywebview.api.regenerate_after_edit();
}

// --- 【新增】菜单和操作栏悬停逻辑的核心函数 ---

// 显示指定消息的操作栏
function showActions(messageId) {
    // 1. 如果有其他消息的操作栏是打开的，先关掉它
    if (activeMenuMessageId && activeMenuMessageId !== messageId) {
        hideActions();
    }

    // 2. 找到目标操作栏并显示它
    const messageNode = document.getElementById(messageId);
    if (messageNode) {
        const actionsDiv = messageNode.querySelector('.message-actions');
        if (actionsDiv) {
            actionsDiv.classList.add('actions-visible');
            activeMenuMessageId = messageId; // 记录当前激活的ID
        }
    }
}

// 隐藏当前激活的操作栏和“更多”菜单
function hideActions() {
    if (activeMenuMessageId) {
        const messageNode = document.getElementById(activeMenuMessageId);
        if (messageNode) {
            const actionsDiv = messageNode.querySelector('.message-actions');
            if (actionsDiv) {
                actionsDiv.classList.remove('actions-visible');
            }
        }
    }
    closeMoreMenu(); // 这是你已有的函数，我们顺便调用它
    activeMenuMessageId = null; // 清空激活ID
}

// 启动一个延时关闭的计时器
function startMenuCloseTimer() {
    // 先清除可能存在的旧计时器
    cancelMenuCloseTimer();
    // 设置一个新的计时器，300毫秒后隐藏所有菜单
    menuCloseTimer = setTimeout(hideActions, 300);
}

// 取消即将执行的关闭操作
function cancelMenuCloseTimer() {
    clearTimeout(menuCloseTimer);
}

function highlightAllCode() {
    Prism.highlightAll();
}

// --- 【核心新增】 ---
// 此函数用于查找所有代码块，并为其添加语言标签和功能按钮
function enhanceCodeBlocks() {
    console.log("DEBUG: Running enhanceCodeBlocks...");
    const codeBlocks = document.querySelectorAll('pre > code[class*="language-"]');

    codeBlocks.forEach((codeEl, index) => {
        const preEl = codeEl.parentElement;

        // 检查是否已经处理过，防止重复添加
        if (preEl.dataset.enhanced) {
            return;
        }

        // 1. 提取语言名称
        const langClass = Array.from(codeEl.classList).find(cls => cls.startsWith('language-'));
        const language = langClass ? langClass.replace('language-', '') : 'text';

        // 2. 创建包裹容器和工具栏
        const wrapper = document.createElement('div');
        wrapper.className = 'code-block-wrapper';

        const toolbar = document.createElement('div');
        toolbar.className = 'code-toolbar';

        // 3. 创建并添加语言名称标签
        const langName = document.createElement('span');
        langName.className = 'code-lang-name';
        langName.textContent = language;
        toolbar.appendChild(langName);

        // 4. 创建并添加“复制代码”按钮
        const copyButton = document.createElement('button');
        copyButton.className = 'code-toolbar-button code-copy-btn';
        // 使用 dataset 存储与此按钮关联的代码块的唯一标识
        const codeBlockId = `code-block-${Date.now()}-${index}`;
        codeEl.id = codeBlockId;
        copyButton.dataset.targetId = codeBlockId;
        copyButton.innerHTML = `<img src="${window.BASE_URL}assets/icons/copy_icon.png" alt="Copy"> 复制代码`;
        toolbar.appendChild(copyButton);

        // 5. 如果是HTML，创建并添加“运行”按钮
        if (language.toLowerCase() === 'html') {
            const runButton = document.createElement('button');
            runButton.className = 'code-toolbar-button code-run-btn';
            runButton.dataset.targetId = codeBlockId;
            runButton.innerHTML = `<img src="${window.BASE_URL}assets/icons/play-circle.png" alt="Run"> 运行`; // 假设你有一个运行图标
            toolbar.appendChild(runButton);
        }

        // 6. DOM结构重组
        preEl.parentNode.insertBefore(wrapper, preEl);
        wrapper.appendChild(preEl);
        wrapper.insertBefore(toolbar, preEl); // 将工具栏插入到 <pre> 之前

        // 标记为已处理
        preEl.dataset.enhanced = 'true';
    });
}
// --- 【核心新增结束】 ---

function loadHistory(messagesData) {
    ui.chatContainer.innerHTML = ''; // 清空现有内容
    messagesData.forEach((msg, index) => {
        const optionsWithIndex = { ...msg.options, index: index };
        createMessageBubble(msg.role, msg.contentHTML, optionsWithIndex);
    });
    // 渲染历史记录中的代码和数学公式
    highlightAllCode();
    enhanceCodeBlocks();
    renderAllMath();
    scrollToBottom(); // <-- 确保加载后滚动到底部
};