// --- DOM Elements ---
const versionListEl = document.getElementById('version-list');
const versionTitleEl = document.querySelector('.version-title');
const versionDateEl = document.querySelector('.version-date');
const versionBodyEl = document.querySelector('.version-body');
const installPathInput = document.getElementById('install-path');
const browseBtn = document.getElementById('browse-btn');
const installBtn = document.getElementById('install-btn');
const repoBtn = document.getElementById('repo-btn');
const progressBar = document.getElementById('progress-bar');
const statusText = document.getElementById('status-text');

// --- State ---
let allVersionsData = [];
let selectedVersionData = null;

// --- Python Callable Functions ---
function update_progress(percent, message) {
    progressBar.style.width = percent + '%';
    statusText.textContent = message;
    statusText.className = '';
}

function update_status(message, type) {
    statusText.textContent = message;
    statusText.className = type; // 'error', 'success', or 'warning'
}

function installation_complete(message) {
    installBtn.textContent = '安装完成';
    installBtn.classList.add('success');
    update_status(message, 'success');
}


// --- Functions ---
async function loadVersions() {
    try {
        update_status('正在从 Gitee 获取版本列表...', '');
        const result = await pywebview.api.get_versions();
        if (result.status === 'success') {
            allVersionsData = result.versions;
            renderVersionList(allVersionsData);
            update_status('获取成功，请选择版本。', 'success');
        } else {
            throw new Error(result.message);
        }
    } catch (e) {
        update_status(`错误: ${e.message}`, 'error');
        console.error('Failed to load versions:', e);
    }
}

function renderVersionList(versions) {
    versionListEl.innerHTML = '';
    if (!versions || versions.length === 0) {
        versionListEl.innerHTML = '<li>未找到任何可用版本。</li>';
        return;
    }

    versions.forEach(version => {
        const li = document.createElement('li');
        li.dataset.tag = version.tag;
        li.innerHTML = `
            <div class="version-tag">${version.tag}</div>
            <div class="version-name">${version.name}</div>
        `;
        li.addEventListener('click', () => handleVersionSelect(version.tag));
        versionListEl.appendChild(li);
    });
}

function handleVersionSelect(tag) {
    selectedVersionData = allVersionsData.find(v => v.tag === tag);
    if (!selectedVersionData) return;

    // Update right panel details
    versionTitleEl.textContent = selectedVersionData.tag;
    versionDateEl.textContent = `发布于: ${new Date(selectedVersionData.published_at).toLocaleString()}`;
    versionBodyEl.innerHTML = selectedVersionData.body.replace(/\n/g, '<br>') || '<p>无版本描述。</p>';

    // Update UI selection state
    document.querySelectorAll('#version-list li').forEach(li => {
        li.classList.toggle('selected', li.dataset.tag === tag);
    });

    checkInstallButtonState();
}

function checkInstallButtonState() {
    const path = installPathInput.value;
    installBtn.disabled = !(selectedVersionData && path);
}

// --- Event Listeners ---
window.addEventListener('pywebviewready', loadVersions);

browseBtn.addEventListener('click', async () => {
    try {
        const path = await pywebview.api.select_directory();
        if (path) {
            installPathInput.value = path;
            checkInstallButtonState();
        }
    } catch (e) {
        console.error('Error selecting directory:', e);
    }
});

installBtn.addEventListener('click', () => {
    if (!selectedVersionData || !installPathInput.value) {
        update_status('请先选择一个版本和安装路径！', 'error');
        return;
    }
    installBtn.disabled = true;
    browseBtn.disabled = true;
    installBtn.textContent = '正在安装...';
    pywebview.api.start_installation(selectedVersionData, installPathInput.value);
});

repoBtn.addEventListener('click', () => {
    pywebview.api.open_repo();
});