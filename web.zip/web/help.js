// --- 状态变量 ---
let currentSectionKey = null;
let currentPageInSection = 0;
let totalPagesInSection = 1;

// 新增：定义多彩边框的颜色池
const colorPalette = ['#82A5D1', '#97B99C', '#F5C578', '#D16D66', '#8884d8'];

// --- DOM 元素获取 ---
const pageTitleEl = document.getElementById('page-title');
const textContentEl = document.getElementById('text-content');
const imageEl = document.getElementById('help-image');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const pageIndicatorEl = document.getElementById('page-indicator');
const sectionListEl = document.getElementById('section-list');

/**
 * 渲染页面内容
 * @param {object} data - 从 Python API 返回的数据对象
 */
function renderPage(data) {
    if (!data) return;

    const { page_data, current_page, total_pages, section_key } = data;

    // 更新状态
    currentSectionKey = section_key;
    currentPageInSection = current_page;
    totalPagesInSection = total_pages;

    // 渲染内容
    document.title = page_data.title || "使用说明";
    pageTitleEl.textContent = page_data.title || ''; // <-- 新增
    textContentEl.textContent = page_data.text || '';

    if (page_data.image) {
        imageEl.src = page_data.image;
        imageEl.style.display = 'block';
        imageEl.onclick = () => pywebview.api.show_full_size_image(page_data.image_relative_path);
    } else {
        imageEl.style.display = 'none';
        imageEl.onclick = null;
    }

    // 更新翻页指示器和按钮状态
    pageIndicatorEl.textContent = `第 ${currentPageInSection + 1} / ${totalPagesInSection} 页`;
    prevBtn.disabled = currentPageInSection === 0;
    nextBtn.disabled = currentPageInSection >= totalPagesInSection - 1;
}

/**
 * 加载指定章节的指定页面
 * @param {string} sectionKey - 章节的键
 * @param {number} pageIndex - 页面索引
 */
async function loadContent(sectionKey, pageIndex = 0) {
    const data = await pywebview.api.get_section_content(sectionKey, pageIndex);
    if (data) {
        renderPage(data);
        updateSidebarActiveState(sectionKey);
    }
}

/**
 * 更新侧边栏的高亮状态
 * @param {string} activeSectionKey - 当前活动的章节键
 */
function updateSidebarActiveState(activeSectionKey) {
    const items = sectionListEl.querySelectorAll('li');
    items.forEach(item => {
        if (item.dataset.sectionKey === activeSectionKey) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
}

/**
 * 初始化函数，在 pywebview 准备好后执行
 */
async function initialize() {
    // 1. 从后端获取所有章节标题
    const sections = await pywebview.api.get_sections();
    if (!sections || sections.length === 0) {
        textContentEl.textContent = '没有可用的帮助内容。';
        return;
    }

    // 2. 动态创建侧边栏列表
    sections.forEach((sectionKey, index) => { // <-- 新增 index 参数
        const li = document.createElement('li');
        li.textContent = sectionKey;
        li.dataset.sectionKey = sectionKey;

        // --- 核心新增：分配颜色 ---
        const color = colorPalette[index % colorPalette.length];
        li.style.setProperty('--item-color', color);
        // -------------------------

        li.addEventListener('click', () => loadContent(sectionKey));
        sectionListEl.appendChild(li);
    });

    // 3. 为翻页按钮添加事件监听
    prevBtn.addEventListener('click', () => {
        if (currentPageInSection > 0) {
            loadContent(currentSectionKey, currentPageInSection - 1);
        }
    });
    nextBtn.addEventListener('click', () => {
        if (currentPageInSection < totalPagesInSection - 1) {
            loadContent(currentSectionKey, currentPageInSection + 1);
        }
    });

    // 4. 默认加载第一个章节的第一页
    loadContent(sections[0]);
}

// --- 程序入口 ---
window.addEventListener('pywebviewready', initialize);